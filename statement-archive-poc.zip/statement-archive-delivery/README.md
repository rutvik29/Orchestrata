# Statement Archive Delivery Package

Consumer-facing REST API facade over the NCP Direct Access B2B Web Services, generated from the WSDL (`Statements.xml`) and the NCP specification document, preserving the enterprise Mortgage-loan-statement Swagger 2.0 contract and adding BIAN-aligned paths.

## Contents

| Path | Purpose |
|---|---|
| `input/wsdl/` | Source WSDL and XSDs (service `Statements`, operations `Authenticate`, `List`) |
| `input/ncp-spec/` | NCP Direct Access specification document (+ extracted text) |
| `input/enterprise-contract/` | Existing enterprise Swagger 2.0 contract (preserved as source of truth) |
| `swagger/statement-archive.openapi.yaml` | Generated OpenAPI 3.0.3 — legacy + BIAN paths |
| `design/statement-archive-design.md` | Design document: mappings, error mapping, security, AWS architecture, Mermaid diagrams |
| `design/architecture.mermaid` | Standalone high-level architecture diagram |
| `api/` | Node.js source (AWS Lambda + Express) and Mocha/Chai/Sinon unit tests |
| `api/wsdl/` | WSDL bundled into the deployment package (no runtime ?wsdl fetch) |
| `scripts/validate-openapi.py` | Contract regression gate: fails if the OpenAPI drifts from the frozen enterprise contract |
| `.github/workflows/ci.yml` | CI: contract gate, syntax check, unit tests, npm audit, sanitization scan |

## Consumer Operations

| operationId | Path | Backend orchestration |
|---|---|---|
| `ListStatement` | `POST /statement-archive/v1/statements/list` | `Authenticate` (SOAP) → `List` (SOAP) → JSON mapping |
| `RetrieveStatement` | `POST /statement-archive/v1/statements/retrieve` | `GetAccountPDF` or `GetAccountPDFinline` (REST) by `operationName` |
| `listMortgageStatement` (legacy) | `POST /document-services/mortgage-statement/list/get` | Same as ListStatement, legacy field names |
| `retrieveMortgageStmt` (legacy) | `POST /document-services/mortgage-statement/stream/get` | Same as RetrieveStatement, JSON base64 envelope |

## Code Layout (`api/src`)

`lambda.js` (AWS Lambda / API Gateway proxy entry point) and `app.js` (Express, local dev + tests) both delegate to `service.js` (orchestration), which uses `ncpClient.js` (SOAP + REST backend calls), `hashUtil.js` (SHA-256 Authenticate hash), `mappers.js` (XML→JSON, date and field mapping), `errorMapping.js` (NCP error codes → sanitized enterprise errorResponse), `config.js` (endpoints + Secrets Manager credentials), `routes.js`, and `logger.js` (masked structured logging).

## Running Tests

```bash
cd api
npm install
npm test
```

Environment for local runs (unit tests set mock values automatically):

```bash
NCP_CLIENT_ID=...        # from AWS Secrets Manager in AWS
NCP_USER_ID=...
NCP_PASSWORD=...
NCP_SHARED_SECRET=...
NCP_SOAP_WSDL=https://.../AvailableImages/Statements.svc?wsdl
NCP_REST_BASE=https://.../ImageRetrieval/Repository.svc
```

## Deployment Notes

Deploy `api/src` as a Node.js 18+ Lambda with handler `src/lambda.handler`. Import `swagger/statement-archive.openapi.yaml` into API Gateway, enable binary media type `application/pdf`, api-key requirement, and request validation. Store NCP credentials in Secrets Manager (`NCP_SECRET_ID` env var) and route Lambda egress through a NAT Gateway EIP registered on the NCP allowlist. See `design/statement-archive-design.md` for the full architecture.

## Production Hardening

The enterprise contract and templates are frozen; all hardening is additive in the facade:
SOAP and REST calls carry explicit timeouts (`HTTP_TIMEOUT_MS`); the SOAP client loads the
bundled WSDL at cold start instead of fetching `?wsdl` from the IP-allowlisted endpoint;
PDF payloads are capped (`MAX_PDF_BYTES`, default 50 MB); non-JSON request media types are
rejected with 415; and date fields are strictly validated (legacy `yyyymmdd`, BIAN
`yyyy-mm-dd`) before any backend call.

## SDLC Gates (run on every change)

```bash
python3 scripts/validate-openapi.py   # contract regression gate
cd api && npm install && npm test     # unit tests
npm audit --omit=dev --audit-level=high
```

The GitHub Actions workflow (`.github/workflows/ci.yml`) runs all three plus a
sanitization scan (no raw NCP error text or credential literals in consumer-facing
sources) on every push and pull request.
