'use strict';

/**
 * NCP error code to consumer HTTP status mapping and sanitized enterprise
 * errorResponse (Zalando Problem format) construction.
 *
 * Raw NCP error text, tokens, hashes, and secrets are NEVER placed in
 * consumer payloads. The NCP error code is exposed only as
 * resultDetails[].detailCode for support correlation; the message is generic.
 */

// Authenticate error codes (1100-1199) - returned in the token string.
const AUTHENTICATE_ERROR_STATUS = {
  1100: 400, // Required parameters are missing
  1101: 400, // Too many accounts have been requested
  1102: 500, // Hash mismatch
  1103: 400, // Invalid parameter value
  1199: 502 // Unexpected exception
};

// List error codes (1200-1299) - returned in the statementlist XML.
const LIST_ERROR_STATUS = {
  1200: 401, // Authentication token timed out (30-minute limit)
  1201: 502, // Authentication token is corrupt
  1203: 502, // Unable to load the product lookup table
  1205: 200, // No records found - NOT an error; 200 with empty statements array
  1206: 502, // Missing required columns in SSE search results
  1207: 502, // Unable to retrieve a list of client numbers
  1299: 502 // Unexpected exception
};

// GetAccountPDF / GetAccountPDFinline error codes (1000-1099) - Warning header.
const PDF_ERROR_STATUS = {
  1000: 400, // Document key is corrupt
  1001: 401, // Exceeded time allotted for viewing (30-minute limit)
  1003: 404, // SSE search did not return a document
  1004: 502, // Missing Report Authorization Code column
  1005: 502, // PDF is not readable
  1006: 403, // PDF request could not be verified
  1099: 502 // Unexpected exception
};

const STATUS_TITLES = {
  400: 'Bad Request',
  401: 'Unauthorized',
  403: 'Forbidden',
  404: 'Not Found',
  415: 'Unsupported Media Type',
  429: 'Too Many Requests',
  500: 'Internal Server Error',
  502: 'Bad Gateway',
  504: 'Integration or Backend Timeout'
};

const GENERIC_DETAIL =
  'We are unable to process your request at this time. Please try again later. ' +
  'If the problem persists, please contact the support line.';

const EXPIRED_DETAIL =
  'Your session or document link has expired. Please request the statement list again.';

/**
 * Build a sanitized enterprise errorResponse (Zalando Problem format).
 *
 * @param {object} options
 * @param {number} options.status - HTTP status code.
 * @param {string} options.instance - Request path for the instance URI.
 * @param {string} [options.detail] - Consumer-safe detail message.
 * @param {string} [options.ncpErrorCode] - NCP error code for resultDetails.
 * @returns {object} errorResponse body.
 */
function buildErrorResponse({ status, instance, detail, ncpErrorCode }) {
  const body = {
    type: 'about:blank',
    title: STATUS_TITLES[status] || 'Error',
    status,
    detail: detail || (status === 401 ? EXPIRED_DETAIL : GENERIC_DETAIL),
    instance: instance || ''
  };
  if (ncpErrorCode) {
    body.resultDetails = [
      { detailCode: String(ncpErrorCode), detailMessage: 'NCP backend error reference code' }
    ];
  }
  return body;
}

/**
 * Parse an Authenticate failure string and map it to an HTTP status.
 * Failure format: "ERROR: Authentication Failure|1199 <internal message>"
 *
 * @param {string} authenticateResult - Raw AuthenticateResult string.
 * @returns {{isError: boolean, ncpErrorCode: string|null, httpStatus: number|null}}
 */
function mapAuthenticateResult(authenticateResult) {
  if (typeof authenticateResult !== 'string' || !authenticateResult.startsWith('ERROR')) {
    return { isError: false, ncpErrorCode: null, httpStatus: null };
  }
  const match = authenticateResult.match(/\|(\d{4})/);
  const ncpErrorCode = match ? match[1] : null;
  const httpStatus = (ncpErrorCode && AUTHENTICATE_ERROR_STATUS[Number(ncpErrorCode)]) || 502;
  return { isError: true, ncpErrorCode, httpStatus };
}

/**
 * Map a List XML error code to an HTTP status.
 * @param {string|number} code - NCP List error code from the statementlist XML.
 * @returns {number} HTTP status (200 for 1205 - no records found).
 */
function mapListErrorStatus(code) {
  return LIST_ERROR_STATUS[Number(code)] || 502;
}

/**
 * Parse the NCP Warning header from a PDF retrieval response.
 * Format: "NCP: <code> <error message>", e.g. "NCP: 1001 Account # ... has exceeded ..."
 *
 * @param {string} warningHeader - Raw Warning header value.
 * @returns {{ncpErrorCode: string|null, httpStatus: number}}
 */
function mapPdfWarning(warningHeader) {
  const match = typeof warningHeader === 'string' && warningHeader.match(/NCP:\s*(\d{4})/);
  const ncpErrorCode = match ? match[1] : null;
  const httpStatus = (ncpErrorCode && PDF_ERROR_STATUS[Number(ncpErrorCode)]) || 502;
  return { ncpErrorCode, httpStatus };
}

module.exports = {
  AUTHENTICATE_ERROR_STATUS,
  LIST_ERROR_STATUS,
  PDF_ERROR_STATUS,
  buildErrorResponse,
  mapAuthenticateResult,
  mapListErrorStatus,
  mapPdfWarning,
  GENERIC_DETAIL,
  EXPIRED_DETAIL
};
