'use strict';

const express = require('express');
const bodyParser = require('body-parser');
const { handleList, handleRetrieve } = require('./handlers');
const { ROUTES } = require('./routes');

/**
 * Express application exposing the exact consumer paths from the enterprise
 * contract. Used for local development and unit tests; production traffic is
 * served by AWS API Gateway + Lambda (see lambda.js).
 */
const app = express();
app.use(bodyParser.json({ limit: '5mb' }));

for (const route of ROUTES) {
  app.post(route.path, route.action === 'list' ? handleList : handleRetrieve);
}

const PORT = process.env.PORT || 3000;
if (require.main === module) {
  app.listen(PORT, () => {
    // eslint-disable-next-line no-console
    console.log(`Statement Archive API listening on ${PORT}`);
  });
}

module.exports = app;
