'use strict';

/**
 * Minimal structured logger for CloudWatch.
 *
 * Security rules (BMO data policy / NCP spec):
 * - Never log NCP password, shared secret, hash, or token.
 * - Never log PDF bytes.
 * - Mask account numbers and statement keys.
 */

/** Mask a sensitive value, keeping only the last four characters. */
function mask(value) {
  if (value === undefined || value === null) {
    return value;
  }
  const text = String(value);
  if (text.length <= 4) {
    return '****';
  }
  return `****${text.slice(-4)}`;
}

function log(level, message, fields = {}) {
  const entry = { level, message, timestamp: new Date().toISOString(), ...fields };
  // eslint-disable-next-line no-console
  console[level === 'error' ? 'error' : 'log'](JSON.stringify(entry));
}

module.exports = {
  mask,
  info: (message, fields) => log('info', message, fields),
  warn: (message, fields) => log('warn', message, fields),
  error: (message, fields) => log('error', message, fields)
};
