'use strict';

const { parseStringPromise } = require('xml2js');

/**
 * Request/response field mapping between the consumer contract (legacy +
 * BIAN paths) and the NCP backend, per the enterprise Swagger and the NCP
 * Direct Access specification.
 */

/** Convert an ISO 8601 date (yyyy-mm-dd) to the NCP yyyymmdd format. */
function isoDateToYyyymmdd(value) {
  if (!value) {
    return '';
  }
  return String(value).replace(/-/g, '');
}

/** Convert an NCP statement date (MM/DD/YYYY) to ISO 8601 (yyyy-mm-dd). */
function mmddyyyyToIsoDate(value) {
  if (!value || !/^\d{2}\/\d{2}\/\d{4}$/.test(value)) {
    return value;
  }
  const [month, day, year] = value.split('/');
  return `${year}-${month}-${day}`;
}

/**
 * Normalize the consumer operationName to the exact NCP backend operation name.
 *
 * Legacy contract values: getAccountPDF / getAccountPDFInline (camelCase).
 * BIAN contract enum:     GetAccountPDF / GetAccountPDFinline (PascalCase).
 *
 * @param {string} operationName - Consumer-provided operation name.
 * @param {{legacy: boolean}} options - Legacy paths accept both casings;
 *   BIAN paths accept only the strict enum.
 * @returns {'GetAccountPDF'|'GetAccountPDFinline'|null}
 */
function normalizeOperationName(operationName, { legacy } = { legacy: false }) {
  const strict = {
    GetAccountPDF: 'GetAccountPDF',
    GetAccountPDFinline: 'GetAccountPDFinline'
  };
  const legacyAliases = {
    getAccountPDF: 'GetAccountPDF',
    getAccountPDFInline: 'GetAccountPDFinline',
    GetAccountPDFInline: 'GetAccountPDFinline'
  };
  if (strict[operationName]) {
    return strict[operationName];
  }
  if (legacy && legacyAliases[operationName]) {
    return legacyAliases[operationName];
  }
  return null;
}

/**
 * Parse the NCP statementlist XML returned by the List operation.
 *
 * @param {string} xml - Raw ListResult XML string.
 * @returns {Promise<{errorCode: string|null, statements: object[]}>}
 *   statements keep the exact NCP element names (date, description, key,
 *   product, and optional account / flexfield1-flexfield6).
 */
async function parseStatementListXml(xml) {
  const parsed = await parseStringPromise(xml, { explicitArray: false, trim: true });
  const statementlist = parsed && parsed.statementlist;
  if (!statementlist) {
    return { errorCode: null, statements: [] };
  }
  if (statementlist.error) {
    return { errorCode: String(statementlist.error.code || ''), statements: [] };
  }
  if (!statementlist.statement) {
    return { errorCode: null, statements: [] };
  }
  const entries = Array.isArray(statementlist.statement)
    ? statementlist.statement
    : [statementlist.statement];
  return { errorCode: null, statements: entries };
}

/** Build the legacy productResponse (exact legacy field names: date, key). */
function toProductResponse(statements) {
  return {
    result: { code: '200', status: 'SUCCESS', messages: [] },
    statementList: {
      statements: statements.map((entry) => ({
        date: entry.date,
        description: entry.description,
        key: entry.key,
        product: entry.product
      }))
    }
  };
}

/** Build the BIAN ListStatementResponse (statementKey, ISO statementDate). */
function toListStatementResponse(statements) {
  return {
    result: { code: '200', status: 'SUCCESS', messages: [] },
    statements: statements.map((entry) => {
      const mapped = {
        statementKey: entry.key,
        statementDate: mmddyyyyToIsoDate(entry.date),
        description: entry.description,
        product: entry.product
      };
      if (entry.account !== undefined) {
        mapped.account = entry.account;
      }
      for (let i = 1; i <= 6; i += 1) {
        const value = entry[`flexfield${i}`];
        if (value !== undefined) {
          mapped[`flexField${i}`] = value;
        }
      }
      return mapped;
    })
  };
}

/** Build the legacy streamingResponse wrapping the PDF bytes as base64. */
function toStreamingResponse(pdfBuffer) {
  const base64 = Buffer.isBuffer(pdfBuffer)
    ? pdfBuffer.toString('base64')
    : Buffer.from(pdfBuffer || '').toString('base64');
  return {
    result: { code: '200', status: 'SUCCESS', messages: [] },
    statementsPDF: base64
  };
}

module.exports = {
  isoDateToYyyymmdd,
  mmddyyyyToIsoDate,
  normalizeOperationName,
  parseStatementListXml,
  toProductResponse,
  toListStatementResponse,
  toStreamingResponse
};
