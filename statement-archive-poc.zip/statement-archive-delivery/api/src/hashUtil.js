'use strict';

const crypto = require('crypto');

/**
 * Ordered Authenticate parameters 1-10 per the NCP Direct Access specification.
 * (Parameter 11 clientIpAddress and parameter 12 hash are NOT part of the
 * hash input; only parameters 1-10 are concatenated.)
 */
const HASH_PARAMETER_ORDER = [
  'clientId',
  'userId',
  'password',
  'account',
  'startDate',
  'endDate',
  'product',
  'flexField1',
  'flexField2',
  'flexField3'
];

/**
 * Calculate the SHA-256 hash for the NCP Authenticate operation.
 *
 * Per the specification:
 * - Concatenate parameters 1-10 in order.
 * - If an optional parameter is not used, omit it from the string.
 * - Append the Shared Secret.
 * - Calculate a SHA-256 hash of the string (hex encoded).
 *
 * When calling with multiple pipe-delimited account numbers, the entire
 * pipe-delimited string must be used (the caller passes it as `account`).
 *
 * @param {object} params - Authenticate parameters keyed by NCP parameter name.
 * @param {string} sharedSecret - The NCP shared secret (never logged, never sent).
 * @returns {string} lowercase hex SHA-256 digest.
 */
function buildAuthenticateHash(params, sharedSecret) {
  if (!sharedSecret) {
    throw new Error('sharedSecret is required to calculate the Authenticate hash');
  }
  const concatenated = HASH_PARAMETER_ORDER
    .map((name) => params[name])
    .filter((value) => value !== undefined && value !== null && value !== '')
    .join('');
  return crypto
    .createHash('sha256')
    .update(concatenated + sharedSecret, 'utf8')
    .digest('hex');
}

module.exports = { buildAuthenticateHash, HASH_PARAMETER_ORDER };
