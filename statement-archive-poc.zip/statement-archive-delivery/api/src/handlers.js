'use strict';

const service = require('./service');
const logger = require('./logger');
const { buildErrorResponse } = require('./errorMapping');
const { REQUIRED_HEADERS } = require('./routes');

/**
 * Express adapters over the protocol-agnostic service layer.
 * Production traffic uses lambda.js; this app serves local dev and tests.
 */

/** Return the enterprise headers missing from the request. */
function getMissingRequiredHeaders(headers) {
  return REQUIRED_HEADERS.filter((name) => !headers[name]);
}

/**
 * Build the enterprise response headers. When x-fapi-interaction-id is not
 * supplied its value is the same as x-request-id (per contract).
 */
function buildResponseHeaders(requestHeaders) {
  const responseHeaders = {};
  if (requestHeaders['x-request-id']) {
    responseHeaders['x-request-id'] = requestHeaders['x-request-id'];
    responseHeaders['x-fapi-interaction-id'] =
      requestHeaders['x-fapi-interaction-id'] || requestHeaders['x-request-id'];
  } else if (requestHeaders['x-fapi-interaction-id']) {
    responseHeaders['x-fapi-interaction-id'] = requestHeaders['x-fapi-interaction-id'];
  }
  return responseHeaders;
}

/** Resolve the correlation id used in all internal logs. */
function getCorrelationId(headers) {
  return headers['x-fapi-interaction-id'] || headers['x-request-id'] || 'unknown';
}

function buildContext(req) {
  return {
    legacy: req.path.startsWith('/document-services/mortgage-statement/'),
    instance: req.originalUrl || req.path,
    correlationId: getCorrelationId(req.headers)
  };
}

/** Send a normalized service result over Express. */
function sendResult(req, res, result) {
  res.set(buildResponseHeaders(req.headers));
  if (result.pdf) {
    res.set('Content-Type', 'application/pdf');
    res.set('Content-Disposition', result.contentDisposition);
    return res.status(result.statusCode).send(result.pdf);
  }
  return res.status(result.statusCode).json(result.json);
}

/** Shared pre-processing: enterprise header validation. */
function rejectIfMissingHeaders(req, res) {
  const missing = getMissingRequiredHeaders(req.headers);
  if (missing.length === 0) {
    return false;
  }
  res.set(buildResponseHeaders(req.headers));
  res.status(400).json(
    buildErrorResponse({
      status: 400,
      instance: req.originalUrl || req.path,
      detail: `Missing required headers: ${missing.join(', ')}`
    })
  );
  return true;
}

/** Shared pre-processing: enforce application/json request media type (415). */
function rejectIfUnsupportedMediaType(req, res) {
  const contentType = req.headers['content-type'];
  if (!contentType || contentType.toLowerCase().includes('application/json')) {
    return false;
  }
  res.set(buildResponseHeaders(req.headers));
  res.status(415).json(
    buildErrorResponse({
      status: 415,
      instance: req.originalUrl || req.path,
      detail: 'Request content type must be application/json'
    })
  );
  return true;
}

/** POST list paths (legacy + BIAN). */
async function handleList(req, res) {
  const context = buildContext(req);
  try {
    if (rejectIfMissingHeaders(req, res) || rejectIfUnsupportedMediaType(req, res)) {
      return;
    }
    const result = await service.listStatement(req.body || {}, context);
    sendResult(req, res, result);
  } catch (error) {
    logger.error('handleList unexpected error', {
      correlationId: context.correlationId,
      error: error && error.message
    });
    sendResult(req, res, {
      statusCode: 502,
      json: buildErrorResponse({ status: 502, instance: context.instance })
    });
  }
}

/** POST retrieve paths (legacy + BIAN). */
async function handleRetrieve(req, res) {
  const context = buildContext(req);
  try {
    if (rejectIfMissingHeaders(req, res) || rejectIfUnsupportedMediaType(req, res)) {
      return;
    }
    const result = await service.retrieveStatement(req.body || {}, context);
    sendResult(req, res, result);
  } catch (error) {
    logger.error('handleRetrieve unexpected error', {
      correlationId: context.correlationId,
      error: error && error.message
    });
    sendResult(req, res, {
      statusCode: 502,
      json: buildErrorResponse({ status: 502, instance: context.instance })
    });
  }
}

module.exports = {
  handleList,
  handleRetrieve,
  // Exported for unit tests.
  getMissingRequiredHeaders,
  buildResponseHeaders,
  getCorrelationId
};
