'use strict';

const service = require('./service');
const logger = require('./logger');
const { buildErrorResponse } = require('./errorMapping');
const { ROUTES, REQUIRED_HEADERS } = require('./routes');

/**
 * AWS Lambda entry point (API Gateway Lambda proxy integration).
 * API Gateway must enable binary media type application/pdf so
 * isBase64Encoded PDF responses are decoded for the consumer.
 */

/** Lower-case all header names (API Gateway casing is not guaranteed). */
function normalizeHeaders(headers) {
  const normalized = {};
  for (const [name, value] of Object.entries(headers || {})) {
    normalized[name.toLowerCase()] = value;
  }
  return normalized;
}

function buildResponseHeaders(requestHeaders) {
  const responseHeaders = {};
  if (requestHeaders['x-request-id']) {
    responseHeaders['x-request-id'] = requestHeaders['x-request-id'];
    responseHeaders['x-fapi-interaction-id'] =
      requestHeaders['x-fapi-interaction-id'] || requestHeaders['x-request-id'];
  } else if (requestHeaders['x-fapi-interaction-id']) {
    responseHeaders['x-fapi-interaction-id'] = requestHeaders['x-fapi-interaction-id'];
  }
  return responseHeaders;
}

function jsonResponse(statusCode, body, headers) {
  return {
    statusCode,
    headers: { ...headers, 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
    isBase64Encoded: false
  };
}

/** Lambda proxy handler for all four consumer operations. */
async function handler(event) {
  const headers = normalizeHeaders(event.headers);
  const responseHeaders = buildResponseHeaders(headers);
  const path = event.path || (event.requestContext && event.requestContext.path) || '';
  const correlationId = headers['x-fapi-interaction-id'] || headers['x-request-id'] || 'unknown';

  const route = ROUTES.find((candidate) => candidate.path === path);
  if (!route || (event.httpMethod && event.httpMethod !== 'POST')) {
    return jsonResponse(
      404,
      buildErrorResponse({ status: 404, instance: path, detail: 'Resource not found' }),
      responseHeaders
    );
  }

  const contentType = headers['content-type'];
  if (contentType && !contentType.toLowerCase().includes('application/json')) {
    return jsonResponse(
      415,
      buildErrorResponse({
        status: 415,
        instance: path,
        detail: 'Request content type must be application/json'
      }),
      responseHeaders
    );
  }

  const missing = REQUIRED_HEADERS.filter((name) => !headers[name]);
  if (missing.length > 0) {
    return jsonResponse(
      400,
      buildErrorResponse({
        status: 400,
        instance: path,
        detail: `Missing required headers: ${missing.join(', ')}`
      }),
      responseHeaders
    );
  }

  let body = {};
  if (event.body) {
    try {
      const raw = event.isBase64Encoded
        ? Buffer.from(event.body, 'base64').toString('utf8')
        : event.body;
      body = JSON.parse(raw);
    } catch (error) {
      return jsonResponse(
        400,
        buildErrorResponse({ status: 400, instance: path, detail: 'Request body must be valid JSON' }),
        responseHeaders
      );
    }
  }

  const context = { legacy: route.legacy, instance: path, correlationId };

  try {
    const result =
      route.action === 'list'
        ? await service.listStatement(body, context)
        : await service.retrieveStatement(body, context);

    if (result.pdf) {
      // Binary PDF via Lambda proxy: base64 body + isBase64Encoded.
      return {
        statusCode: result.statusCode,
        headers: {
          ...responseHeaders,
          'Content-Type': 'application/pdf',
          'Content-Disposition': result.contentDisposition
        },
        body: result.pdf.toString('base64'),
        isBase64Encoded: true
      };
    }
    return jsonResponse(result.statusCode, result.json, responseHeaders);
  } catch (error) {
    logger.error('Lambda handler unexpected error', {
      correlationId,
      operationId: route.operationId,
      error: error && error.message
    });
    return jsonResponse(
      502,
      buildErrorResponse({ status: 502, instance: path }),
      responseHeaders
    );
  }
}

module.exports = { handler };
