'use strict';

/**
 * Configuration for the Statement Archive API facade.
 * NCP credentials are secrets: AWS Secrets Manager in AWS, env vars locally.
 */

const path = require('path');

const ENDPOINTS = {
  // Production default: WSDL bundled with the deployment package so cold
  // starts never depend on fetching ?wsdl from an IP-allowlisted endpoint.
  NCP_SOAP_WSDL:
    process.env.NCP_SOAP_WSDL || path.join(__dirname, '..', 'wsdl', 'Statements.xml'),
  NCP_SOAP_ENDPOINT:
    process.env.NCP_SOAP_ENDPOINT ||
    'https://directaccess.ncpsolutions.com:8443/AvailableImages/Statements.svc',
  NCP_REST_BASE:
    process.env.NCP_REST_BASE ||
    'https://directaccess.ncpsolutions.com:8443/ImageRetrieval/Repository.svc',
  HTTP_TIMEOUT_MS: parseInt(process.env.HTTP_TIMEOUT_MS || '20000', 10),
  MAX_PDF_BYTES: parseInt(process.env.MAX_PDF_BYTES || String(50 * 1024 * 1024), 10)
};

let cachedCredentials = null;

/**
 * Resolve NCP credentials: Secrets Manager (NCP_SECRET_ID) or env fallback.
 * @returns {Promise<{clientId, userId, password, sharedSecret}>}
 */
async function getCredentials() {
  if (cachedCredentials) {
    return cachedCredentials;
  }

  if (process.env.NCP_SECRET_ID) {
    const { SecretsManagerClient, GetSecretValueCommand } = require('@aws-sdk/client-secrets-manager');
    const client = new SecretsManagerClient({});
    const response = await client.send(
      new GetSecretValueCommand({ SecretId: process.env.NCP_SECRET_ID })
    );
    const secret = JSON.parse(response.SecretString);
    cachedCredentials = {
      clientId: secret.clientId,
      userId: secret.userId,
      password: secret.password,
      sharedSecret: secret.sharedSecret
    };
    return cachedCredentials;
  }

  const fromEnv = {
    clientId: process.env.NCP_CLIENT_ID,
    userId: process.env.NCP_USER_ID,
    password: process.env.NCP_PASSWORD,
    sharedSecret: process.env.NCP_SHARED_SECRET
  };

  const missing = Object.keys(fromEnv).filter((key) => !fromEnv[key]);
  if (missing.length > 0) {
    throw new Error(`Missing NCP credential configuration: ${missing.join(', ')}`);
  }

  cachedCredentials = fromEnv;
  return cachedCredentials;
}

/** Reset the in-memory credential cache (tests and secret rotation). */
function resetCredentialCache() {
  cachedCredentials = null;
}

module.exports = { ...ENDPOINTS, getCredentials, resetCredentialCache };
