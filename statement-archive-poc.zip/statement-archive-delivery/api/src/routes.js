'use strict';

/**
 * Consumer route table (exact paths from the enterprise contract).
 * Legacy paths are backward-compatible; BIAN paths are additive.
 */
const ROUTES = [
  {
    path: '/document-services/mortgage-statement/list/get',
    operationId: 'listMortgageStatement',
    action: 'list',
    legacy: true
  },
  {
    path: '/document-services/mortgage-statement/stream/get',
    operationId: 'retrieveMortgageStmt',
    action: 'retrieve',
    legacy: true
  },
  {
    path: '/statement-archive/v1/statements/list',
    operationId: 'ListStatement',
    action: 'list',
    legacy: false
  },
  {
    path: '/statement-archive/v1/statements/retrieve',
    operationId: 'RetrieveStatement',
    action: 'retrieve',
    legacy: false
  }
];

/** Required enterprise request headers (per the enterprise Swagger contract). */
const REQUIRED_HEADERS = ['x-request-id', 'x-api-key', 'x-fapi-financial-id', 'x-app-cat-id'];

module.exports = { ROUTES, REQUIRED_HEADERS };
