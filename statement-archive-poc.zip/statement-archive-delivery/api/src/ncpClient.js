'use strict';

const axios = require('axios');
const config = require('./config');

/**
 * NCP Direct Access backend client.
 * SOAP: Authenticate, List (Statements.svc, document/literal).
 * REST: GET {base}/{GetAccountPDF|GetAccountPDFinline}/{documentKey}
 *       with X-NCP-AUTH header; errors signalled via Warning header + error PDF.
 */

let soapClientPromise = null;

/** Create (and cache) the node-soap client for the Statements service. */
function getSoapClient() {
  if (!soapClientPromise) {
    const soap = require('soap');
    soapClientPromise = soap
      .createClientAsync(config.NCP_SOAP_WSDL, { endpoint: config.NCP_SOAP_ENDPOINT })
      .catch((error) => {
        soapClientPromise = null;
        throw error;
      });
  }
  return soapClientPromise;
}

/**
 * Call the NCP Authenticate SOAP operation (named-args object per WSDL).
 * @returns {Promise<string>} token or "ERROR: Authentication Failure|<code> ..."
 */
async function authenticate(authParams) {
  const client = await getSoapClient();
  const args = {
    clientId: authParams.clientId || '',
    userId: authParams.userId || '',
    password: authParams.password || '',
    account: authParams.account || '',
    startDate: authParams.startDate || '',
    endDate: authParams.endDate || '',
    product: authParams.product || '',
    flexField1: authParams.flexField1 || '',
    flexField2: authParams.flexField2 || '',
    flexField3: authParams.flexField3 || '',
    clientIpAddress: authParams.clientIpAddress || '',
    hash: authParams.hash || ''
  };
  const [result] = await client.AuthenticateAsync(args, { timeout: config.HTTP_TIMEOUT_MS });
  return result && typeof result.AuthenticateResult === 'string'
    ? result.AuthenticateResult
    : '';
}

/**
 * Call the NCP List SOAP operation.
 * @param {string} token - Hexadecimal token from Authenticate (30-minute TTL).
 * @returns {Promise<string>} statementlist XML string.
 */
async function listStatements(token) {
  const client = await getSoapClient();
  const [result] = await client.ListAsync({ token }, { timeout: config.HTTP_TIMEOUT_MS });
  return result && typeof result.ListResult === 'string' ? result.ListResult : '';
}

/**
 * Call the NCP Image Retrieval REST operation.
 * @returns {Promise<{status: number, headers: object, data: Buffer}>}
 */
async function getPdf(operationName, documentKey, accountNumber) {
  const url = `${config.NCP_REST_BASE}/${operationName}/${encodeURIComponent(documentKey)}`;
  const response = await axios.get(url, {
    responseType: 'arraybuffer',
    timeout: config.HTTP_TIMEOUT_MS,
    maxContentLength: config.MAX_PDF_BYTES,
    maxBodyLength: config.MAX_PDF_BYTES,
    headers: { 'X-NCP-AUTH': accountNumber },
    validateStatus: () => true
  });
  return {
    status: response.status,
    headers: response.headers || {},
    data: Buffer.from(response.data || '')
  };
}

/** Reset the cached SOAP client (used by tests). */
function resetSoapClient() {
  soapClientPromise = null;
}

module.exports = { authenticate, listStatements, getPdf, getSoapClient, resetSoapClient };
