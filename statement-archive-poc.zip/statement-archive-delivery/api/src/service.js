'use strict';

const config = require('./config');
const ncpClient = require('./ncpClient');
const logger = require('./logger');
const { buildAuthenticateHash } = require('./hashUtil');
const {
  buildErrorResponse,
  mapAuthenticateResult,
  mapListErrorStatus,
  mapPdfWarning,
  EXPIRED_DETAIL
} = require('./errorMapping');
const {
  isoDateToYyyymmdd,
  normalizeOperationName,
  parseStatementListXml,
  toProductResponse,
  toListStatementResponse,
  toStreamingResponse
} = require('./mappers');

/**
 * Protocol-agnostic Statement Archive service layer.
 * Results: { statusCode, json } or { statusCode, pdf, contentDisposition }.
 */

/**
 * ListStatement / listMortgageStatement:
 * Authenticate (SOAP) -> List (SOAP) -> XML parsing -> consumer JSON mapping.
 */
async function listStatement(body = {}, context) {
  const { legacy, instance, correlationId } = context;

  // Legacy field: account (yyyymmdd dates). BIAN field: accountNumber (ISO dates).
  const account = legacy ? body.account : body.accountNumber;
  if (!account) {
    return {
      statusCode: 400,
      json: buildErrorResponse({
        status: 400,
        instance,
        detail: `Missing required field: ${legacy ? 'account' : 'accountNumber'}`
      })
    };
  }
  if (String(account).split('|').length > 25) {
    return {
      statusCode: 400,
      json: buildErrorResponse({
        status: 400,
        instance,
        detail: 'A maximum of 25 account numbers may be requested per call'
      })
    };
  }

  // Strict date-format validation: legacy yyyymmdd, BIAN ISO 8601.
  const datePattern = legacy ? /^\d{8}$/ : /^\d{4}-\d{2}-\d{2}$/;
  for (const field of ['startDate', 'endDate']) {
    const value = body[field];
    if (value !== undefined && value !== null && value !== '' && !datePattern.test(String(value))) {
      return {
        statusCode: 400,
        json: buildErrorResponse({
          status: 400,
          instance,
          detail: `${field} must be in ${legacy ? 'yyyymmdd' : 'yyyy-mm-dd'} format`
        })
      };
    }
  }

  const credentials = await config.getCredentials();
  const authParams = {
    clientId: credentials.clientId,
    userId: credentials.userId,
    password: credentials.password,
    account: String(account),
    startDate: legacy ? body.startDate || '' : isoDateToYyyymmdd(body.startDate),
    endDate: legacy ? body.endDate || '' : isoDateToYyyymmdd(body.endDate),
    product: body.product || '',
    flexField1: body.flexField1 || '',
    flexField2: body.flexField2 || '',
    flexField3: body.flexField3 || '',
    clientIpAddress: body.clientIpAddress || ''
  };
  // Parameter 12: SHA-256 of parameters 1-10 + shared secret (server-side only).
  authParams.hash = buildAuthenticateHash(authParams, credentials.sharedSecret);

  // Backend call 1: Authenticate (SOAP).
  const authenticateResult = await ncpClient.authenticate(authParams);
  const authError = mapAuthenticateResult(authenticateResult);
  if (authError.isError) {
    logger.error('NCP Authenticate failure', {
      correlationId,
      ncpErrorCode: authError.ncpErrorCode,
      account: logger.mask(account)
    });
    return {
      statusCode: authError.httpStatus,
      json: buildErrorResponse({
        status: authError.httpStatus,
        instance,
        ncpErrorCode: authError.ncpErrorCode
      })
    };
  }

  // Backend call 2: List (SOAP) with the 30-minute token.
  const listXml = await ncpClient.listStatements(authenticateResult);
  const { errorCode, statements } = await parseStatementListXml(listXml);

  if (errorCode) {
    // 1205 "No records found" is not an error: 200 with an empty array.
    if (errorCode === '1205') {
      return {
        statusCode: 200,
        json: legacy ? toProductResponse([]) : toListStatementResponse([])
      };
    }
    const status = mapListErrorStatus(errorCode);
    logger.error('NCP List failure', {
      correlationId,
      ncpErrorCode: errorCode,
      account: logger.mask(account)
    });
    return {
      statusCode: status,
      json: buildErrorResponse({
        status,
        instance,
        ncpErrorCode: errorCode,
        detail: errorCode === '1200' ? EXPIRED_DETAIL : undefined
      })
    };
  }

  logger.info('ListStatement success', {
    correlationId,
    statementCount: statements.length,
    account: logger.mask(account)
  });
  return {
    statusCode: 200,
    json: legacy ? toProductResponse(statements) : toListStatementResponse(statements)
  };
}

/**
 * RetrieveStatement / retrieveMortgageStmt:
 * routes to GetAccountPDF or GetAccountPDFinline by operationName,
 * inspects the NCP Warning header, suppresses backend error PDFs.
 */
async function retrieveStatement(body = {}, context) {
  const { legacy, instance, correlationId } = context;

  // Legacy field: encryptedKey. BIAN field: statementKey.
  const documentKey = legacy ? body.encryptedKey : body.statementKey;
  const accountNumber = body.accountNumber;
  const operationName = normalizeOperationName(body.operationName, { legacy });

  const missing = [];
  if (!documentKey) missing.push(legacy ? 'encryptedKey' : 'statementKey');
  if (!accountNumber) missing.push('accountNumber');
  if (!body.operationName) missing.push('operationName');
  if (missing.length > 0) {
    return {
      statusCode: 400,
      json: buildErrorResponse({
        status: 400,
        instance,
        detail: `Missing required fields: ${missing.join(', ')}`
      })
    };
  }
  if (!operationName) {
    return {
      statusCode: 400,
      json: buildErrorResponse({
        status: 400,
        instance,
        detail: legacy
          ? 'operationName must be getAccountPDF or getAccountPDFInline'
          : 'operationName must be GetAccountPDF or GetAccountPDFinline'
      })
    };
  }

  const backendResponse = await ncpClient.getPdf(operationName, documentKey, accountNumber);
  const warningHeader =
    backendResponse.headers.warning || backendResponse.headers.Warning || null;

  // NCP signals errors via the Warning header plus an error PDF body.
  // The error PDF must never be returned to the consumer.
  if (warningHeader) {
    const { ncpErrorCode, httpStatus } = mapPdfWarning(warningHeader);
    logger.error('NCP PDF retrieval warning', {
      correlationId,
      ncpErrorCode,
      operationName,
      accountNumber: logger.mask(accountNumber),
      statementKey: logger.mask(documentKey)
    });
    return {
      statusCode: httpStatus,
      json: buildErrorResponse({
        status: httpStatus,
        instance,
        ncpErrorCode,
        detail: ncpErrorCode === '1001' ? EXPIRED_DETAIL : undefined
      })
    };
  }

  if (backendResponse.status < 200 || backendResponse.status >= 300) {
    logger.error('NCP PDF retrieval HTTP failure', {
      correlationId,
      backendStatus: backendResponse.status,
      operationName,
      accountNumber: logger.mask(accountNumber)
    });
    return {
      statusCode: 502,
      json: buildErrorResponse({ status: 502, instance })
    };
  }

  logger.info('RetrieveStatement success', {
    correlationId,
    operationName,
    accountNumber: logger.mask(accountNumber),
    contentLength: backendResponse.data.length
  });

  if (legacy) {
    // Legacy contract: JSON streamingResponse with base64 statementsPDF.
    return { statusCode: 200, json: toStreamingResponse(backendResponse.data) };
  }

  // BIAN contract: raw application/pdf binary.
  return {
    statusCode: 200,
    pdf: backendResponse.data,
    contentDisposition: operationName === 'GetAccountPDFinline' ? 'inline' : 'attachment'
  };
}

module.exports = { listStatement, retrieveStatement };
