'use strict';

require('./helpers');
const { expect } = require('chai');
const {
  isoDateToYyyymmdd,
  mmddyyyyToIsoDate,
  normalizeOperationName,
  parseStatementListXml,
  toProductResponse,
  toListStatementResponse,
  toStreamingResponse
} = require('../src/mappers');
const { SAMPLE_STATEMENT_LIST_XML, statementListErrorXml } = require('./helpers');

describe('mappers', () => {
  describe('date conversion', () => {
    it('converts ISO 8601 dates to the NCP yyyymmdd format', () => {
      expect(isoDateToYyyymmdd('2014-01-01')).to.equal('20140101');
      expect(isoDateToYyyymmdd('')).to.equal('');
      expect(isoDateToYyyymmdd(undefined)).to.equal('');
    });

    it('converts NCP MM/DD/YYYY statement dates to ISO 8601', () => {
      expect(mmddyyyyToIsoDate('09/30/2014')).to.equal('2014-09-30');
      expect(mmddyyyyToIsoDate('not-a-date')).to.equal('not-a-date');
    });
  });

  describe('normalizeOperationName', () => {
    it('accepts the strict BIAN enum GetAccountPDF / GetAccountPDFinline on BIAN paths', () => {
      expect(normalizeOperationName('GetAccountPDF', { legacy: false })).to.equal('GetAccountPDF');
      expect(normalizeOperationName('GetAccountPDFinline', { legacy: false })).to.equal('GetAccountPDFinline');
    });

    it('rejects legacy camelCase values on BIAN paths', () => {
      expect(normalizeOperationName('getAccountPDF', { legacy: false })).to.equal(null);
      expect(normalizeOperationName('getAccountPDFInline', { legacy: false })).to.equal(null);
    });

    it('accepts legacy camelCase values on legacy paths and normalizes to the backend name', () => {
      expect(normalizeOperationName('getAccountPDF', { legacy: true })).to.equal('GetAccountPDF');
      expect(normalizeOperationName('getAccountPDFInline', { legacy: true })).to.equal('GetAccountPDFinline');
    });

    it('rejects unknown operation names', () => {
      expect(normalizeOperationName('DeleteAccountPDF', { legacy: true })).to.equal(null);
      expect(normalizeOperationName(undefined, { legacy: true })).to.equal(null);
    });
  });

  describe('parseStatementListXml', () => {
    it('parses statements with the exact NCP element names', async () => {
      const { errorCode, statements } = await parseStatementListXml(SAMPLE_STATEMENT_LIST_XML);
      expect(errorCode).to.equal(null);
      expect(statements).to.have.lengthOf(2);
      expect(statements[0]).to.deep.include({
        date: '09/30/2014',
        description: 'Monthly Statement',
        key: '6754325468636748593261506F37',
        product: '00001000'
      });
    });

    it('parses a single-statement list into an array', async () => {
      const xml =
        '<statementlist><statement><date>09/30/2014</date><description>Monthly Statement</description><key>K1</key><product>P1</product></statement></statementlist>';
      const { statements } = await parseStatementListXml(xml);
      expect(statements).to.have.lengthOf(1);
    });

    it('extracts the NCP error code from an error statementlist', async () => {
      const { errorCode, statements } = await parseStatementListXml(
        statementListErrorXml('1205', 'No Records Found')
      );
      expect(errorCode).to.equal('1205');
      expect(statements).to.have.lengthOf(0);
    });

    it('parses optional account and flexfield elements when configured', async () => {
      const xml =
        '<statementlist><statement><account>11111111</account><date>09/30/2017</date>' +
        '<description>Monthly Statement</description><key>K1</key><product>00001000</product>' +
        '<flexfield1>A</flexfield1><flexfield2>BB</flexfield2><flexfield3>CCC</flexfield3>' +
        '<flexfield4></flexfield4><flexfield5></flexfield5><flexfield6>1234</flexfield6>' +
        '</statement></statementlist>';
      const { statements } = await parseStatementListXml(xml);
      expect(statements[0].account).to.equal('11111111');
      expect(statements[0].flexfield6).to.equal('1234');
    });
  });

  describe('response mapping', () => {
    const entries = [
      { date: '09/30/2014', description: 'Monthly Statement', key: 'K1', product: '00001000' }
    ];

    it('maps to the legacy productResponse with legacy field names (date, key)', () => {
      const response = toProductResponse(entries);
      expect(response.result).to.deep.equal({ code: '200', status: 'SUCCESS', messages: [] });
      expect(response.statementList.statements[0]).to.deep.equal({
        date: '09/30/2014',
        description: 'Monthly Statement',
        key: 'K1',
        product: '00001000'
      });
    });

    it('maps to the BIAN ListStatementResponse with statementKey and ISO statementDate', () => {
      const response = toListStatementResponse(entries);
      expect(response.statements[0]).to.deep.equal({
        statementKey: 'K1',
        statementDate: '2014-09-30',
        description: 'Monthly Statement',
        product: '00001000'
      });
    });

    it('wraps PDF bytes as base64 in the legacy streamingResponse', () => {
      const pdf = Buffer.from('%PDF-1.4 sample');
      const response = toStreamingResponse(pdf);
      expect(response.statementsPDF).to.equal(pdf.toString('base64'));
      expect(response.result.status).to.equal('SUCCESS');
    });
  });
});
