'use strict';

const { enterpriseHeaders, SAMPLE_STATEMENT_LIST_XML, statementListErrorXml } = require('./helpers');
const crypto = require('crypto');
const { expect } = require('chai');
const sinon = require('sinon');
const request = require('supertest');

const app = require('../src/app');
const ncpClient = require('../src/ncpClient');
const config = require('../src/config');

describe('Statement Archive handlers (Express, legacy + BIAN paths)', () => {
  afterEach(() => {
    sinon.restore();
  });

  describe('ListStatement / listMortgageStatement', () => {
    it('legacy list: calls Authenticate then List and returns the legacy productResponse', async () => {
      const authenticateStub = sinon.stub(ncpClient, 'authenticate').resolves('4A6B7C8D9E0F');
      const listStub = sinon.stub(ncpClient, 'listStatements').resolves(SAMPLE_STATEMENT_LIST_XML);

      const response = await request(app)
        .post('/document-services/mortgage-statement/list/get')
        .set(enterpriseHeaders())
        .send({
          account: '11111111|22222222|33333333',
          startDate: '20140101',
          endDate: '20140930',
          product: '00001000'
        });

      expect(response.status).to.equal(200);
      expect(response.body.result).to.deep.equal({ code: '200', status: 'SUCCESS', messages: [] });
      expect(response.body.statementList.statements).to.have.lengthOf(2);
      expect(response.body.statementList.statements[0]).to.deep.equal({
        date: '09/30/2014',
        description: 'Monthly Statement',
        key: '6754325468636748593261506F37',
        product: '00001000'
      });
      // Orchestration order: Authenticate before List, token passed through.
      expect(authenticateStub.calledBefore(listStub)).to.equal(true);
      expect(listStub.firstCall.args[0]).to.equal('4A6B7C8D9E0F');
      // Legacy dates are passed to the backend unchanged (yyyymmdd).
      expect(authenticateStub.firstCall.args[0]).to.include({
        startDate: '20140101',
        endDate: '20140930'
      });
    });

    it('legacy list: computes the SHA-256 hash server-side from params 1-10 + shared secret', async () => {
      const authenticateStub = sinon.stub(ncpClient, 'authenticate').resolves('4A6B7C8D9E0F');
      sinon.stub(ncpClient, 'listStatements').resolves(SAMPLE_STATEMENT_LIST_XML);

      await request(app)
        .post('/document-services/mortgage-statement/list/get')
        .set(enterpriseHeaders())
        .send({ account: '11111111', startDate: '20140101', endDate: '20140930' });

      const sent = authenticateStub.firstCall.args[0];
      const expectedHash = crypto
        .createHash('sha256')
        .update(
          process.env.NCP_CLIENT_ID +
            process.env.NCP_USER_ID +
            process.env.NCP_PASSWORD +
            '11111111' +
            '20140101' +
            '20140930' +
            process.env.NCP_SHARED_SECRET,
          'utf8'
        )
        .digest('hex');
      expect(sent.hash).to.equal(expectedHash);
      expect(sent.clientId).to.equal(process.env.NCP_CLIENT_ID);
    });

    it('BIAN list: converts ISO dates to yyyymmdd and returns statementKey/statementDate names', async () => {
      const authenticateStub = sinon.stub(ncpClient, 'authenticate').resolves('4A6B7C8D9E0F');
      sinon.stub(ncpClient, 'listStatements').resolves(SAMPLE_STATEMENT_LIST_XML);

      const response = await request(app)
        .post('/statement-archive/v1/statements/list')
        .set(enterpriseHeaders({ 'x-fapi-interaction-id': 'interaction-1' }))
        .send({ accountNumber: '11111111', startDate: '2014-01-01', endDate: '2014-09-30' });

      expect(response.status).to.equal(200);
      expect(authenticateStub.firstCall.args[0]).to.include({
        account: '11111111',
        startDate: '20140101',
        endDate: '20140930'
      });
      expect(response.body.statements[0]).to.deep.equal({
        statementKey: '6754325468636748593261506F37',
        statementDate: '2014-09-30',
        description: 'Monthly Statement',
        product: '00001000'
      });
      expect(response.headers['x-fapi-interaction-id']).to.equal('interaction-1');
    });

    it('echoes x-request-id and defaults x-fapi-interaction-id to x-request-id', async () => {
      sinon.stub(ncpClient, 'authenticate').resolves('4A6B7C8D9E0F');
      sinon.stub(ncpClient, 'listStatements').resolves(SAMPLE_STATEMENT_LIST_XML);

      const response = await request(app)
        .post('/statement-archive/v1/statements/list')
        .set(enterpriseHeaders())
        .send({ accountNumber: '11111111' });

      expect(response.headers['x-request-id']).to.equal('req-0001');
      expect(response.headers['x-fapi-interaction-id']).to.equal('req-0001');
    });

    it('returns 400 with the enterprise errorResponse when a required header is missing', async () => {
      const response = await request(app)
        .post('/statement-archive/v1/statements/list')
        .set(enterpriseHeaders({ 'x-api-key': undefined }))
        .send({ accountNumber: '11111111' });

      expect(response.status).to.equal(400);
      expect(response.body).to.include.keys(['type', 'title', 'status', 'detail', 'instance']);
      expect(response.body.status).to.equal(400);
    });

    it('returns 400 when accountNumber is missing (BIAN) or account is missing (legacy)', async () => {
      const bian = await request(app)
        .post('/statement-archive/v1/statements/list')
        .set(enterpriseHeaders())
        .send({});
      expect(bian.status).to.equal(400);

      const legacy = await request(app)
        .post('/document-services/mortgage-statement/list/get')
        .set(enterpriseHeaders())
        .send({ accountNumber: '11111111' }); // wrong field name on legacy path
      expect(legacy.status).to.equal(400);
    });

    it('returns 415 when the request content type is not application/json', async () => {
      const response = await request(app)
        .post('/statement-archive/v1/statements/list')
        .set(enterpriseHeaders({ 'Content-Type': 'text/plain' }))
        .send('accountNumber=11111111');

      expect(response.status).to.equal(415);
      expect(response.body).to.include.keys(['type', 'title', 'status', 'detail', 'instance']);
      expect(response.body.status).to.equal(415);
    });

    it('returns 400 for invalid date formats (BIAN requires yyyy-mm-dd, legacy requires yyyymmdd)', async () => {
      const bian = await request(app)
        .post('/statement-archive/v1/statements/list')
        .set(enterpriseHeaders())
        .send({ accountNumber: '11111111', startDate: '2014/01/01' });
      expect(bian.status).to.equal(400);
      expect(bian.body.detail).to.include('yyyy-mm-dd');

      const legacy = await request(app)
        .post('/document-services/mortgage-statement/list/get')
        .set(enterpriseHeaders())
        .send({ account: '11111111', endDate: '2014-09-30' });
      expect(legacy.status).to.equal(400);
      expect(legacy.body.detail).to.include('yyyymmdd');
    });

    it('returns 400 when more than 25 pipe-delimited accounts are requested', async () => {
      const accounts = Array.from({ length: 26 }, (_, i) => `1000000${i}`).join('|');
      const response = await request(app)
        .post('/statement-archive/v1/statements/list')
        .set(enterpriseHeaders())
        .send({ accountNumber: accounts });
      expect(response.status).to.equal(400);
    });

    it('maps Authenticate failure 1199 to 502 and never exposes the raw NCP message', async () => {
      sinon
        .stub(ncpClient, 'authenticate')
        .resolves('ERROR: Authentication Failure|1199 No control record found for user ID 1234');

      const response = await request(app)
        .post('/statement-archive/v1/statements/list')
        .set(enterpriseHeaders())
        .send({ accountNumber: '11111111' });

      expect(response.status).to.equal(502);
      expect(response.body.resultDetails[0].detailCode).to.equal('1199');
      expect(JSON.stringify(response.body)).to.not.match(/No control record|Authentication Failure/);
    });

    it('maps Authenticate failure 1102 (hash mismatch) to 500', async () => {
      sinon.stub(ncpClient, 'authenticate').resolves('ERROR: Authentication Failure|1102 Hash mismatch');

      const response = await request(app)
        .post('/statement-archive/v1/statements/list')
        .set(enterpriseHeaders())
        .send({ accountNumber: '11111111' });

      expect(response.status).to.equal(500);
    });

    it('returns 200 with an empty statements array for List error 1205 (no records found)', async () => {
      sinon.stub(ncpClient, 'authenticate').resolves('4A6B7C8D9E0F');
      sinon.stub(ncpClient, 'listStatements').resolves(statementListErrorXml('1205', 'No Records Found'));

      const bian = await request(app)
        .post('/statement-archive/v1/statements/list')
        .set(enterpriseHeaders())
        .send({ accountNumber: '11111111' });
      expect(bian.status).to.equal(200);
      expect(bian.body.statements).to.deep.equal([]);
    });

    it('maps List error 1200 (token timed out) to 401 with a session-expired message', async () => {
      sinon.stub(ncpClient, 'authenticate').resolves('4A6B7C8D9E0F');
      sinon.stub(ncpClient, 'listStatements').resolves(statementListErrorXml('1200', 'Token timed out'));

      const response = await request(app)
        .post('/statement-archive/v1/statements/list')
        .set(enterpriseHeaders())
        .send({ accountNumber: '11111111' });

      expect(response.status).to.equal(401);
      expect(response.body.detail).to.match(/expired/i);
      expect(response.body.resultDetails[0].detailCode).to.equal('1200');
    });

    it('returns 502 with a sanitized errorResponse when the SOAP call throws', async () => {
      sinon.stub(ncpClient, 'authenticate').rejects(new Error('socket hang up'));

      const response = await request(app)
        .post('/statement-archive/v1/statements/list')
        .set(enterpriseHeaders())
        .send({ accountNumber: '11111111' });

      expect(response.status).to.equal(502);
      expect(JSON.stringify(response.body)).to.not.include('socket hang up');
    });
  });

  describe('RetrieveStatement / retrieveMortgageStmt', () => {
    const pdfBuffer = Buffer.from('%PDF-1.4 unit-test-document');

    it('legacy retrieve: accepts encryptedKey + camelCase operationName and returns the JSON streamingResponse', async () => {
      const getPdfStub = sinon
        .stub(ncpClient, 'getPdf')
        .resolves({ status: 200, headers: { 'content-type': 'application/pdf' }, data: pdfBuffer });

      const response = await request(app)
        .post('/document-services/mortgage-statement/stream/get')
        .set(enterpriseHeaders())
        .send({
          encryptedKey: '6754325468636748593261506F37',
          operationName: 'getAccountPDFInline',
          accountNumber: '11111111'
        });

      expect(response.status).to.equal(200);
      expect(response.headers['content-type']).to.match(/application\/json/);
      expect(response.body.statementsPDF).to.equal(pdfBuffer.toString('base64'));
      // Backend routing: normalized to the exact NCP operation name + X-NCP-AUTH inputs.
      expect(getPdfStub.firstCall.args).to.deep.equal([
        'GetAccountPDFinline',
        '6754325468636748593261506F37',
        '11111111'
      ]);
    });

    it('BIAN retrieve: GetAccountPDF returns application/pdf binary with Content-Disposition attachment', async () => {
      sinon
        .stub(ncpClient, 'getPdf')
        .resolves({ status: 200, headers: { 'content-type': 'application/pdf' }, data: pdfBuffer });

      const response = await request(app)
        .post('/statement-archive/v1/statements/retrieve')
        .set(enterpriseHeaders())
        .send({
          statementKey: '6754325468636748593261506F37',
          operationName: 'GetAccountPDF',
          accountNumber: '11111111'
        })
        .buffer(true)
        .parse((res, callback) => {
          const chunks = [];
          res.on('data', (chunk) => chunks.push(chunk));
          res.on('end', () => callback(null, Buffer.concat(chunks)));
        });

      expect(response.status).to.equal(200);
      expect(response.headers['content-type']).to.match(/application\/pdf/);
      expect(response.headers['content-disposition']).to.equal('attachment');
      expect(Buffer.compare(response.body, pdfBuffer)).to.equal(0);
    });

    it('BIAN retrieve: GetAccountPDFinline sets Content-Disposition inline', async () => {
      sinon
        .stub(ncpClient, 'getPdf')
        .resolves({ status: 200, headers: {}, data: pdfBuffer });

      const response = await request(app)
        .post('/statement-archive/v1/statements/retrieve')
        .set(enterpriseHeaders())
        .send({
          statementKey: '6754325468636748593261506F37',
          operationName: 'GetAccountPDFinline',
          accountNumber: '11111111'
        });

      expect(response.status).to.equal(200);
      expect(response.headers['content-disposition']).to.equal('inline');
    });

    it('BIAN retrieve: rejects legacy camelCase operationName values with 400', async () => {
      const response = await request(app)
        .post('/statement-archive/v1/statements/retrieve')
        .set(enterpriseHeaders())
        .send({
          statementKey: 'K1',
          operationName: 'getAccountPDF',
          accountNumber: '11111111'
        });
      expect(response.status).to.equal(400);
    });

    it('suppresses the NCP error PDF and maps Warning 1001 to 401 (session expired)', async () => {
      sinon.stub(ncpClient, 'getPdf').resolves({
        status: 200,
        headers: {
          warning:
            'NCP: 1001 Account # 11111111 has exceeded the time allotted for viewing the requested statement',
          'content-disposition': 'inline;Filename=ERROR.PDF'
        },
        data: Buffer.from('%PDF-1.4 ERROR DOCUMENT')
      });

      const response = await request(app)
        .post('/statement-archive/v1/statements/retrieve')
        .set(enterpriseHeaders())
        .send({
          statementKey: 'K1',
          operationName: 'GetAccountPDFinline',
          accountNumber: '11111111'
        });

      expect(response.status).to.equal(401);
      expect(response.headers['content-type']).to.match(/application\/json/);
      // The error PDF bytes and raw NCP message never reach the consumer.
      expect(JSON.stringify(response.body)).to.not.include('ERROR DOCUMENT');
      expect(JSON.stringify(response.body)).to.not.include('has exceeded the time allotted');
      expect(response.body.detail).to.match(/expired/i);
      expect(response.body.resultDetails[0].detailCode).to.equal('1001');
    });

    it('maps Warning 1000 to 400, 1003 to 404, and 1006 to 403', async () => {
      const cases = [
        { warning: 'NCP: 1000 Document key is corrupt', status: 400 },
        { warning: 'NCP: 1003 The SSE search did not return a document', status: 404 },
        { warning: 'NCP: 1006 The PDF request could not be verified', status: 403 }
      ];
      for (const testCase of cases) {
        sinon.restore();
        sinon.stub(ncpClient, 'getPdf').resolves({
          status: 200,
          headers: { warning: testCase.warning },
          data: Buffer.from('%PDF error')
        });
        const response = await request(app)
          .post('/statement-archive/v1/statements/retrieve')
          .set(enterpriseHeaders())
          .send({ statementKey: 'K1', operationName: 'GetAccountPDF', accountNumber: '1' });
        expect(response.status).to.equal(testCase.status, testCase.warning);
      }
    });

    it('returns 400 when required fields are missing', async () => {
      const response = await request(app)
        .post('/statement-archive/v1/statements/retrieve')
        .set(enterpriseHeaders())
        .send({ operationName: 'GetAccountPDF' });
      expect(response.status).to.equal(400);
      expect(response.body.detail).to.include('statementKey');
      expect(response.body.detail).to.include('accountNumber');
    });

    it('maps a non-2xx backend HTTP status without Warning header to 502', async () => {
      sinon.stub(ncpClient, 'getPdf').resolves({ status: 503, headers: {}, data: Buffer.from('') });

      const response = await request(app)
        .post('/statement-archive/v1/statements/retrieve')
        .set(enterpriseHeaders())
        .send({ statementKey: 'K1', operationName: 'GetAccountPDF', accountNumber: '1' });

      expect(response.status).to.equal(502);
    });
  });

  describe('credential handling', () => {
    it('never sends the shared secret to the backend (only the derived hash)', async () => {
      const authenticateStub = sinon.stub(ncpClient, 'authenticate').resolves('4A6B7C8D9E0F');
      sinon.stub(ncpClient, 'listStatements').resolves(SAMPLE_STATEMENT_LIST_XML);

      await request(app)
        .post('/statement-archive/v1/statements/list')
        .set(enterpriseHeaders())
        .send({ accountNumber: '11111111' });

      const sent = authenticateStub.firstCall.args[0];
      expect(JSON.stringify(sent)).to.not.include(process.env.NCP_SHARED_SECRET);
      expect(sent).to.not.have.property('sharedSecret');
    });

    it('config.getCredentials caches and can be reset', async () => {
      config.resetCredentialCache();
      const first = await config.getCredentials();
      const second = await config.getCredentials();
      expect(first).to.equal(second);
      config.resetCredentialCache();
    });
  });
});
