'use strict';

const { enterpriseHeaders, SAMPLE_STATEMENT_LIST_XML } = require('./helpers');
const { expect } = require('chai');
const sinon = require('sinon');

const { handler } = require('../src/lambda');
const ncpClient = require('../src/ncpClient');

function buildEvent(path, body, headerOverrides = {}) {
  return {
    httpMethod: 'POST',
    path,
    headers: enterpriseHeaders(headerOverrides),
    body: JSON.stringify(body),
    isBase64Encoded: false
  };
}

describe('AWS Lambda handler (API Gateway proxy integration)', () => {
  afterEach(() => {
    sinon.restore();
  });

  it('handles ListStatement and returns a JSON proxy response with correlation headers', async () => {
    sinon.stub(ncpClient, 'authenticate').resolves('4A6B7C8D9E0F');
    sinon.stub(ncpClient, 'listStatements').resolves(SAMPLE_STATEMENT_LIST_XML);

    const response = await handler(
      buildEvent('/statement-archive/v1/statements/list', { accountNumber: '11111111' })
    );

    expect(response.statusCode).to.equal(200);
    expect(response.isBase64Encoded).to.equal(false);
    expect(response.headers['x-request-id']).to.equal('req-0001');
    expect(response.headers['x-fapi-interaction-id']).to.equal('req-0001');
    const body = JSON.parse(response.body);
    expect(body.statements).to.have.lengthOf(2);
  });

  it('handles RetrieveStatement and returns a base64 PDF with isBase64Encoded true', async () => {
    const pdfBuffer = Buffer.from('%PDF-1.4 lambda-test');
    sinon.stub(ncpClient, 'getPdf').resolves({ status: 200, headers: {}, data: pdfBuffer });

    const response = await handler(
      buildEvent('/statement-archive/v1/statements/retrieve', {
        statementKey: '6754325468636748593261506F37',
        operationName: 'GetAccountPDF',
        accountNumber: '11111111'
      })
    );

    expect(response.statusCode).to.equal(200);
    expect(response.isBase64Encoded).to.equal(true);
    expect(response.headers['Content-Type']).to.equal('application/pdf');
    expect(response.headers['Content-Disposition']).to.equal('attachment');
    expect(Buffer.from(response.body, 'base64').toString()).to.equal('%PDF-1.4 lambda-test');
  });

  it('routes the legacy stream path to the JSON streamingResponse envelope', async () => {
    const pdfBuffer = Buffer.from('%PDF-1.4 legacy');
    sinon.stub(ncpClient, 'getPdf').resolves({ status: 200, headers: {}, data: pdfBuffer });

    const response = await handler(
      buildEvent('/document-services/mortgage-statement/stream/get', {
        encryptedKey: 'K1',
        operationName: 'getAccountPDF',
        accountNumber: '11111111'
      })
    );

    expect(response.statusCode).to.equal(200);
    expect(response.isBase64Encoded).to.equal(false);
    const body = JSON.parse(response.body);
    expect(body.statementsPDF).to.equal(pdfBuffer.toString('base64'));
  });

  it('normalizes mixed-case API Gateway headers', async () => {
    sinon.stub(ncpClient, 'authenticate').resolves('4A6B7C8D9E0F');
    sinon.stub(ncpClient, 'listStatements').resolves(SAMPLE_STATEMENT_LIST_XML);

    const event = buildEvent('/statement-archive/v1/statements/list', { accountNumber: '1' });
    event.headers = {
      'X-Request-ID': 'req-0001',
      'X-API-Key': 'key',
      'X-FAPI-Financial-ID': '001',
      'X-App-Cat-ID': 'APPCAT-001'
    };

    const response = await handler(event);
    expect(response.statusCode).to.equal(200);
  });

  it('returns 415 when the request content type is not application/json', async () => {
    const event = buildEvent('/statement-archive/v1/statements/list', { accountNumber: '1' });
    event.headers['content-type'] = 'application/xml';
    const response = await handler(event);
    expect(response.statusCode).to.equal(415);
    expect(JSON.parse(response.body).status).to.equal(415);
  });

  it('returns 404 for unknown paths and 400 for missing headers / invalid JSON', async () => {
    const unknown = await handler(buildEvent('/unknown/path', {}));
    expect(unknown.statusCode).to.equal(404);

    const missingHeaders = await handler(
      buildEvent('/statement-archive/v1/statements/list', { accountNumber: '1' }, { 'x-api-key': undefined })
    );
    expect(missingHeaders.statusCode).to.equal(400);

    const badJson = buildEvent('/statement-archive/v1/statements/list', {});
    badJson.body = '{not-json';
    const invalid = await handler(badJson);
    expect(invalid.statusCode).to.equal(400);
  });

  it('returns a sanitized 502 errorResponse when the backend throws', async () => {
    sinon.stub(ncpClient, 'authenticate').rejects(new Error('ECONNRESET'));

    const response = await handler(
      buildEvent('/statement-archive/v1/statements/list', { accountNumber: '1' })
    );

    expect(response.statusCode).to.equal(502);
    expect(response.body).to.not.include('ECONNRESET');
    const body = JSON.parse(response.body);
    expect(body).to.include.keys(['type', 'title', 'status', 'detail', 'instance']);
  });
});
