'use strict';

require('./helpers');
const { expect } = require('chai');
const {
  buildErrorResponse,
  mapAuthenticateResult,
  mapListErrorStatus,
  mapPdfWarning
} = require('../src/errorMapping');

describe('errorMapping', () => {
  describe('mapAuthenticateResult', () => {
    it('treats a hexadecimal token as success', () => {
      const result = mapAuthenticateResult('4A6B7C8D9E0F');
      expect(result.isError).to.equal(false);
    });

    it('maps "ERROR: Authentication Failure|1199 ..." to HTTP 502 without exposing the message', () => {
      const raw = 'ERROR: Authentication Failure|1199 No control record found for user ID 1234';
      const result = mapAuthenticateResult(raw);
      expect(result).to.deep.include({ isError: true, ncpErrorCode: '1199', httpStatus: 502 });
    });

    it('maps 1102 Hash mismatch to HTTP 500', () => {
      const result = mapAuthenticateResult('ERROR: Authentication Failure|1102 Hash mismatch');
      expect(result.httpStatus).to.equal(500);
    });

    it('maps 1100/1101/1103 to HTTP 400', () => {
      for (const code of ['1100', '1101', '1103']) {
        expect(mapAuthenticateResult(`ERROR: Authentication Failure|${code} msg`).httpStatus).to.equal(400);
      }
    });
  });

  describe('mapListErrorStatus', () => {
    it('maps 1200 token timeout to 401 and 1205 no records to 200', () => {
      expect(mapListErrorStatus('1200')).to.equal(401);
      expect(mapListErrorStatus('1205')).to.equal(200);
    });

    it('maps 1201/1203/1206/1207/1299 and unknown codes to 502', () => {
      for (const code of ['1201', '1203', '1206', '1207', '1299', '9999']) {
        expect(mapListErrorStatus(code)).to.equal(502);
      }
    });
  });

  describe('mapPdfWarning', () => {
    it('parses the NCP Warning header format "NCP: <code> <message>"', () => {
      const warning =
        'NCP: 1001 Account # 11111111 has exceeded the time allotted for viewing the requested statement';
      expect(mapPdfWarning(warning)).to.deep.equal({ ncpErrorCode: '1001', httpStatus: 401 });
    });

    it('maps 1000 to 400, 1003 to 404, 1006 to 403, and 1099 to 502', () => {
      expect(mapPdfWarning('NCP: 1000 Document key is corrupt').httpStatus).to.equal(400);
      expect(mapPdfWarning('NCP: 1003 no document').httpStatus).to.equal(404);
      expect(mapPdfWarning('NCP: 1006 not verified').httpStatus).to.equal(403);
      expect(mapPdfWarning('NCP: 1099 unexpected').httpStatus).to.equal(502);
    });

    it('defaults to 502 when the header is malformed', () => {
      expect(mapPdfWarning('unexpected header').httpStatus).to.equal(502);
    });
  });

  describe('buildErrorResponse (enterprise Zalando Problem format)', () => {
    it('builds the errorResponse shape with sanitized detail and NCP code in resultDetails', () => {
      const body = buildErrorResponse({
        status: 502,
        instance: '/statement-archive/v1/statements/list',
        ncpErrorCode: '1299'
      });
      expect(body).to.include.keys(['type', 'title', 'status', 'detail', 'instance']);
      expect(body.type).to.equal('about:blank');
      expect(body.status).to.equal(502);
      expect(body.resultDetails[0].detailCode).to.equal('1299');
      // Sanitization: no raw NCP text in the payload.
      expect(JSON.stringify(body)).to.not.match(/Authentication Failure|control record|SSE/);
    });

    it('uses the session-expired consumer message for 401', () => {
      const body = buildErrorResponse({ status: 401, instance: '/x' });
      expect(body.detail).to.match(/expired/i);
    });
  });
});
