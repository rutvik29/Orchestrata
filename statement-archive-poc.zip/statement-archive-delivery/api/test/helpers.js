'use strict';

/**
 * Shared unit-test helpers: NCP credential environment and enterprise headers.
 * These are mock values only; real credentials come from AWS Secrets Manager.
 */

process.env.NCP_CLIENT_ID = '1234';
process.env.NCP_USER_ID = 'testuser1';
process.env.NCP_PASSWORD = 'Un1t-T3st!Pwd';
process.env.NCP_SHARED_SECRET = 'unit-test-shared-secret';

/** Build the required enterprise request headers, with optional overrides. */
function enterpriseHeaders(overrides = {}) {
  const headers = {
    'x-request-id': 'req-0001',
    'x-api-key': 'unit-test-api-key',
    'x-fapi-financial-id': '001',
    'x-app-cat-id': 'APPCAT-001',
    ...overrides
  };
  for (const name of Object.keys(headers)) {
    if (headers[name] === undefined) {
      delete headers[name];
    }
  }
  return headers;
}

/** Sample NCP statementlist XML (exact element names from the NCP spec). */
const SAMPLE_STATEMENT_LIST_XML =
  '<?xml version="1.0"?><statementlist>' +
  '<statement><date>09/30/2014</date><description>Monthly Statement</description>' +
  '<key>6754325468636748593261506F37</key><product>00001000</product></statement>' +
  '<statement><date>08/31/2014</date><description>Monthly Statement</description>' +
  '<key>6754325468636748593261506F38</key><product>00001000</product></statement>' +
  '</statementlist>';

/** Sample NCP List error XML. */
function statementListErrorXml(code, text) {
  return `<?xml version="1.0"?><statementlist><error><text>${text}</text><code>${code}</code></error></statementlist>`;
}

module.exports = { enterpriseHeaders, SAMPLE_STATEMENT_LIST_XML, statementListErrorXml };
