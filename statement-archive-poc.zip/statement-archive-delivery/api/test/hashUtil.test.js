'use strict';

require('./helpers');
const crypto = require('crypto');
const { expect } = require('chai');
const { buildAuthenticateHash, HASH_PARAMETER_ORDER } = require('../src/hashUtil');

describe('hashUtil.buildAuthenticateHash (NCP Authenticate parameter 12)', () => {
  const sharedSecret = 'unit-test-shared-secret';

  it('concatenates parameters 1-10 in order, appends the shared secret, and returns the SHA-256 hex digest', () => {
    const params = {
      clientId: '1234',
      userId: 'testuser1',
      password: 'Un1t-T3st!Pwd',
      account: '11111111',
      startDate: '20140101',
      endDate: '20140930',
      product: '00001000',
      flexField1: 'A',
      flexField2: 'BB',
      flexField3: 'CCC'
    };
    const expected = crypto
      .createHash('sha256')
      .update(
        '1234' + 'testuser1' + 'Un1t-T3st!Pwd' + '11111111' + '20140101' + '20140930' +
          '00001000' + 'A' + 'BB' + 'CCC' + sharedSecret,
        'utf8'
      )
      .digest('hex');

    expect(buildAuthenticateHash(params, sharedSecret)).to.equal(expected);
  });

  it('omits unused optional parameters from the concatenated string', () => {
    const params = {
      clientId: '1234',
      userId: 'testuser1',
      password: 'Un1t-T3st!Pwd',
      account: '11111111'
      // startDate..flexField3 not used
    };
    const expected = crypto
      .createHash('sha256')
      .update('1234testuser1Un1t-T3st!Pwd11111111' + sharedSecret, 'utf8')
      .digest('hex');

    expect(buildAuthenticateHash(params, sharedSecret)).to.equal(expected);
    expect(buildAuthenticateHash({ ...params, startDate: '', endDate: '' }, sharedSecret)).to.equal(expected);
  });

  it('uses the entire pipe-delimited multi-account string in the hash', () => {
    const account = '11111111|22222222|33333333';
    const params = { clientId: '1', userId: '2', password: '3', account };
    const expected = crypto
      .createHash('sha256')
      .update('123' + account + sharedSecret, 'utf8')
      .digest('hex');

    expect(buildAuthenticateHash(params, sharedSecret)).to.equal(expected);
  });

  it('does not include clientIpAddress (parameter 11) or hash (parameter 12) in the hash input', () => {
    expect(HASH_PARAMETER_ORDER).to.not.include('clientIpAddress');
    expect(HASH_PARAMETER_ORDER).to.not.include('hash');
    expect(HASH_PARAMETER_ORDER).to.have.lengthOf(10);

    const base = { clientId: '1', userId: '2', password: '3', account: '4' };
    const withIp = { ...base, clientIpAddress: '203.0.113.10' };
    expect(buildAuthenticateHash(withIp, sharedSecret)).to.equal(buildAuthenticateHash(base, sharedSecret));
  });

  it('throws when the shared secret is missing', () => {
    expect(() => buildAuthenticateHash({ clientId: '1' }, '')).to.throw(/sharedSecret/);
  });
});
