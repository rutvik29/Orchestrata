#!/usr/bin/env python3
"""Contract regression gate for the Statement Archive OpenAPI.

Fails (exit 1) if the generated OpenAPI 3.0.3 drifts from the frozen
enterprise Mortgage-loan-statement Swagger 2.0 contract, or violates the
structural rules from the Swagger design template (paths, operationIds,
status coverage, headers, schemas, security, enums, binary handling).

Usage:
    python3 scripts/validate-openapi.py \
        [swagger/statement-archive.openapi.yaml] \
        [input/enterprise-contract/mortgage-loan-statement-swagger2.yaml]

Run in CI on every change. The enterprise contract file is the source of
truth and must never be edited.
"""
import re
import sys

import yaml

NEW_PATH = sys.argv[1] if len(sys.argv) > 1 else "swagger/statement-archive.openapi.yaml"
OLD_PATH = (
    sys.argv[2]
    if len(sys.argv) > 2
    else "input/enterprise-contract/mortgage-loan-statement-swagger2.yaml"
)

EXPECTED_PATHS = {
    "/document-services/mortgage-statement/list/get": ("listMortgageStatement", "legacy-compatible"),
    "/document-services/mortgage-statement/stream/get": ("retrieveMortgageStmt", "legacy-compatible"),
    "/statement-archive/v1/statements/list": ("ListStatement", "bian-aligned"),
    "/statement-archive/v1/statements/retrieve": ("RetrieveStatement", "bian-aligned"),
}
REQUIRED_STATUSES = {"200", "400", "401", "403", "404", "415", "429", "500", "502", "504"}
REQUIRED_SCHEMAS = [
    "productAdapterRequest", "streamingAdapterRequest", "productResponse", "streamingResponse",
    "statementList", "statements", "statement", "result", "details", "errorResponse",
    "ListStatementRequest", "ListStatementResponse", "Statement", "RetrieveStatementRequest",
]
RESPONSE_HEADERS = {"x-request-id", "x-fapi-interaction-id"}

errors = []


def check(condition, message):
    if not condition:
        errors.append(message)


old = yaml.safe_load(open(OLD_PATH, encoding="utf-8"))
new = yaml.safe_load(open(NEW_PATH, encoding="utf-8"))
raw_new = open(NEW_PATH, encoding="utf-8").read()

# enterprise metadata: byte-for-byte
check(new.get("openapi") == "3.0.3", "openapi version must be 3.0.3")
for key in ("title", "version", "description", "x-audience"):
    check(old["info"][key] == new["info"].get(key), f"info.{key} drift from enterprise contract")
check(old["info"]["contact"] == new["info"].get("contact"), "info.contact drift")

# enterprise headers: names, required flags, descriptions
params = new.get("components", {}).get("parameters", {})
for name, old_param in old["parameters"].items():
    new_param = params.get(name)
    check(new_param is not None, f"header parameter {name} missing")
    if new_param:
        check(
            bool(old_param.get("required", False)) == bool(new_param.get("required", False)),
            f"header {name}: required flag drift",
        )
        check(
            old_param.get("description") == new_param.get("description"),
            f"header {name}: description drift",
        )

# paths, operationIds, statuses, headers
for path, (operation_id, path_status) in EXPECTED_PATHS.items():
    op = new.get("paths", {}).get(path, {}).get("post")
    check(op is not None, f"missing path {path}")
    if not op:
        continue
    check(op.get("operationId") == operation_id, f"{path}: operationId must be {operation_id}")
    check(op.get("x-path-status") == path_status, f"{path}: x-path-status must be {path_status}")
    check(len(op.get("parameters", [])) == 10, f"{path}: must reference all 10 enterprise headers")
    check(
        set(op.get("responses", {}).keys()) == REQUIRED_STATUSES,
        f"{path}: response statuses must be exactly {sorted(REQUIRED_STATUSES)}",
    )

# schemas preserved
schemas = new.get("components", {}).get("schemas", {})
for schema_name in REQUIRED_SCHEMAS:
    check(schema_name in schemas, f"missing schema {schema_name}")
for schema_name, old_schema in old["definitions"].items():
    new_schema = schemas.get(schema_name, {})
    check(
        sorted(old_schema.get("required", [])) == sorted(new_schema.get("required", [])),
        f"schema {schema_name}: required array drift",
    )
    lost = set(old_schema.get("properties", {}) or {}) - set(new_schema.get("properties", {}) or {})
    check(not lost, f"schema {schema_name}: lost properties {sorted(lost)}")

# security
check(
    new.get("components", {}).get("securitySchemes", {}).get("api_key")
    == {"type": "apiKey", "name": "x-api-key", "in": "header"},
    "api_key security scheme drift",
)
check({"api_key": []} in new.get("security", []), "global api_key security missing")

# operationName enum and binary PDF
enum = (
    schemas.get("RetrieveStatementRequest", {})
    .get("properties", {})
    .get("operationName", {})
    .get("enum")
)
check(enum == ["GetAccountPDF", "GetAccountPDFinline"], f"operationName enum drift: {enum}")
retrieve_200 = (
    new["paths"]["/statement-archive/v1/statements/retrieve"]["post"]["responses"]["200"]
)
pdf = retrieve_200.get("content", {}).get("application/pdf", {}).get("schema", {})
check(pdf.get("format") == "binary", "BIAN retrieve 200 must be application/pdf binary")

# every shared response carries both correlation headers
for name, resp in new.get("components", {}).get("responses", {}).items():
    check(
        set(resp.get("headers", {}).keys()) == RESPONSE_HEADERS,
        f"components.responses.{name}: must define exactly {sorted(RESPONSE_HEADERS)}",
    )

# all internal refs resolve
components = new.get("components", {})
for section, ref_name in set(re.findall(r"#/components/(\w+)/([\w-]+)", raw_new)):
    check(ref_name in components.get(section, {}), f"unresolved $ref #/components/{section}/{ref_name}")

# sanitization: no raw NCP error text in the contract
check("No control record" not in raw_new, "contract leaks raw NCP error text")

if errors:
    print("CONTRACT VALIDATION FAILED")
    for message in errors:
        print(f"  - {message}")
    sys.exit(1)
print(f"CONTRACT VALIDATION PASSED ({NEW_PATH})")
