# Statement Archive API — Design Document

Scope Check: In-scope operations detected: 4/4
Sanitization Check: No raw NCP messages, tokens, hashes, secrets, or backend error PDFs are exposed in consumer payloads
Binary Handling Check: application/pdf response and API Gateway binary handling are included
Enterprise Contract Check: Enterprise headers, legacy paths, and Zalando errorResponse schema preserved

## 1. Scope Confirmation

The consumer-facing REST API is a facade over exactly four NCP Direct Access backend operations, with names taken verbatim from the WSDL (`Statements.xml`, service `Statements`, portType `IStatements`) and the NCP specification document:

| # | Backend Operation | Protocol | Backend Service |
|---|---|---|---|
| 1 | `Authenticate` | SOAP (document/literal, basicHttpBinding, transport security) | AvailableImages/Statements.svc |
| 2 | `List` | SOAP (document/literal) | AvailableImages/Statements.svc |
| 3 | `GetAccountPDF` | REST GET | ImageRetrieval/Repository.svc |
| 4 | `GetAccountPDFinline` | REST GET | ImageRetrieval/Repository.svc |

`ListDynamic` and `CreateMultidocPDF` appear in the WSDL but are **out of scope** and are excluded from the consumer contract, orchestration, and mapping tables.

Consumer operations:

| Consumer Operation | Paths | Backend Orchestration |
|---|---|---|
| `ListStatement` (BIAN) / `listMortgageStatement` (legacy) | `POST /statement-archive/v1/statements/list` / `POST /document-services/mortgage-statement/list/get` | `Authenticate` then `List`, in sequence; XML parsed and mapped to JSON |
| `RetrieveStatement` (BIAN) / `retrieveMortgageStmt` (legacy) | `POST /statement-archive/v1/statements/retrieve` / `POST /document-services/mortgage-statement/stream/get` | `GetAccountPDF` **or** `GetAccountPDFinline`, selected by the `operationName` request field |

## 2. Assumptions and Design Notes

1. The enterprise Swagger 2.0 contract (`input/enterprise-contract/mortgage-loan-statement-swagger2.yaml`) is preserved: metadata, all ten request headers with their required/optional settings, legacy paths and operationIds, `result`/`details` schemas, and the Zalando Problem `errorResponse`. The OpenAPI 3.0.3 file is a faithful migration with the BIAN paths added alongside.
2. The SHA-256 hash is calculated server-side in Lambda from Authenticate parameters 1–10 (unused optionals omitted) plus the shared secret, hex-encoded (lowercase hex assumed; NCP spec does not state a case — confirm with NCP).
3. BIAN-path dates are ISO 8601 (`yyyy-mm-dd`) and converted to NCP `yyyymmdd`; legacy-path dates pass through unchanged as `yyyymmdd`.
4. Legacy `operationName` values `getAccountPDF`/`getAccountPDFInline` are accepted on the legacy path only and normalized to the exact backend names `GetAccountPDF`/`GetAccountPDFinline`. The BIAN path enforces the strict PascalCase enum.
5. NCP token (30-minute TTL) is used within a single Lambda invocation and never cached or returned. Document keys (30-minute TTL) are opaque `statementKey` values for the consumer.
6. The account parameter may carry up to 25 pipe-delimited account numbers; the facade validates the limit and hashes the entire pipe-delimited string.
7. Optional statement-list fields (`account`, `flexfield1`–`flexfield6`) are mapped when the NCP account-number / flex-field configuration options are enabled.

## 3. OpenAPI

Complete OpenAPI 3.0.3: `swagger/statement-archive.openapi.yaml` (validated: 4 paths, 10 enterprise headers per operation, 10 response statuses per operation, both enterprise response headers on every response, `application/pdf` binary on the BIAN retrieve).

## 4. Backend Operation Mapping

| Consumer Operation | Step | Backend Call | Transport Detail |
|---|---|---|---|
| ListStatement | 1 | `Authenticate(clientId, userId, password, account, startDate, endDate, product, flexField1, flexField2, flexField3, clientIpAddress, hash)` | SOAP action `http://directaccess.ncpsolutions.com/services/IStatements/Authenticate` |
| ListStatement | 2 | `List(token)` | SOAP action `http://directaccess.ncpsolutions.com/services/IStatements/List` |
| RetrieveStatement | 1 | `GET {base}/GetAccountPDF/{statementKey}` or `GET {base}/GetAccountPDFinline/{statementKey}` with header `X-NCP-AUTH: {accountNumber}` | `{base}` = `https://directaccess.ncpsolutions.com:8443/ImageRetrieval/Repository.svc` |

## 5. Request Mapping

ListStatement (legacy `productAdapterRequest` → BIAN `ListStatementRequest` → NCP `Authenticate`):

| Legacy Field | BIAN Field | NCP Parameter | Transformation |
|---|---|---|---|
| `account` | `accountNumber` | `account` (4) | Up to 25 pipe-delimited values, passed whole |
| `startDate` (yyyymmdd) | `startDate` (yyyy-mm-dd) | `startDate` (5) | BIAN: strip hyphens; legacy: pass-through |
| `endDate` (yyyymmdd) | `endDate` (yyyy-mm-dd) | `endDate` (6) | Same as startDate |
| `product` | `product` | `product` (7) | Pass-through |
| `flexField1`–`flexField3` | `flexField1`–`flexField3` | `flexField1`–`flexField3` (8–10) | Pass-through |
| `clientIpAddress` | `clientIpAddress` | `clientIpAddress` (11) | Pass-through |
| — (server-side) | — (server-side) | `clientId` (1), `userId` (2), `password` (3) | From AWS Secrets Manager |
| — (server-side) | — (server-side) | `hash` (12) | SHA-256(params 1–10 + shared secret) |

RetrieveStatement (legacy `streamingAdapterRequest` → BIAN `RetrieveStatementRequest` → NCP REST):

| Legacy Field | BIAN Field | NCP Usage |
|---|---|---|
| `encryptedKey` | `statementKey` | URL path segment (document key) |
| `operationName` (`getAccountPDF`/`getAccountPDFInline`) | `operationName` (`GetAccountPDF`/`GetAccountPDFinline`) | Operation-name URL segment (normalized to PascalCase) |
| `accountNumber` | `accountNumber` | `X-NCP-AUTH` request header |

## 6. Response Mapping

ListStatement (NCP `statementlist` XML → consumer JSON):

| NCP XML Element | Legacy `productResponse` | BIAN `ListStatementResponse` |
|---|---|---|
| `statement/date` (MM/DD/YYYY) | `statementList.statements[].date` (unchanged) | `statements[].statementDate` (ISO 8601) |
| `statement/description` | `...description` | `statements[].description` |
| `statement/key` | `...key` | `statements[].statementKey` |
| `statement/product` | `...product` | `statements[].product` |
| `statement/account` (optional) | — | `statements[].account` |
| `statement/flexfield1`–`flexfield6` (optional) | — | `statements[].flexField1`–`flexField6` |

RetrieveStatement:

| Backend Result | Legacy Path | BIAN Path |
|---|---|---|
| PDF bytes, no Warning header | `streamingResponse` JSON: `statementsPDF` base64 | Raw `application/pdf` binary; `Content-Disposition` attachment (GetAccountPDF) or inline (GetAccountPDFinline) |
| Warning header present (error PDF) | Sanitized `errorResponse` JSON — error PDF suppressed | Same |

## 7. Error Mapping (NCP → enterprise errorResponse)

NCP error codes are surfaced only in `resultDetails[].detailCode`; `detail` carries a generic consumer-safe message. Raw NCP text is logged internally with the correlation ID, never returned.

Authenticate (code in `ERROR: Authentication Failure|<code> ...` string):

| NCP Code | Description | HTTP |
|---|---|---|
| 1100 | Required parameters are missing | 400 |
| 1101 | Too many accounts have been requested | 400 |
| 1102 | Hash mismatch | 500 |
| 1103 | Invalid parameter value | 400 |
| 1199 | Unexpected exception | 502 |

List (code in `statementlist/error/code`):

| NCP Code | Description | HTTP |
|---|---|---|
| 1200 | Authentication token timed out (30-minute limit) | 401 (session-expired message) |
| 1201 | Authentication token is corrupt | 502 |
| 1203 | Unable to load the product lookup table | 502 |
| 1205 | No records found | **200 with empty statements array** |
| 1206 | Missing required columns in SSE search results | 502 |
| 1207 | Unable to retrieve a list of client numbers | 502 |
| 1299 | Unexpected exception | 502 |

GetAccountPDF / GetAccountPDFinline (code in `Warning: NCP: <code> <message>` header):

| NCP Code | Description | HTTP |
|---|---|---|
| 1000 | Document key is corrupt | 400 |
| 1001 | Exceeded time allotted for viewing (30-minute limit) | 401 (session-expired message) |
| 1003 | SSE search did not return a document | 404 |
| 1004 | Missing Report Authorization Code column | 502 |
| 1005 | PDF is not readable | 502 |
| 1006 | PDF request could not be verified | 403 |
| 1099 | Unexpected exception | 502 |
| Any Warning header without a mappable code | — | 502 |

## 8. Security Considerations

Consumers never see: SOAP/WSDL internals, raw NCP XML, NCP credentials, the NCP token, the SHA-256 hash, the shared secret, or the backend error PDF. `clientId`, `userId`, `password`, and `sharedSecret` live in AWS Secrets Manager; password and shared secret are never logged. Account numbers and statement keys are masked in logs (last four characters); PDF bytes are never logged. HTTPS end-to-end; API Gateway enforces `x-api-key`; `x-fapi-interaction-id` (defaulting to `x-request-id`) is the correlation ID in all logs and error responses. NCP requires source-IP allowlisting, so Lambda egress goes through a VPC NAT Gateway with an Elastic IP registered with NCP.

## 9. AWS Deployment Architecture

API Gateway: exposes the four POST paths, enforces `x-api-key`, request validation from the OpenAPI schema, throttling, access logging, and binary media type `application/pdf`. Lambda (Node.js 18+, handler `src/lambda.handler`): validates headers/body, loads credentials from Secrets Manager (cached across warm invocations), normalizes dates, computes the SHA-256 hash, builds and calls the SOAP operations, parses XML, calls the REST PDF operations, inspects the Warning header, suppresses error PDFs, and returns mapped JSON or a base64 PDF proxy response with `isBase64Encoded: true`. Supporting services: Secrets Manager (credentials), SSM Parameter Store (non-secret endpoint config), CloudWatch Logs (structured, masked logging), X-Ray (tracing), VPC/NAT/EIP (fixed outbound IP for the NCP allowlist).

## 10. High-Level Architecture Diagram

```mermaid
flowchart LR
    subgraph Consumers["Consumer Channels"]
        WEB[Web] --- MOB[Mobile] --- INT[Internal App]
    end
    subgraph AWS["AWS"]
        APIGW["API Gateway<br/>legacy + BIAN paths<br/>x-api-key auth, throttle,<br/>binary media application/pdf"]
        LAMBDA["Lambda<br/>Statement Archive Handler<br/>(src/lambda.handler)"]
        SM["Secrets Manager<br/>clientId / userId /<br/>password / sharedSecret"]
        SSM["SSM Parameter Store<br/>NCP endpoints, timeouts"]
        CW["CloudWatch Logs"]
        XRAY["X-Ray"]
        NAT["VPC / NAT Gateway / EIP<br/>(NCP IP allowlist)"]
    end
    subgraph NCP["NCP Solutions"]
        SOAP["Available Images SOAP<br/>Statements.svc<br/>Authenticate, List"]
        REST["Image Retrieval REST<br/>Repository.svc<br/>GetAccountPDF, GetAccountPDFinline"]
        ARCHIVE[("Document Image Archive")]
    end
    Consumers -->|HTTPS| APIGW --> LAMBDA
    LAMBDA --> SM
    LAMBDA --> SSM
    LAMBDA --> CW
    LAMBDA --> XRAY
    LAMBDA --> NAT
    NAT -->|HTTPS 8443| SOAP
    NAT -->|HTTPS 8443| REST
    SOAP --> ARCHIVE
    REST --> ARCHIVE
```

## 11. ListStatement Sequence Diagram

```mermaid
sequenceDiagram
    participant C as Consumer
    participant G as API Gateway
    participant L as Lambda
    participant S as Secrets Manager
    participant A as NCP Authenticate (SOAP)
    participant N as NCP List (SOAP)
    C->>G: POST /statement-archive/v1/statements/list<br/>(headers + ListStatementRequest)
    G->>L: Proxy event (x-api-key validated)
    L->>L: Validate headers/body, ISO dates -> yyyymmdd
    L->>S: GetSecretValue (cached)
    S-->>L: clientId, userId, password, sharedSecret
    L->>L: hash = SHA-256(params 1-10 + sharedSecret)
    L->>A: Authenticate(12 ordered params)
    A-->>L: AuthenticateResult (hex token | ERROR string)
    alt ERROR string
        L-->>G: Sanitized errorResponse (400/500/502)
    else token
        L->>N: List(token)
        N-->>L: statementlist XML
        alt error code 1205
            L-->>G: 200 with empty statements array
        else error code
            L-->>G: Sanitized errorResponse (401/502)
        else statements
            L->>L: Parse XML, map date/key -> statementDate/statementKey
            L-->>G: 200 ListStatementResponse (JSON)
        end
    end
    G-->>C: Response + x-request-id / x-fapi-interaction-id
```

## 12. RetrieveStatement Sequence Diagram

```mermaid
sequenceDiagram
    participant C as Consumer
    participant G as API Gateway
    participant L as Lambda
    participant R as NCP Repository.svc (REST)
    C->>G: POST /statement-archive/v1/statements/retrieve<br/>(accountNumber, statementKey, operationName)
    G->>L: Proxy event (x-api-key validated)
    L->>L: Validate; route by operationName enum<br/>GetAccountPDF | GetAccountPDFinline
    L->>R: GET {base}/{operationName}/{statementKey}<br/>X-NCP-AUTH: accountNumber
    R-->>L: PDF bytes (+ optional Warning header)
    alt Warning header present (error PDF)
        L->>L: Suppress error PDF, log NCP code with correlation ID
        L-->>G: Sanitized errorResponse (400/401/403/404/502)
        G-->>C: JSON error
    else success
        L-->>G: Base64 PDF, isBase64Encoded=true,<br/>Content-Disposition attachment|inline
        G-->>C: application/pdf binary
    end
```

## 13. Risks, Open Questions, Recommendations

Risks: the 30-minute token/key TTL means slow consumers will hit 1001/1200 (surfaced as 401 with a session-expired message); NCP IP allowlisting couples deployments to the NAT EIP — register both production and DR EIPs; large multi-account statement lists can approach SOAP message-size limits (NCP suggests `maxReceivedMessageSize` 2 MB — keep the Lambda/axios limits aligned).

Open questions: hash hex casing (assumed lowercase — confirm with NCP); whether the account-number and flex-field statement-list configuration options are enabled for this client; whether a client certificate will be presented to NCP (spec supports it).

Recommendations: enable API Gateway request validation from the OpenAPI schema to reject malformed bodies before Lambda; add an alarm on 1102 (hash mismatch — indicates credential/secret drift); rotate the shared secret via Secrets Manager rotation with `resetCredentialCache`; consider caching the SOAP WSDL locally in the deployment package to avoid the runtime `?wsdl` fetch.
