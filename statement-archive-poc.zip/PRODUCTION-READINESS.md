# Production Readiness — honest boundary of this tool

## What the pipeline guarantees (mechanically, every run)

- Contract fidelity to the ground sources (WSDL + NCP doc), verified by the contract gate
- Company-standard structure, naming, and entry points, verified by the generation gate
- Known failure classes blocked (unreachable status codes, unenforced api-key, missing
  VPC wiring, missing .gitignore, silent assumptions) — rules 1-6
- Every unknown flagged as an Open Item instead of assumed
- Unit-level behavior verified against spec fixtures

## What the pipeline can NOT guarantee — and what covers each gap

| Gap | Why the tool can't close it | What closes it |
|---|---|---|
| Unknown defect classes (the next "VPC-style" miss) | gates are built from known failures | mandatory human PR review (CODEOWNERS), reviewer owns the merge |
| Real-backend mismatches (WSDL drift, hash casing, Warning formats) | unit tests use stubs | SIT contract suite vs NCP QA (dat1) before every promotion |
| Bad version reaching all users | any code can have bugs | canary deployment + CloudWatch alarms + automatic rollback |
| Platform-level abuse/overload | app code alone can't contain it | API Gateway validation, throttling, WAF — independent of the Lambda |
| Unresolved ground-truth items | tool refuses to assume | Open Items table = hard release blocker, human sign-off |
| Stand-in framework code | golden source is not in the tool's inputs | swap to golden-source logger before SIT exit |

## The correct claim for your demo

Not: "the AI generates production-ready code."
But: "the AI generates review-ready code that passes every mechanical gate we can define,
flags everything it cannot know, and flows through the same human review, SIT contract
testing, and canary promotion as any engineer's code — so one mistake cannot reach the
whole system."

This is defense in depth. The tool removes weeks of drafting; the bank's controls remain
the reason production is safe.
