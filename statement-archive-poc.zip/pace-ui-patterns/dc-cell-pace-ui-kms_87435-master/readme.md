# Blank template
Reference: https://bmo.atlassian.net/wiki/spaces/AUTOMATE/pages/645864213/Empty+Template
--

# KMS PBB-US (PACE) Fargate Container
Chose to use our own KMS key for ECR and EFS encryption.

As of 2025-03-02, container shared resources are only available in DIT1, SIT1, and PRD1 stage.