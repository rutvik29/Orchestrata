import * as cdk from 'aws-cdk-lib';
import { BMOKMSConstruct } from '@bmo-cdk/kms';
import { BMOSSMConstruct } from '@bmo-cdk/ssm-parameter';
import { Construct } from 'constructs';
import { createBmoCdkHelper } from '../config/index';
import { extendedBaseTags, extendedKmsTags } from '../config/constants';

export class KmsStack extends cdk.Stack {
  public readonly ecrKmsKey: BMOKMSConstruct;

  constructor(scope: Construct, id: string, props: cdk.StackProps) {
    super(scope, id, props);

    const helper = createBmoCdkHelper(this);

    const owner = extendedBaseTags.portfolioShortCode;

    const accountId: string = helper.deployment.accountId;
    const stage: string = helper.deployment.stage;
    const accountShortCode: string = helper.deployment.accountShortCode;
    const environment: string = helper.deployment.environment;
    const stageShortCode: string = helper.deployment.stageShortCode;
    const region: string = helper.deployment.region;
    const regionShortCode: string = helper.deployment.regionShortCode;
    const serviceName: string = helper.application.serviceName;

    const kmsAlias: string = `${accountShortCode}-${stageShortCode}-${regionShortCode}-${serviceName}-kms`;

    //debugging
    console.log(`kms alias: ${kmsAlias}`);
    console.log(`extended Base Tags: ${JSON.stringify(extendedBaseTags)}`);

    this.ecrKmsKey = new BMOKMSConstruct(this, `${serviceName}-ecr-kms-key`, {
      alias: `${kmsAlias}`,
      keyType: 'platform',                                  //'platform' or 'application' - will automatically add keyPolicy defined here - https://confluence.bmogc.net/display/IE/KMS+CMK+keys+policy+pattern
      //applicationKeyAppCatIdForTagBasedAccess: '71803',   // conditional - needs to be specified if keyType is application
      enabled: true,
      keyUsage: 'ENCRYPT_DECRYPT',
      tags: extendedKmsTags,
    });

    // export new kms key arn to SSM parameter
    const ecrKmsKeyArnSsm = new BMOSSMConstruct(this, 'SSM-ECR-KMS-Key-arn-Parameter', {
      // ssmName: namingHelpers.toKmsKeyArn.name,
      ssmName: `/${owner}/${serviceName}/${stage}/${regionShortCode}/ecr/kms/key/arn`,
      ssmDescription: `KMS Key ARN Parameter for ${serviceName} CDK Version`,
      ssmType: 'String',
      ssmValue: this.ecrKmsKey.kmsKey.attrArn, //output is kms arn
      tags: extendedBaseTags,
    });

    // export new kms key id to SSM parameter
    const ecrKmsKeyIdSsm = new BMOSSMConstruct(this, 'SSM-ECR-KMS-Key-id-Parameter', {
      ssmName: `/${owner}/${serviceName}/${stage}/${regionShortCode}/ecr/kms/key/id`,
      ssmDescription: `KMS Key Id Parameter for ${serviceName} CDK Version`,
      ssmType: 'String',
      ssmValue: this.ecrKmsKey.kmsKey.ref, // output is kms id
      tags: extendedBaseTags,
    });

    // export new kms key alias to SSM parameter
    const ecrKmsAliasSsm = new BMOSSMConstruct(this, 'SSM-ECR-KMS-Key-alias-Parameter', {
      ssmName: `/${owner}/${serviceName}/${stage}/${regionShortCode}/ecr/kms/key/alias`,
      ssmDescription: `KMS Key Alias Parameter for ${serviceName} CDK Version`,
      ssmType: 'String',
      ssmValue: `${kmsAlias}`,
      tags: extendedBaseTags,
    });
  }
}
