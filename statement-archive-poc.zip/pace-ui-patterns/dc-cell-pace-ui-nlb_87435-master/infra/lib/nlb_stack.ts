import * as cdk from "aws-cdk-lib";
import { Construct } from "constructs";
import { createBmoCdkHelper } from "../config/index";
import { extendedBaseTags, extendedNlbTags } from "../config/constants";
import { safeGetSSMValue } from "@bmo-cdk/common";
import { BMONLBConstruct } from "@bmo-cdk/nlb";
import { BMOSSMConstruct } from "@bmo-cdk/ssm-parameter";

export class NlbStack extends cdk.Stack {
  public readonly ecsNlb: BMONLBConstruct;

  constructor(scope: Construct, id: string, props: cdk.StackProps) {
    super(scope, id, props);

    const helper = createBmoCdkHelper(this);

    const owner = extendedBaseTags.portfolioShortCode;

    //some basic attributes
    const accountId: string = helper.deployment.accountId;
    const stage: string = helper.deployment.stage;
    const accountShortCode: string = helper.deployment.accountShortCode;
    const environment: string = helper.deployment.environment;
    const stageShortCode: string = helper.deployment.stageShortCode;
    const region: string = helper.deployment.region;
    const regionShortCode: string = helper.deployment.regionShortCode;
    const serviceName: string = helper.application.serviceName;

    //set NLB name
    const nlbName = `${accountShortCode}-${stageShortCode}-${regionShortCode}-${serviceName}-nlb`; //customize name of your NLB (max 32 characters)

    //available serverless ssm private subnets
    const privSubNet1 = safeGetSSMValue(this,`/ceng/${accountShortCode}/shared/${environment}/${regionShortCode}/infra/ntwrk/subn/subnet-sharednet-01-prv1`,"subnet-bypassSynthesis");
    const privSubNet2 = safeGetSSMValue(this,`/ceng/${accountShortCode}/shared/${environment}/${regionShortCode}/infra/ntwrk/subn/subnet-sharednet-01-prv2`,"subnet-bypassSynthesis");
    const privSubNet3 = safeGetSSMValue(this,`/ceng/${accountShortCode}/shared/${environment}/${regionShortCode}/infra/ntwrk/subn/subnet-sharednet-01-prv3`,"subnet-bypassSynthesis");

    //available serverless ssm vpc id
    const vpcId = safeGetSSMValue(this,`/ceng/${accountShortCode}/shared/${environment}/${regionShortCode}/infra/ntwrk/vpc/vpc-netres-01`, "vpc-bypassSynthesis");

    //availability zones in cc1
    const cc1az = ["ca-central-1a", "ca-central-1b", "ca-central-1d"];

    //debugging
    console.log(`nlb name: ${nlbName}`);
    console.log(`private subnet: ${privSubNet1}, ${privSubNet2}, ${privSubNet3}`);
    console.log(`ssm vpcid is ${vpcId}`);

    //NLB - Network Load Balancer
    this.ecsNlb = new BMONLBConstruct(this,`${serviceName}-${stage}-nlbEcs`,{
      vpcId: vpcId,
      privateSubnetIds: [privSubNet1, privSubNet2, privSubNet3],      // minimum 2 subnets
      // availabilityZones: [subAz1,subAz2],                          // minimum 2 az (optional)
      //privateSubnetRouteTableIds: [subRt1,subRt2],                  // minimum 2 rt (optional)
      loadBalancerName: nlbName,
      deletionProtection: false,
      tags: extendedNlbTags,
    });

    // export new NLB name in SSM parameter
    const ecsNlbNameSsm = new BMOSSMConstruct(this,`${serviceName}-${stage}-SSM-ecsNlb-name`,{
      ssmName: `/${owner}/${serviceName}/${stage}/${regionShortCode}/ecs/nlb/name`,
      ssmDescription: `ECS Network Load Balancer Name Parameter for ${serviceName} CDK Version`,
      ssmType: "String",
      ssmValue: nlbName, //output is nlb name
      tags: extendedNlbTags,
    });

    // export new NLB arn in SSM parameter
    const ecsNlbArnSsm = new BMOSSMConstruct(this,`${serviceName}-${stage}-SSM-ecsNlb-arn`,{
      ssmName: `/${owner}/${serviceName}/${stage}/${regionShortCode}/ecs/nlb/arn`,
      ssmDescription: `ECS Network Load Balancer ARN Parameter for ${serviceName} CDK Version`,
      ssmType: "String",
      ssmValue: this.ecsNlb.nlb.loadBalancerArn, //output is nlb arn
      tags: extendedBaseTags,
    });

    // export new NLB dns in SSM parameter
    const ecsNlbDnsSsm = new BMOSSMConstruct(this,`${serviceName}-${stage}-SSM-ecsNlb-dns`,{
      ssmName: `/${owner}/${serviceName}/${stage}/${regionShortCode}/ecs/nlb/dns`,
      ssmDescription: `ECS Network Load Balancer DNS Parameter for ${serviceName} CDK Version`,
      ssmType: "String",
      ssmValue: this.ecsNlb.nlb.loadBalancerDnsName, //output is nlb dns
      tags: extendedBaseTags,
    });

  }
}
