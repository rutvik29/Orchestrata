import * as cdk from "aws-cdk-lib";
import { Construct } from "constructs";
import { createBmoCdkHelper } from "../config/index";
import { extendedBaseTags, extendedNlbTags } from "../config/constants";
import { GetSSMValue, safeGetSSMValue } from "@bmo-cdk/common";
import { BMONLBTGConstruct } from "@bmo-cdk/nlb";
import { BMOSSMConstruct } from "@bmo-cdk/ssm-parameter";

export class NlbTgStack extends cdk.Stack {
  public readonly ecsNlbTg: BMONLBTGConstruct;

  constructor(scope: Construct, id: string, props: cdk.StackProps) {
    super(scope, id, props);

    const helper = createBmoCdkHelper(this);

    const owner = extendedBaseTags.portfolioShortCode;

    //some basic attributes
    const accountId: string = helper.deployment.accountId;
    const stage: string = helper.deployment.stage;
    const accountShortCode: string = helper.deployment.accountShortCode;
    const environment: string = helper.deployment.environment;
    const stageShortCode: string = helper.deployment.stageShortCode;
    const region: string = helper.deployment.region;
    const regionShortCode: string = helper.deployment.regionShortCode;
    const serviceName: string = helper.application.serviceName;

    //set NLB Target Group name
    const tgName = `${accountShortCode}-${stageShortCode}-${regionShortCode}-${serviceName}-nlbtg`; //max 32 characters

    //get Nlb attributes
    const nlbName = GetSSMValue(this, `/${owner}/${serviceName}/${stage}/${regionShortCode}/ecs/nlb/name`);
    const nlbArn = safeGetSSMValue(this, `/${owner}/${serviceName}/${stage}/${regionShortCode}/ecs/nlb/arn`, 'arn:aws:elasticloadbalancing:ca-central-1:123456789012:loadbalancer/fake-to-pass-synthesis');

    //available serverless ssm vpc id
    const vpcId = GetSSMValue(this,`/ceng/${accountShortCode}/shared/${environment}/${regionShortCode}/infra/ntwrk/vpc/vpc-netres-01`);

    //acm arn for certificate
    const sslArn = 'TBD';

    //debugging
    console.log(`target group name: ${tgName}`);
    console.log(`nlb name: ${nlbName}`);
    console.log(`nlb arn: ${nlbArn}`);
    console.log(`ssm vpcid: ${vpcId}`);
  

    // Network Load Balancer Target Group
    this.ecsNlbTg = new BMONLBTGConstruct(this, `${serviceName}-${stage}-nlbEcs-tg`, {
      vpcId: `${vpcId}`,
      targetGroupName: `${tgName}`,
      listenerCertificateARN: `${sslArn}`,
      loadBalancerName: `${nlbName}`,
      port: 80,
      targetType: "ip", // default is set to instance Review when dealing with targetGroupARN
      tags: extendedBaseTags,
      routingProtocol: 'TCP',
      listenerPort: 443,
      loadBalancerARN: `${nlbArn}`
    });


    // export new NLB Target Group arn in SSM parameter
    new BMOSSMConstruct(this, `${serviceName}-${stage}-SSM-ecsNlb-tg-arn`, {
      ssmName: `/${owner}/${serviceName}/${stage}/${regionShortCode}/ecs/nlb/tg/arn`,
      ssmDescription: 'NLB Target Group ARN Parameter for ${serviceName} CDK Version',
      ssmType: 'String',
      ssmValue: this.ecsNlbTg.nlbtg.ref,  //output is nlb tg arn
      tags: extendedBaseTags
    });

  }
}
