import * as cdk from "aws-cdk-lib";
import { createBmoCdkHelper } from "./index";

const app = new cdk.App();

const helper = createBmoCdkHelper(app);

// refer to https://bmo.atlassian.net/wiki/spaces/MA2324/pages/838956465/Tags+-+Observability for recommneded manatory tags
export const extendedBaseTags = {
  ...helper.tags,
  resourceIdentifier: "hub-cg",
  STO: "Franklin Siu",
  cellShortName: helper.deployment.accountShortCode,
  portfolioShortCode: "dc"
};

export const edc81n1Accounts = {
  dev: '851725409436',
  test: '905418177351',
  prod1: '381492264538',
};

// refer to https://bmo.atlassian.net/wiki/spaces/CG2V/pages/524616536/AWS+Discount+Tag+Mapping for available discount tags
export const tibcoCostSavingTags = {
  AWSOpensearchService: "commN6RVK7YPJY",
  AWSDynamoDB: "commN6RVK7YPJY",
  AWSKinesis: "commN6RVK7YPJY",
  AWSRDS: "commN6RVK7YPJY",
  AWSRedshift: "commN6RVK7YPJY",
  AWSNeptune: "commN6RVK7YPJY",
  AWSDocumentdb: "commN6RVK7YPJY",
  AWSElastiCache: "commN6RVK7YPJY",
  AWSGlue: "commN6RVK7YPJY",
  AWSAthena: "commN6RVK7YPJY",
  AWSCloudWatch: "migN6RVK7YPJY",
  AWSLambda: "migN6RVK7YPJY",
  AWSS3: "migN6RVK7YPJY",
  AWSAPIGateway: "migN6RVK7YPJY",
  AWSKeyManagementService: "migN6RVK7YPJY",
  AWSSecretsManager: "migN6RVK7YPJY",
  AWSSQS: "migN6RVK7YPJY",
  AWSStepFunctions: "migN6RVK7YPJY",
  AWSSNS: "migN6RVK7YPJY",
  AWSCodebuild: "migN6RVK7YPJY",
  AWSCognito: "migN6RVK7YPJY",
  AWSEC2: "migN6RVK7YPJY",
  AWSEBS: "migN6RVK7YPJY",
  AWSECS: "migN6RVK7YPJY",
  AWSSagemaker: "migN6RVK7YPJY",
  AWSElasticLoadBalancing: "migN6RVK7YPJY",
  AWSManagedStreamingForApacheKafka: "migN6RVK7YPJY",
  AWSFsx: "migN6RVK7YPJY",
  AWSInspector: "migN6RVK7YPJY",
  AWSElasticFileSystem: "migN6RVK7YPJY",
  AWSBackup: "migN6RVK7YPJY",
  AWSDatasync: "migN6RVK7YPJY"
};

export const extendedNlbTags = {
  ...extendedBaseTags,
  'map-migrated': tibcoCostSavingTags.AWSKeyManagementService,
};