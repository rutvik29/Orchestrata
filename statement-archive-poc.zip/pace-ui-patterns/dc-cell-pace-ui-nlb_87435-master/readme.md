# Blank template
Reference: https://bmo.atlassian.net/wiki/spaces/AUTOMATE/pages/645864213/Empty+Template

# Load Balancer and Target Group for PBB-US (PACE) Fargate Container
Use the controller.json to toggle deployment of each stack separately or together; becareful of dependencies (see below).
Sequence as follows:

## 1. NLB DEPLOYMENT
1. Deploy NLB Stack and get record of new NLB DNS

## 2. NLB TARGET GROUP DEPLOYMENT
1. Ensure NLB is deployed successfully
2. Ensure you have certificate is loaded to ACM and SSL ARN is provided
3. Deploy NLB Target Group
