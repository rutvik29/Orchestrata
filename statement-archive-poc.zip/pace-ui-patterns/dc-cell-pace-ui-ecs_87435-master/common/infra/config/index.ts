import { configurationHelperFactory } from '@bmo-cdk/common'
import { PurposeCode } from '@bmo-cdk/common/lib/configurationHelper/CommonConfigurationHelperTypes'

/* <Note>
    Please validate the following values. 
    Some of the values were set when creating the repository.
    Please change the values if necessary.
*/
export const createBmoCdkHelper = configurationHelperFactory({
    appCatId: '<%= appCatId %>', // App Cat ID 
    projectName: '<%= projectName %>', // Alphanumeric only, the project name (e.g., CENG)
    serviceName: '<%= serviceName %>', // Alphanumeric and hyphens only
    serviceDescription: '<%= serviceDescription %>', // Any text
    purposeCode: <%= purposeCodeEnum %>, // Purpose code of the multi account. Use PurposeCode.NONE for old account.
    costCenter: '<%= costCenter %>', // Cost Center
    supportTeam: 'RUN_ENG_CLOUD_PLATFORM_SUPPORT', // Support team
})
