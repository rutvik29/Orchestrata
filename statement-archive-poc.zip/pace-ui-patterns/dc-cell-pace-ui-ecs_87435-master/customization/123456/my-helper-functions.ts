export const getPi = () => 3.1415926
