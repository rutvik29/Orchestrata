# Application Patterns

## Golden source for user workflows
Please copy files from this folder: https://github.com/BMO-Prod/CENG_application-patterns_TU9916/tree/master/common/.github to user repository's .github folder
<p>The .github/wrokflows folder are the workflows of this repository, not the template to be copied.</p>

## Local development guide
1. Copy common/infra/config/index.ts to [pattern]/infra/config/index.ts
2. Update the copied file with your test values

Note: The files in [pattern]/infra/config/index.ts are added to .gitignore and will not be committed
