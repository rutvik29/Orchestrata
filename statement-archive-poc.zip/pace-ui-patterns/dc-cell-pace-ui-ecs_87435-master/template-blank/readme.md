# Blank template
Reference: https://bmo.atlassian.net/wiki/spaces/AUTOMATE/pages/645864213/Empty+Template