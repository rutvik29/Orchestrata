# Static Website Application Pattern

The Static Website Application Pattern aims to provide a simple, low-cost solution for hosting static content and single-page applications, without the need to manage servers or containers.

For more details, please review the [Application Pattern docs](./docs/).

Please spend time updating your application specific documentation within this readme.

## Use Cases

- This pattern would be utilized for hosting the static content, primarily the SPA (Public Client), with Public Content
- The use case covers un-authenticated connection from a user on BMO private network connecting to a static content on S3
- No classified data is permitted

Please note in this app pattern is only for static web conent hosting without any auth system to connect to API backend.

## Requirements

- The app uses an `index.html` file from an SPA, and expects that file to be present
- No classified data allowed
- Internal useage only
- All data is accessed via AD Azure Auth token

## Prerequisites Tasks

- Determine the domain name of your application
- Verify S3 interface VPC endpoints and SSM params exists in the target accounts
   - [Contact Cloud Platform Support for assistance](https://bmo.atlassian.net/wiki/spaces/HCPSUP/pages/410747424/Cloud+Deployments+Requests+Platform+Support)
  - A dedicated S3 interface endpoint is required in each Business domain Shared Net Account Netresource VPC. There is no requirement to create S3 interface endpoint for each Static webhosting deployment.
  - SSM Params must be published using BMO standard naming for the application to deploy correctly
  - See implementation details in this document for details on the VPC endpoint and security group policies.
- Obtain an SSL certificate from the enterprise certificate management
  - [Venafi is our certificate management system](https://bmo.atlassian.net/wiki/spaces/IE/pages/360453196/Request+Venafi+Certificate)
- Upload the SSL certificate to the AWS account
   - Contact Cloud Platform Support for assistance
- Deploy the solution, referencing the chosen domain name and SSl certificates
- Create DNS entries in the enterprise DNS management
   - Open a service now request under [Hostmaster DNS Request](https://bmogc.service-now.com/sp?id=sc_cat_item&sys_id=17c8ca6edb480c10c634362f9d9619b6)
   - Home -> Service Catalog -> IT for IT -> DDI Hostmaster -> Hostmaster DNS Request
- Request the compliance exceptions for your project.
   - Follow the process on this page: https://bmo.atlassian.net/wiki/x/U5woHg
   - You can use the following line for the correct exceptions: `all:[E022=20,E029,E031]`
- Begin app development

## Getting started

This repo provides everything needed to get started with this type of application. Please follow the below getting started steps to ensure the application deploys as expected.

- Install depedencies in the `infra` directories
- Update infrastructure-as-code configurations under `infra/config/index.ts`
- Develop your application under the `service` directory, usually by running an SPA bootstrap script
- Update the build.sh with application build commands which will build your app in the pipeline
- Follow the standard pull request & deployment process, available here: [CDK-v2 Guide for GitHub Actions](https://bmo.atlassian.net/wiki/spaces/CUDP/pages/751082146/CDK-v2+Guide+for+Github+Actions)

## Further reading

- [Application Pattern docs](./docs/)

## Architecture

![architecture diagram](./docs/architecture.png)
