# Pattern Controls

| SL# | Security Domain | Controls |
| --- | --- | --- |
| 1 | Identity & Access Management | The pattern is required to allow anonymous access to the S3 hosting the Static Webpage through the S3 interface endpoint. The anonymous access is restricted to the s3:GetObject action only. E031 exception is required to deploy S3 Bucket for this pattern.|
| | | The pattern uses the IAM Role to upload the static web page content to the S3 bucket. |
| | | In the case of the SPA Public Client use case, no authentication is required to access the SPA page from the S3, but the authentication must be enabled in the code when the client connects to AWS API from the browser. Refer SPA Authentication pattern documentation for addtional details. Align to End User Azure AD Authentication and BMO Application integration with Azure AD patterns to integrate SPA public client with Azure AD. All the Azure AD Conditional access policies are evaluated when the user logs in to the application. |
| 2 | Data Security | The scope of this pattern is for only SPA (Public Clients) and Static webpages, which are classified as public content Because; 1) The pattern is not leveraging the AWS KMS as the AWS KMS doesn't support anonymous requests. 2)The Static Content in the S3 can't be encrypted by AWS Key Management Service (AWS KMS) to enable anonymous access. |
| | | The static objects are encrypted using server-side encryption with Amazon S3 managed keys (SSE-S3). |
| | | Requires E029 Exception while deploying the S3 Bucket for this pattern. |
| 3 | Application Development Security | The SPA must be inline with the Public client specification. |
| | | SPA or Static content must not have any secret or confidential data. |
| 4 | Endpoint Security | Follow the existing DevSecOps vulnerability scanning pattern to scan the code and the content while deploying the content to S3. |
| 5 | Network Security | A new dedicated S3 interface endpoint is required in each NetRes VPC, which allows anonymous access for the s3:GetObject only. Because: 1) The default BMO interface endpoint policy for S3 allows access only to all the S3 in the BMO Account. 2) Since the request is Anonymous, and our pattern doesn't use the IAM role, the policy is not applicable for this request, and it blocks access. |
| | | The dedicated Static web hosting S3 Interface endpoint's and allow access from workload VPC CIDR. |
| | | ALB is configured with FQDN Based Routing. The bucket name is unique across the globe. So ALB will deny the connection towards any other S3 bucket. |
| | | The pattern uses secured and encrypted protocols like HTTPS and TLS 1.2 extra. |
| | | The pattern uses a custom domain name and the Venafi-issued certificate to terminate the TLS session at AWS ALB. |
| | | We are waiting for AWS to come up with either the option to refer security group in security group rule across two VPCs which are connected over transit gateway or the Static IP support with ALB, to enhance this pattern. |
| 6 | Security Monitoring and Analytics | Align to BMO Cloud Security Management Standard by integrating security activity logs with Splunk SIEM, leveraging pattern - PTN-SMA-01(AWS) - Logging and Monitoring - SOC Integration with BMO AWS |
| | | Align to BMO’s Security Event Management Standard by ensuring monitoring of logs for any unauthorized activity |
| | | Avoid storing sensitive data in logs |
| 7 | Security Incident Response | Align to BMO’s Security Event Management Standard by leveraging pattern - PTN-SMA-02(AWS) - Incident Alerting and Response - SOC Integration with BMO AWS |
| 8 | Secure Configuration and Change control | Align to Assets Management and BMO Cloud Security Management Standard for asset management. |
| | | Align to Change Management Process for change control. |