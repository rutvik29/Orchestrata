# Application Pattern Documentation

The Static Website Application Pattern aims to provide a simple, low-cost solution for hosting static content and single-page applications, without the need to manage servers or containers. Refer to the [solution design pattern](https://bmo.atlassian.net/wiki/spaces/IEC/pages/633289959/BMO+AWS+S3+Static+Webhosting+Pattern+V1.1) for additional details.

![architecture diagram](architecture.png)

## Use Cases

- This pattern would be utilized for hosting the static content, primarily the SPA (Public Client), with Public Content
- The use case covers un-authenticated connection from a user on BMO private network connecting to a static content on S3
- No classified data is permitted

Please note in this app pattern is only for static web conent hosting without any auth system to connect to API backend.

## Requirements

- The app uses an `index.html` file from an SPA, and expects that file to be present
- No classified data allowed
- Internal useage only
- All data is accessed via AD Azure Auth token

## Prerequisites Tasks

- Determine the domain name of your application
- Verify S3 interface VPC endpoints and SSM params exists in the target accounts
  - [Contact Cloud Platform Support for assistance](https://bmo.atlassian.net/wiki/spaces/HCPSUP/pages/410747424/Cloud+Deployments+Requests+Platform+Support)
  - A dedicated S3 interface endpoint is required in each Business domain Shared Net Account Netresource VPC. There is no requirement to create S3 interface endpoint for each Static webhosting deployment.
  - SSM Params must be published using BMO standard naming for the application to deploy correctly
  - See implementation details in this document for details on the VPC endpoint and security group policies.
- Obtain an SSL certificate from the enterprise certificate management
  - [Venafi is our certificate management system](https://bmo.atlassian.net/wiki/spaces/IE/pages/360453196/Request+Venafi+Certificate)
- Upload the SSL certificate to the AWS account
  - Contact Cloud Platform Support for assistance
- Deploy the solution, referencing the chosen domain name and SSl certificates
- Create DNS entries in the enterprise DNS management
  - Open a service now request under [Hostmaster DNS Request](https://bmogc.service-now.com/sp?id=sc_cat_item&sys_id=17c8ca6edb480c10c634362f9d9619b6)
  - Home -> Service Catalog -> IT for IT -> DDI Hostmaster -> Hostmaster DNS Request
- Request the compliance exceptions for your project.
   - Follow the process on this page: https://bmo.atlassian.net/wiki/x/U5woHg
   - You can use the following line for the correct exceptions: `all:[E022=20,E029,E031]`
- Begin app development

## Design Details

- As the AWS S3 Webhosting feature is only for public website endpoints, this pattern does not leverage the S3 Static Webhosting feature.
- Instead, this pattern serves the static content by sending a Get request to the S3 interface Rest API Endpoint.
- To identify the bucket when we connect to the S3 via the interface endpoint, the bucket name and URL must be the same. The pattern leverages the ability to create a bucket with an FQDN and the S3 bucket identification based on the FQDN. Refer to AWS Documentation for additional details.
- No AWS IAM principal or IAM role is involved in the BMO S3 static web hosting pattern to access the static content on S3.
- Anonymous access must be enabled at the S3 Interface endpoint and the bucket policy for the s3:GetObject action.
- The exiting bucket policy requires Authentication header to allow the S3 access. E031 exception is required to deploy S3 Bucket for this pattern.
- As AWS KMS doesn't support anonymous requests, Objects can't be encrypted by AWS Key Management Service (AWS KMS). Refer to the AWS documentation for additional details. Requires E029 Exception while deploying the S3 Bucket for this pattern.
- The pattern leverages the internal AWS Application load balancer to support the custom domain name for HTTPS traffic to terminate the TLS session.
- Since the ALB health checks host headers will not contain a domain name, S3 will return a non-200 HTTP response code. We need to add 307,405" to the health check success codes to overcome this challenge.
- As the S3 private Link Endpoint is a Rest API Endpoint, a trailing slash request will return XML directory listings by default. To overcome this challenge, a redirect rule is required to create in AWS ALB to point all requests ending in a trailing slash to the home page.
- This pattern leverages the the existing BMO CDK module to deploy S3 bucket and upload the Static content to the S3 bucket. The exceptions E031, E029 are required while creating S3 bucket for this pattern.
- AWS Security group rule referencing another security group across two VPCs which are connected over transit gateway is not currently supported. Since the Shared Net VPC uses transit gateway to connect to NetRes VPC , this pattern cannot leverage the Security group rule references.
- Security rule referencing the another security group across account is supported. The VPCs must be either peered or shared VPC to support the Cross account Security group reference. BMO Leverages transit gateway to interconnect VPCs.
- The Security group reference across TGW is on the AWS roadmap for Q2 ‘24. Initially it was released last year but rolled back.
- AWS ALB currently lacks the support for the static IP address.
- Since the Client IP is preserved when we specify NLB target by application load balancer type, we need to allow the Client CIDR block at ALB Network security group. Refer the AWS documentation for additional details.

## Observability & Logging

### User Connection to the ALB

- Access Logs are enabled on the ALB. Access logs capture detailed information about requests received by the load balancer and stored on a logging s3 bucket
- VPC Flow Logs which captures IP traffic going to and from network interfaces attached to the ALB.

### ALB connection to Target Group

- VPC Flow Logs which captures IP traffic going to and from network interfaces of the target group. The logs would be delivered to a logging s3 bucket

### S3 Bucket

- Server Access logging would be enabled on the S3 bucket, Server access logging provides detailed records for the requests that are made to a bucket. The logs would be delivered to a logging s3 bucket

## Resiliency

- The architecture leverages two load balancers, VPC endpoints and S3 storage.
- All services are multi-availability zone by default. If there is one issue in an availability zone, the solution will handle traffic routing to other availability zones.
- The solution is not multi-region compatible
- The availability of these solutions are configured to be resilient, and leverage AWS managed services where possible

## Organization Defaults

### CORS (Cross Origin Resource Sharing) for SPA

Cross-origin resource sharing (CORS) is a mechanism that allows restricted resources on a web page to be accessed from another domain outside the domain from which the web page was served. CORS should be considered when connecting the SPA to an API. Refer to the [BMO API access pattern here](https://bmo.atlassian.net/wiki/spaces/SCEAC/pages/498107523/PTN-EIAM-70+Employee+access+to+BMO+API+updated+2.1).

## Dependencies

- The Website must have a default page like index.html, which is required to configure an ALB redirect rule to point all requests ending in a trailing slash.
- The BMO S3 Webhosting pattern is for internal use only. The end-user network details (CIDR) list is required to configure ALB Security Group.
- For the non-prod environment, the recommended approach is to use the SSG to access the Website. Then, we are required to allow only the SSG IPs, 10.230.4.33/10.231.4.33 IPs, at the ALB.
- Request to assess the requirement and allow the connection only from the required end-user network.
- Request a Certifcicate specific for your Project team website domain, Request process [Venafi Certificate Request Process](https://bmo.sharepoint.com/sites/InformationSecurity/Documents/Website_Docs/Application_Security_Services_Documents/Services_Software/ckm/Venafi_Aperture_User_Procedures.pdf#search=Venafi)
- DNS and Certificates should be created for each environment
- VPC endpoint and SSM params should be used for each environment

From <https://bmo.atlassian.net/wiki/spaces/IEC/pages/633289959/BMO+AWS+S3+Static+Webhosting+Pattern+V1.1>

## Implementation Details

### Interface Endpoint Policy

A sample Interface endpoint policy is given below. In this policy we are allowing the access from 10.0.0.0/8 for the s3:GetObject action. Further network restrictions are enforced at the ALB Network Security level.

```JSON
{
  "Condition": {
    "IpAddressIfExists": {
      "aws:SourceIp": ["10.0.0.0/8"]
    }
  },
  "Action": "s3:GetObject",
  "Resource": "*",
  "Effect": "Allow",
  "Principal": "*",
  "Sid": "S3StaticWebhosting"
}
```

### Interface Endpoint Security Group

Create a security group to allow the connection from the workload VPC CIDR on Port 443 and assign it to the new S3 interface endpoint. It is recommended to create IP Prefix list to create the security group rule.

We will whitelist the Workload VPC CIDR until, AWS come up with either the option to refer the security group in the security group rule across two VPCs connected over the transit gateway or the Static IP support with ALB to enhance this pattern.

Task 3- ALB Routing rule
As mentioned in the solution highlight, an addtional redirect rule is required to redirect all requests ending in a trailing slash to the default home page.

A sample CDK Code snippet of the ALB listener rule is given below.

```typscript
listenerRule: [
  {
    actions: [
      {
        type: "redirect",
        redirectConfig: {
          protocol: "HTTPS",
          statusCode: "HTTP_301",
          path: "/#{path}index.html",
          port: "443",
          host: "#{host}",
        },
      },
    ],
    conditions: [
      {
        field: "path-pattern",
        pathPatternConfig: {
          values: ["*/"],
        },
      },
    ],
  },
];
```

### S3 Bucket creation and Bucket Policy.
When deploying the S3 Bucket for this pattern, the project team needs to raise exceptions E031, E029. Refer the security control section for addtional details.

And in the bucket policy allow access from the Dedicated interface endpoint for the s3:GetObject action only.

Additional permissions are required for the CDK pipelines to push the content to S3 bucket. Follow the existing pattern for those requirements.

A sample S3 Bucket Policy to allow permission access through interface endpoint is given below.

```JSON
{
  "Sid": "Access-to-specific-VPCE-only",
  "Effect": "Allow",
  "Principal": "*",
  "Action": "s3:GetObject",
  "Resource": [
    "arn:aws:s3:::onedevops-sbx.devhcloud.bmogc.net",
    "arn:aws:s3:::onedevops-sbx.devhcloud.bmogc.net/*"
  ],
  "Condition": {
    "StringEquals": {
      "aws:SourceVpce": "vpce-0a6167e314d360ef3"
    }
  }
}
```

## References

### BMO pattern References

- [S3 Build CDK Modules](https://bmo.atlassian.net/wiki/spaces/AUTOMATE/pages/243269807)
- [Exception Approval process](https://bmo.atlassian.net/wiki/spaces/AUTOMATE/pages/541229683)
- [Exception E031](https://bmo.atlassian.net/wiki/spaces/AUTOMATE/pages/529039955)
- [Exception E029](https://bmo.atlassian.net/wiki/spaces/AUTOMATE/pages/529039624)
- [TN-EIAM-61 End user Azure AD Authentication and SSO](https://bmo.atlassian.net/wiki/spaces/ENTARCH/pages/294912868)
- [Guidelines to enable Authentication in SPA using the PKCE](https://bmo.atlassian.net/wiki/spaces/ESA/pages/287179718/PTN-EIAM-50+App+End+User+Access+to+BMO+Applications+using+Azure+AD+as+Identity+Provider)

### External Reference

- [AWS Pattern Reference for Private Static Webhosting](https://bmo.atlassian.net/wiki/spaces/AUTOMATE/pages/243269807)
- [Limitation with Anonymous access](https://bmo.atlassian.net/wiki/spaces/AUTOMATE/pages/541229683)
- [S3 with Domain name (FQDN) and access pattern](https://docs.aws.amazon.com/AmazonS3/latest/userguide/VirtualHosting.html#VirtualHostingCustomURLs)
- [VPC endpoint Policy](https://docs.aws.amazon.com/vpc/latest/privatelink/vpc-endpoints-access.html#vpc-endpoint-policies)
- [S3 Bucket Policy for VPC endpoints](https://docs.aws.amazon.com/AmazonS3/latest/userguide/example-bucket-policies-vpc-endpoint.html)
- [Data Perimeter White paper](https://docs.aws.amazon.com/whitepapers/latest/building-a-data-perimeter-on-aws/perimeter-implementation.html)

## Support & Operations

- Please reach out to BMO AWS Cloud Support Team using ServiceNow Portal.
