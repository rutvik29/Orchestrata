### Install dependencies for CDK code
pushd infra
pnpm i --shamefully-hoist=true
popd 


### Prepare artifact to be uploaded to S3
pushd service
# Step 1: Build your artifacts if necessary (e.g., `npm run build`)

# Step 2: Package the artifact into a zip file, the same zip file name is used in CDK code.
zip -r s3.zip .
popd
