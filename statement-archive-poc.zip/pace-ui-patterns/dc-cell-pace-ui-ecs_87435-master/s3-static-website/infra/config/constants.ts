/**
 * Add other variables here
 */
export const constants = {
    iamRoleName: 's3-static-website-deployment-role',
    bucketName: '<Please fill in your domain name>', // This must match with the domain name
    bucketDeploymentName: 's3-static-website-deployment',
    certificateArn: '<Please fill in your certificate arn>',
}