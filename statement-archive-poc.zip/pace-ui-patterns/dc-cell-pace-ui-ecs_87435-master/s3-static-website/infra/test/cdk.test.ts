import assert from 'assert';
import { Node } from 'constructs';
import { Template } from 'aws-cdk-lib/assertions';
import { openSync, closeSync, unlinkSync } from 'fs'

jest.mock('../controller.json', () => ({
    "stacks": "F"
}), { virtual: true })

jest.spyOn(Node.prototype, 'tryGetContext')
    .mockImplementation((arg: string) => {
        switch (arg) {
            case 'Stage':
                return 'dev'
            case 'stageShortCode':
                return 'dev'
            case 'accountID':
                return '123412341234'
            case 'accountShortCode':
                return 'abcd'
            case 'environment':
                return 'dev'
            case 'region':
                return 'ca-central-1'
            case 'regionShortCode':
                return 'ca1'
            case 'DynatraceNodeLayer':
                return 'arn:aws:lambda:ca-central-1:260773135411:layer:bmo-dynatrace-node-layer:10'
            case 'DynatraceJavaLayer':
                return 'arn:aws:lambda:ca-central-1:260773135411:layer:bmo-dynatrace-java-layer:8'
            case 'DynatracePythonLayer':
                return 'arn:aws:lambda:ca-central-1:260773135411:layer:bmo-dynatrace-python-layer:14'
            case 'DynatraceCompatibleRuntimes':
                return JSON.stringify(['java8.al2', 'java11', 'java17', 'java21', 'nodejs16.x', 'nodejs18.x', 'nodejs20.x', 'python3.8', 'python3.9', 'python3.10', 'python3.11', 'python3.12'])
            default:
                return undefined
        }
    })

process.env = {
    VALIDATE_APPCATID: '7777778',
    VALIDATE_APPCATID2: '7777778',
    CDK_CONTEXT_JSON: JSON.stringify({ "environment": "dev", "Stage": "dev" }),
    ALLOWED_EXCEPTIONS: 'E022=10,E029=10,E031=10'
}

beforeAll(() => {
    closeSync(openSync('../service/s3.zip', 'w'));
})

afterAll(() => {
    unlinkSync('../service/s3.zip');
})

test('Test CDK stacks', async () => {
    const { constants } = await import('../config/constants')
    constants.bucketName = 'unit-test.devhcloud.bmogc.net'
    constants.certificateArn = 'arn:aws:acm:ca-central-1:123412341234:certificate/12345678-1324-1234-1234-1234567890ab'

    const infra = await import('../bin/infra')

    assert(infra.iamStack != null)
    Template.fromStack(infra.iamStack).resourceCountIs('AWS::IAM::Role', 1);

    assert(infra.networkStack != null)
    const networkStackTemplate = Template.fromStack(infra.networkStack);

    networkStackTemplate.resourceCountIs('AWS::EC2::SecurityGroup', 2);
    networkStackTemplate.resourceCountIs('AWS::ElasticLoadBalancingV2::LoadBalancer', 2);
    networkStackTemplate.resourceCountIs('AWS::ElasticLoadBalancingV2::TargetGroup', 2);
    networkStackTemplate.resourceCountIs('AWS::ElasticLoadBalancingV2::Listener', 3);

    assert(infra.s3WebsiteStack != null)
    const s3WebsiteStackTemplate = Template.fromStack(infra.s3WebsiteStack);
    s3WebsiteStackTemplate.resourceCountIs('AWS::S3::Bucket', 1);
    s3WebsiteStackTemplate.resourceCountIs('AWS::Lambda::Function', 1);
});
