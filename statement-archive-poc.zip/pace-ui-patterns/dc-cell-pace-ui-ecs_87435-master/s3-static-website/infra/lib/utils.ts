import { GetSSMValue } from "@bmo-cdk/common"
import { Construct } from "constructs"

export const safeGetSSMValue = (construct: Construct, name: string, dummy: string = '') => {
    const value = GetSSMValue(construct, name)
    if (value.startsWith('dummy-value-for')) {
        return dummy
    } else {
        return value
    }
}

export const safeGetCidrBlock = (cidrBlock: string) => cidrBlock === '1.2.3.4/5' ? '10.0.0.0/32' : cidrBlock