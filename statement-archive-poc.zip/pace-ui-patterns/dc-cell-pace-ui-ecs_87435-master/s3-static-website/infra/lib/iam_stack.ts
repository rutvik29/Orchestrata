import { Stack, StackProps } from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { BMOIAMConstruct } from '@bmo-cdk/iam';
import { createBmoCdkHelper } from '../config';
import { constants } from '../config/constants';

export class IamStack extends Stack {
  constructor(scope: Construct, id: string, props: StackProps) {
    super(scope, id, props);

    const helper = createBmoCdkHelper(this)

    new BMOIAMConstruct(this, helper.namingHelpers.toResourceFullName(constants.iamRoleName), {
      roleName: helper.namingHelpers.toResourceFullName(constants.iamRoleName),
      roleDescription: 'IAM role for s3 asset deployment to s3 bucket',
      pathOverride: '/',
      associatedAppCatID: [helper.tags.AppCatID],
      assumeRolePolicyDocument: {
        Version: '2012-10-17',
        Statement: [
          {
            Sid: 'AssumeRole',
            Effect: 'Allow',
            Principal: {
              Service: 'lambda.amazonaws.com',
            },
            Action: 'sts:AssumeRole',
          },
        ],
      },
      managedPolicyArns: ['arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole'],
      policies: [
        {
          policyName: 's3-deployment-policy',
          policyDocument: {
            Version: '2012-10-17',
            Statement: [
              {
                Action: [
                  's3:GetObject*',
                  's3:GetBucket*',
                  's3:List*',
                  's3:DeleteObject*',
                  's3:PutObject',
                  's3:PutObjectLegalHold',
                  's3:PutObjectRetention',
                  's3:PutObjectTagging',
                  's3:PutObjectVersionTagging',
                  's3:Abort*',
                ],
                Resource: [helper.namingHelpers.toS3BucketArn(constants.bucketName), `${helper.namingHelpers.toS3BucketArn(constants.bucketName)}/*`],
                Effect: 'Allow',
              },
            ],
          },
        },
      ],
      tags: helper.tags
    });
  }
}
