import { BMOBucketConstruct } from "@bmo-cdk/s3";
import { BMOBucketDeploymentConstruct } from "@bmo-cdk/s3deployment";
import { StackProps, Stack } from "aws-cdk-lib";
import { Construct } from "constructs";
import { createBmoCdkHelper } from "../config";
import { GetSSMValue } from "@bmo-cdk/common";
import { constants } from "../config/constants";

export class S3WebsiteStack extends Stack {
    constructor(scope: Construct, id: string, props: StackProps) {
        super(scope, id, props);

        const helper = createBmoCdkHelper(this);

        const s3Bucket = new BMOBucketConstruct(this, helper.namingHelpers.toResourceFullName(constants.bucketName), {
            bucketName: constants.bucketName,
            versioned: true,
            isBatchBucket: false,
            isDataTransition: false,
            kmsKeyArn: '',
            bucketKeyEnabled: false,
            encryption: 'aes256',
            disablePresignedPost: true,
            addPolicyStatement: [
                {
                    Sid: 'shared-role access',
                    Effect: 'Allow',
                    Principal: {
                        AWS: [helper.iamRoleArn.deployerRole],
                    },
                    Action: [
                        's3:AbortMultipartUpload',
                        's3:GetBucketAcl',
                        's3:GetBucketLocation',
                        's3:GetObject',
                        's3:ListBucket',
                        's3:ListBucketMultipartUploads',
                        's3:PutObject',
                        's3:DeleteObject',
                    ],
                    Resource: [helper.namingHelpers.toS3BucketArn(constants.bucketName), `${helper.namingHelpers.toS3BucketArn(constants.bucketName)}/*`],
                },
                {
                    Sid: 'Access-to-specific-VPCE-only',
                    Principal: '*',
                    Action: 's3:GetObject',
                    Effect: 'Allow',
                    Resource: [helper.namingHelpers.toS3BucketArn(constants.bucketName), `${helper.namingHelpers.toS3BucketArn(constants.bucketName)}/*`],
                    Condition: {
                        StringEquals: {
                            'aws:SourceVpce': GetSSMValue(this, `/ceng/${helper.deployment.accountShortCode}/local/${helper.deployment.environment}/${helper.deployment.regionShortCode}/infra/ntwrk/s3/interfaceendpoint/id`),
                        },
                    },
                },
            ],
            nonCurrentVersionExpirationInDays: 30,
            exceptionCode: ['E029', 'E031'],
            tags: helper.tags
        });

        new BMOBucketDeploymentConstruct(this, helper.namingHelpers.toResourceFullName(constants.bucketDeploymentName), {
            bucketArn: s3Bucket.s3Bucket.bucketArn,
            filename: ["../service/s3.zip"],
            role: helper.namingHelpers.toIamRoleArn(helper.namingHelpers.toResourceFullName(constants.iamRoleName)),
            storageClass: 'INTELLIGENT_TIERING',
            serverSideEncryption: 'AES_256',
            tags: helper.tags
        });
    }
}