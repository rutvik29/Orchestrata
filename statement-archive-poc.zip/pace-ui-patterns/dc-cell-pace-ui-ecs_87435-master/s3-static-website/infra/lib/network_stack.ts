import { BMOALBConstruct, BMOALBTGConstruct, BMOALBListenerConstruct } from "@bmo-cdk/alb";
import { BMONLBConstruct, BMONLBTGConstruct } from "@bmo-cdk/nlb";
import { BMOSecurityGroupConstruct } from "@bmo-cdk/security-group";
import { StackProps, Stack } from "aws-cdk-lib";
import { Construct } from "constructs";
import { createBmoCdkHelper } from "../config";
import { GetSSMValue } from "@bmo-cdk/common";
import { constants } from "../config/constants";
import { safeGetCidrBlock, safeGetSSMValue } from './utils';

export class NetworkStack extends Stack {
    constructor(scope: Construct, id: string, props: StackProps) {
        super(scope, id, props);

        const helper = createBmoCdkHelper(this);
        const availabilityZones = helper.deployment.region === 'ca-central-1' ?
                ['ca-central-1a', 'ca-central-1b', 'ca-central-1d']
                : ['us-east-1b', 'us-east-1c', 'us-east-1d']

        const ipAddresses = safeGetSSMValue(
            this, 
            `/ceng/${helper.deployment.accountShortCode}/local/${helper.deployment.environment}/${helper.deployment.regionShortCode}/infra/ntwrk/s3/interfaceendpoint/ip`,
            '10.0.0.1,10.0.0.2,10.0.0.3'
        ).split(',')
        
        const { nlb } = new BMONLBConstruct(this, helper.namingHelpers.toResourceFullName('nlb'), {
            loadBalancerName: helper.namingHelpers.toResourceFullName('nlb'),
            vpcId: GetSSMValue(this, helper.ssmParamemterName.network.sharedWorkloadVpc.vpcId),
            availabilityZones,
            privateSubnetIds: GetSSMValue(this,
                [
                    helper.ssmParamemterName.network.sharedWorkloadVpc.subnet1Id,
                    helper.ssmParamemterName.network.sharedWorkloadVpc.subnet2Id,
                    helper.ssmParamemterName.network.sharedWorkloadVpc.subnet3Id
                ]
            ),
            tags: helper.tags
        });
        
        const { sg } = new BMOSecurityGroupConstruct(this, helper.namingHelpers.toResourceFullName('security-group'), {
            groupDescription: 'Security group for the static website',
            vpcId: GetSSMValue(this, helper.ssmParamemterName.network.sharedWorkloadVpc.vpcId),
            groupName: helper.namingHelpers.toResourceFullName('security-group'),
            tags: helper.tags,
            exceptionCode: ['E022'],
            securityGroupIngress: [
                {
                    ipProtocol: '-1',
                    cidrIp: '199.181.202.0/24',
                    description: 'Ingress rule for S3',
                    fromPort: -1,
                    toPort: -1,
                },
                {
                    ipProtocol: '-1',
                    cidrIp: '161.39.19.0/24',
                    description: 'Ingress rule for S3',
                    fromPort: -1,
                    toPort: -1,
                },
                {
                    ipProtocol: '-1',
                    cidrIp: '198.96.178.33/32',
                    description: 'Ingress rule for S3',
                    fromPort: -1,
                    toPort: -1,
                },
                {
                    ipProtocol: '-1',
                    cidrIp: '198.96.180.245/32',
                    description: 'Ingress rule for S3',
                    fromPort: -1,
                    toPort: -1,
                },
                ...(nlb.vpc?.privateSubnets || []).map(subnet => ({
                    ipProtocol: '-1',
                    cidrIp: safeGetCidrBlock(subnet.ipv4CidrBlock),
                    description: 'Ingress rule for NLB',
                    fromPort: -1,
                    toPort: -1
                }))
            ],
            securityGroupEgress: [
                {
                    ipProtocol: '-1',
                    cidrIp: `${ipAddresses[0]}/32`,
                    description: 'Egress rule for S3 VPCE',
                    fromPort: -1,
                    toPort: -1,
                },
                {
                    ipProtocol: '-1',
                    cidrIp: `${ipAddresses[1]}/32`,
                    description: 'Egress rule for S3 VPCE',
                    fromPort: -1,
                    toPort: -1,
                },
                {
                    ipProtocol: '-1',
                    cidrIp: `${ipAddresses[2]}/32`,
                    description: 'Egress rule for S3 VPCE',
                    fromPort: -1,
                    toPort: -1,
                },
            ],
            s3AccessRequired: true,
        });

        const { alb } = new BMOALBConstruct(this, helper.namingHelpers.toResourceFullName('alb'), {
            loadBalancerName: helper.namingHelpers.toResourceFullName('alb'),
            vpcId: GetSSMValue(this, helper.ssmParamemterName.network.sharedWorkloadVpc.vpcId),
            availabilityZones,
            privateSubnetIds: GetSSMValue(this,
                [
                    helper.ssmParamemterName.network.sharedWorkloadVpc.subnet1Id,
                    helper.ssmParamemterName.network.sharedWorkloadVpc.subnet2Id,
                    helper.ssmParamemterName.network.sharedWorkloadVpc.subnet3Id
                ]
            ),
            securityGroupID: sg.attrGroupId,
            tags: helper.tags
        });

        new BMOALBTGConstruct(this, helper.namingHelpers.toResourceFullName('alb-tg'), {
            vpcId: GetSSMValue(this, helper.ssmParamemterName.network.sharedWorkloadVpc.vpcId),
            targetGroupName: helper.namingHelpers.toResourceFullName('alb-tg'),
            port: 443,
            routingProtocol: 'HTTPS',
            targetType: 'ip',
            targets: [...Array(3)].map((_, i) => 
                ({
                    id: ipAddresses[i],
                    availabilityZone: availabilityZones[i],
                    port: 443
                })
            ),
            healthCheckPath: '/',
            healthCheckPort: '443',
            loadBalancerARN: alb.loadBalancerArn,
            listenerPort: 443,
            httpCode: '200,307,405,403',
            albSecurityGroupID: sg.attrGroupId,
            listenerCertificateARN: constants.certificateArn,
            tags: helper.tags
        });

        new BMOALBListenerConstruct(this, helper.namingHelpers.toResourceFullName('alb-listener'), {
            albArn: alb.loadBalancerArn,
            listenerPort: 80,
            protocol: 'HTTPS',
            listenerCertificateARN: constants.certificateArn,
            albSecurityGroupID: sg.attrGroupId,
            defaultActions: [
                {
                    type: 'redirect',
                    redirectConfig: {
                        statusCode: 'HTTP_301',
                        path: '/#{path}index.html',
                        port: '443',
                        host: '#{host}',
                    },
                },
            ],
        });


        new BMONLBTGConstruct(this, helper.namingHelpers.toResourceFullName('nlb-tg'), {
            vpcId: GetSSMValue(this, helper.ssmParamemterName.network.sharedWorkloadVpc.vpcId),
            targetGroupName: helper.namingHelpers.toResourceFullName('nlb-tg'),
            loadBalancerARN: nlb.loadBalancerArn,
            port: 443,
            targetType: 'alb',
            targets: [
                {
                    id: alb.loadBalancerArn
                }
            ],
            listenerPort: 443,
            routingProtocol: 'TCP',
            healthCheckProtocol: 'HTTPS',
            tags: helper.tags
        });
    }
}
