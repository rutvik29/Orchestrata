export CONTAINER_ARTIFACTS="WINDOWS"
export ECR_REPO="tanveer-test-repo-v2"
export ECR_TAG="lts2022-1"
export PROMOTE_IMAGE_URI="$TargetAccountNumber.dkr.ecr.ca-central-1.amazonaws.com/tanveer-test-repo-v2:lts2022-1"
cp -R service infra
pushd infra
pnpm i --shamefully-hoist=true
popd    


