import * as cdk from 'aws-cdk-lib';
import { BMOEcrRepositoryConstruct } from '@bmo-cdk/ecr';
import { GetSSMValue } from "@bmo-cdk/common";
import { createBmoCdkHelper } from '../config';
import { Construct } from 'constructs';


export class EcrStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);
    
    const helper = createBmoCdkHelper(this)

    let regionShortCode = helper.deployment.regionShortCode
    let AccountShortCode = helper.deployment.accountShortCode;
    let Environment = helper.deployment.environment;
    
    let promoteImageURI='';
    let createEcrRepository = true;

    const ecr= new BMOEcrRepositoryConstruct (this, 'MyEcrConstruct',  {
      createEcrRepository,
      customImageTag:"v1" ,
      repositoryName: helper.application.serviceName,
      imageMutability: 'MUTABLE', 
      promoteImageURI,
      encryptionType: 'KMS',
      kmsKey:  GetSSMValue(this,`/tie/cea/${helper.deployment.stage}/${helper.deployment.region}/ecr/kms/key/name`),
      readWriteRoles: [helper.iamRoleArn.deployerRole], 
      lifecyclePolicy:{lifecyclePolicyText:JSON.stringify({
              "rules": [
                {
                    "rulePriority": 2,
                    "description": "Expire images older than 60 days",
                    "selection":{
                        "tagStatus": "tagged",
                        "tagPrefixList":["latest"],
                        "countType": "sinceImagePushed",
                        "countUnit": "days",
                        "countNumber": 60
                    },
                    "action": {
                        "type": "expire"
                    }
                }
            ]
          })},
      tags: helper.tags,  
    });
   
  } 
}
