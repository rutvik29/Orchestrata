/**
 * Add other variables here
 */
export const constants = {
    ecrRepositoryName: "my-ecrrepo",
}