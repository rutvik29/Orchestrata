# Global Docs

Use this directory for global docs that get copied to every application pattern.

## Files

| Filename | Domain | Description |
| --- | --- | --- |
| security.md | Security Engineering | Document with links to universal security documents. |
