# Security Documentation

## Security References
- [CDK Security Exceptions](https://bmo.atlassian.net/wiki/spaces/AUTOMATE/pages/243271442/BMO+CDK+Policy+Enforcement+Rules+-+Exception+List)
- [Cloud Change Process](https://bmo.atlassian.net/wiki/spaces/HCPSUP/pages/425262783/Cloud+Services+Change-Incident+Management+Process)
- Cloud Security Management Standard # TODO
- Security Event Management Standard # TODO
- Asset Security Management Standard # TODO

## SOC Integration
- [Logging & Monitoring SOC Integration](https://bmo.atlassian.net/wiki/spaces/PR023886/pages/322733278/Logging+Monitoring+SOC+Integration)
- [Incident Alerting & Response SOC Integration](https://bmo.atlassian.net/wiki/spaces/PR023886/pages/322732330/Incident+Alerting+and+Response+SOC+Integration)
