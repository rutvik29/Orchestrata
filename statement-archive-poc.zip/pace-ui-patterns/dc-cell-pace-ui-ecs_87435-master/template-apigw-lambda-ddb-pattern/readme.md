# Serverless API Pattern (API Gateway + Lambda + DynamoDB)

The Serverless API Application Pattern aims to provide a simple, low-cost solution for creating APIs and a nosql database, without the need to manage servers or containers.

For more details, please review the Application Pattern docs.

## Use Cases

- This pattern would be utilized for creating APIs
- The use case covers API connecting and interacting with serverless DynamoDB which can be accessed by an API with no need of SQL 
- The use case covers the authentication of the token from the requester via lambda authorizer

Please note in this app pattern is only for creating service/API without any auth system, however this requires the requester to do the authentication before calling this service.

## Requirements

- This pattern uses any programming language like python, Node.js or Java etc to code for the lambda
- Lambda requires an IAM role to be able to interact with DynamoDB, which is included in the pattern
- The API response should return in less than 29 seconds 

## Prerequisites Tasks 

- Verify custom domain name for the API Gateway end point exists 
- Verify account limits are not reached for API Gateway, Lambda, DynamoDB

## Getting started

This repo provides everything needed to get started with this type of application. Please follow the below getting started steps to ensure the application deploys as expected.
- Install depedencies in the infra and service directories
- Update infrastructure-as-code configurations under `infra/config/index.ts`
- Develop the app in the `service` directory
- Follow the standard pull request & deployment process, available here: [CDK-v2 Guide for GitHub Actions](https://bmo.atlassian.net/wiki/spaces/CUDP/pages/751082146/CDK-v2+Guide+for+Github+Actions)
 
## Further reading

- [Application Pattern docs](./docs/)

## Architecture

![architecture diagram](./docs/architecture.png)

## Legacy Documentation

- [Blueprint first time setup guide](https://bmo.atlassian.net/wiki/spaces/AUTOMATE/pages/704878485/Blueprint+first+time+setup+guide)
- [Blueprint documentation](https://bmo.atlassian.net/wiki/spaces/AUTOMATE/pages/633100275/Serverless+pattern+ApiGateway+Lambda+DynamoDB)
