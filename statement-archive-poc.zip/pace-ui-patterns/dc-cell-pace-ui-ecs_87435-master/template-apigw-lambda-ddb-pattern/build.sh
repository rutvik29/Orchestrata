pushd infra
pnpm i --shamefully-hoist=true
popd 

pushd service/api-lambda
pnpm i --shamefully-hoist=true
npx tsc
popd
