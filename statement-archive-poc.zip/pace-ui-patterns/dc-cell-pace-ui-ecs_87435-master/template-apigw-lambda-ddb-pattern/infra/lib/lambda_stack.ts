import * as cdk from 'aws-cdk-lib';
import { GetSSMValue } from '@bmo-cdk/common';
import { BMOLambdaConstruct } from '@bmo-cdk/lambdafunction';
import { Construct } from 'constructs';
import { createBmoCdkHelper } from '../config';
import { constants } from '../config/constants';


interface LambdaStackProps extends cdk.StackProps {
  apiId: string;
}

export class LambdaStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props: LambdaStackProps) {
    super(scope, id, props);

    const helper = createBmoCdkHelper(this)

    new BMOLambdaConstruct(this, helper.namingHelpers.toResourceFullName(constants.lambdaShortName), {
      functionName: helper.namingHelpers.toResourceFullName(constants.lambdaShortName),
      functionRelativePath: `../service/api-lambda`,
      handler: 'index.handler',
      resourceBasedPolicyConf: [
        {
          'principal': 'apigateway.amazonaws.com',
          'action': 'lambda:InvokeFunction',
          'sourceArn': `${helper.namingHelpers.toExecuteApiArn(props.apiId)}/*/*/*`
        }
      ],
      environmentVariables: {
        'DDB_TABLE_NAME': constants.dynamodbTableShortName
      },
      runtime: 'nodejs18.x',
      tags: helper.tags,
      subnetIds: GetSSMValue(this,
        [
          helper.ssmParamemterName.network.sharedWorkloadVpc.subnet1Id,
          helper.ssmParamemterName.network.sharedWorkloadVpc.subnet2Id
        ]
      ),
      securityGroupIds: GetSSMValue(this, [helper.ssmParamemterName.network.sharedWorkloadVpc.lambdaSecurityGroupId]),
      lambdaLogGroupKmsKeyArn: helper.namingHelpers.toKmsKeyArn(GetSSMValue(this, helper.ssmParamemterName.kmsKey.cloudWatchLogsKeyId)),
      lambdaLogRetentionInDays: 30,
      existingRoleArn: helper.namingHelpers.toIamRoleArn(constants.lambdaExecutionRoleShortName),
      dynatraceConfig: true,
      timeout: 30
    });
  }
}
