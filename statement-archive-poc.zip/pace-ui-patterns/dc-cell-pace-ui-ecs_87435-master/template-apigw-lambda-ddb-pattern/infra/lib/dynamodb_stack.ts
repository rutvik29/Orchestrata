import * as cdk from 'aws-cdk-lib';
import { BMODDBConstruct } from '@bmo-cdk/dynamodb';
import { Construct } from 'constructs';
import { GetSSMValue } from '@bmo-cdk/common';
import { createBmoCdkHelper } from '../config';
import { constants } from '../config/constants';

export class DynamoDBStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props: cdk.StackProps) {
    super(scope, id, props);

    const helper = createBmoCdkHelper(this)

    new BMODDBConstruct(this, helper.namingHelpers.toResourceFullName(constants.dynamodbTableShortName), {
      tableName: constants.dynamodbTableShortName,
      billingMode: 'PAY_PER_REQUEST',
      keySchema: [
        {
          attributeName: "id",
          keyType: "HASH"
        },
        {
          attributeName: "myRangeAttribute",
          keyType: "RANGE"
        }
      ],
      attributeDefinitions: [
        {
          attributeName: "id",
          attributeType: "S"
        },
        {
          attributeName: "myRangeAttribute",
          attributeType: "S"
        }
      ],
      kmsMasterKeyId: GetSSMValue(this, helper.ssmParamemterName.kmsKey.dynamoKeyId),
      tags: helper.tags,
    });
  }
}
