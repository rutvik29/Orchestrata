import * as cdk from 'aws-cdk-lib';
import { BMOIAMConstruct } from "@bmo-cdk/iam";
import { Construct } from 'constructs';
import { createBmoCdkHelper } from '../config';
import { constants } from '../config/constants';

export class IamStack extends cdk.Stack {

    constructor(scope: Construct, id: string, props: cdk.StackProps) {
        super(scope, id, props);

        const helper = createBmoCdkHelper(this)
        new BMOIAMConstruct(this, helper.namingHelpers.toResourceFullName(constants.lambdaExecutionRoleShortName), {
            roleName: helper.namingHelpers.toResourceFullName(constants.lambdaExecutionRoleShortName),
            roleDescription: `IAM role for ${helper.application.serviceName} lambda execution`,
            assumeRolePolicyDocument: {
                "Version": "2012-10-17",
                "Statement": [
                    {
                        "Effect": "Allow",
                        "Principal": {
                            "Service": "lambda.amazonaws.com"
                        },
                        "Action": "sts:AssumeRole"
                    }
                ]
            },
            policies: [
                {
                    policyName: 'dynamodb-crud-policy',
                    policyDocument: {
                        Version: '2012-10-17',
                        Statement: [
                            {
                                "Effect": "Allow",
                                "Action": [
                                    "dynamodb:GetShardIterator",
                                    "dynamodb:Scan",
                                    "dynamodb:Query",
                                    "dynamodb:DescribeStream",
                                    "dynamodb:GetRecords",
                                    "dynamodb:ListStreams"
                                ],
                                "Resource": [
                                    `${helper.namingHelpers.toDynamodbTableArn(constants.dynamodbTableShortName)}/index/*`,
                                    `${helper.namingHelpers.toDynamodbTableArn(constants.dynamodbTableShortName)}/stream/*`
                                ]
                            },
                            {
                                "Effect": "Allow",
                                "Action": [
                                    "dynamodb:BatchGetItem",
                                    "dynamodb:BatchWriteItem",
                                    "dynamodb:ConditionCheckItem",
                                    "dynamodb:PutItem",
                                    "dynamodb:DescribeTable",
                                    "dynamodb:DeleteItem",
                                    "dynamodb:GetItem",
                                    "dynamodb:Scan",
                                    "dynamodb:Query",
                                    "dynamodb:UpdateItem"
                                ],
                                "Resource": helper.namingHelpers.toDynamodbTableArn(constants.dynamodbTableShortName)
                            },
                            {
                                "Effect": "Allow",
                                "Action": "dynamodb:DescribeLimits",
                                "Resource": [
                                    helper.namingHelpers.toDynamodbTableArn(constants.dynamodbTableShortName),
                                    `${helper.namingHelpers.toDynamodbTableArn(constants.dynamodbTableShortName)}/index/*`
                                ]
                            }
                        ]
                    }
                }
            ],
            managedPolicyArns: [
                'arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole',
                'arn:aws:iam::aws:policy/service-role/AWSLambdaVPCAccessExecutionRole'
            ],
            associatedAppCatID: [helper.application.appCatId],
            tags: helper.tags
        });
    }
}
