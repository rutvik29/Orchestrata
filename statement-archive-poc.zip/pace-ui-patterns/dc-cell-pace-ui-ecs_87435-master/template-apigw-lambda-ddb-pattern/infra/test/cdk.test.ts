import assert from 'assert';
import { Node } from 'constructs';
import { Template } from 'aws-cdk-lib/assertions';

jest.mock('../controller.json', () => ({
    "stacks": "F"
}), { virtual: true })

jest.spyOn(Node.prototype, 'tryGetContext')
    .mockImplementation((arg: string) => {
        switch (arg) {
            case 'Stage':
                return 'dev'
            case 'stageShortCode':
                return 'dev'
            case 'accountID':
                return '123412341234'
            case 'accountShortCode':
                return 'abcd'
            case 'environment':
                return 'dev'
            case 'region':
                return 'ca-central-1'
            case 'regionShortCode':
                return 'ca1'
            case 'DynatraceNodeLayer':
                return 'arn:aws:lambda:ca-central-1:260773135411:layer:bmo-dynatrace-node-layer:10'
            case 'DynatraceJavaLayer':
                return 'arn:aws:lambda:ca-central-1:260773135411:layer:bmo-dynatrace-java-layer:8'
            case 'DynatracePythonLayer':
                return 'arn:aws:lambda:ca-central-1:260773135411:layer:bmo-dynatrace-python-layer:14'
            case 'DynatraceCompatibleRuntimes':
                return JSON.stringify(['java8.al2', 'java11', 'java17', 'java21', 'nodejs16.x', 'nodejs18.x', 'nodejs20.x', 'python3.8', 'python3.9', 'python3.10', 'python3.11', 'python3.12'])
            default: 
                return undefined
        }
    })

process.env = {
    VALIDATE_APPCATID: '7777778',
    VALIDATE_APPCATID2: '7777778',
    CDK_CONTEXT_JSON: JSON.stringify({ "environment": "dev", "Stage": "dev" })
}

test('Test CDK stacks', async () => {
    const infra = await import('../bin/infra')

    assert(infra.iamStack != null)
    Template.fromStack(infra.iamStack).resourceCountIs('AWS::IAM::Role', 1);

    assert(infra.dynamodbStack != null)
    Template.fromStack(infra.dynamodbStack).resourceCountIs('AWS::DynamoDB::Table', 1)

    assert(infra.lambdaStack != null)
    Template.fromStack(infra.lambdaStack).resourceCountIs('AWS::Lambda::Function', 1)

    assert(infra.apiGatewayStack != null)
    const apiStackTemplate = Template.fromStack(infra.apiGatewayStack);
    apiStackTemplate.resourceCountIs('AWS::ApiGateway::RestApi', 1);
    apiStackTemplate.resourceCountIs('AWS::ApiGateway::Stage', 1);
    apiStackTemplate.resourceCountIs('AWS::Logs::LogGroup', 1);
});