/**
 * Add other variables here
 */
export const constants = {
    lambdaExecutionRoleShortName: "lambda-execution-role",
    apiGatewayShortName: "my-apigateway",
    dynamodbTableShortName: "myTable",
    lambdaShortName: "my-function"
}