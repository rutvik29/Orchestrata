# Application Pattern Documentation

The Serverless Application Pattern aims to provide a simple, low-cost solution for creating APIs and nosql database, without the need to manage servers or containers.

![architecture diagram](architecture.png)

## Use Cases

- This pattern would be utilized for creating APIs
- The use case covers API connecting and interacting with serverless DynamoDB which can be accessed by an API with no need of SQL 
- The use case covers the authentication of the token from the requester via lambda authorizer

Please note in this app pattern is only for creating service/API without any auth system, however this requires the requester to do the authentication before calling this service.

## Requirements

- This pattern uses any programming language like python, Node.js or Java etc to code for the lambda
- Lambda requires an IAM role to be able to interact with DynamoDB, which is included in the pattern
- The API response should return in less than 29 seconds 

## Prerequisites Tasks

- Verify custom domain name for the API Gateway end point exists 
- Verify account limits are not reached for API Gateway, Lambda, DynamoDB

## Design Details

- API Gateway acts as a interface for the serverless service deployed in a lambda function
- All APIs are Private Rest API's
- Custom Domain Names are already defined for the API Gateway in the respective accounts
- API Gateway is configured to authenticate the incoming request by delegating it to lambda authorizer
- The lambda authorizer can validate APIC token or cognito token
- The lambda service accessess the DynamoDB table using an IAM role, included in the design
- Other than the clients within your VPC, all traffic will come through the shared network NLB via Interface end point to the API Gateway 
- API Gateway has a timeout of less than 29 secs, so make sure lambda can respond in less than 30 secs irrespective of payload size
- This pattern leverages the the existing BMO CDK module to deploy lambda and upload the  content to the Dyanmo DB table
- A custom Security Group must be created that provide firewall rules to control what IP ranges this lambda is able to reach

## Observability & Logging

### User Connection to the API Gateway

- Access Logs are enabled on the API Gateway. Access logs capture detailed information about requests received by the API Gateway and stored on a logging s3 bucket
- VPC Flow Logs which captures IP traffic going to and from network interfaces attached to the API Gateway.

### VPC end point connection to DynamoDB

- VPC Flow Logs which captures IP traffic going to and from VPC end points. The logs are delivered to a logging s3 bucket.

### DynamoDB

- Management and Insights audit events are captured by Cloudtrail and send to Splunk

## Resiliency

- The architecture leverages fully managed services by AWS.
- All services are multi-availability zone by default. If there is one issue in an availability zone, the solution will handle traffic routing to other availability zones.
- The solution is not multi-region compatible.
- The availability of these solutions are configured to be resilient, and leverage AWS managed services where possible.

## References

### Pattern References

- [API Gateway CDK Modules](https://bmo.atlassian.net/wiki/spaces/AUTOMATE/pages/243271258/bmo-cdk+apigateway)
- [DynamoDB CDK Modules](https://bmo.atlassian.net/wiki/spaces/AUTOMATE/pages/243271280/bmo-cdk+dynamodb)
- [lambda function CDK Modules](https://bmo.atlassian.net/wiki/spaces/AUTOMATE/pages/243271004/bmo-cdk+lambdafunction)
- [API Gateway Pattern](https://bmo.atlassian.net/wiki/spaces/IEC/pages/489282834/AWS+API+Gateway+Service+Pattern+v1.0)
- [TN-EIAM-61 End user Azure AD Authentication and SSO](https://bmo.atlassian.net/wiki/spaces/ENTARCH/pages/294912868)
- [Serverless pattern](https://bmo.atlassian.net/wiki/spaces/ENTARCH/pages/294912412/PTN-AW-01+AWS+Serverless+Workload+Pattern+Lambda)

### External Reference

- [Create a CRUD HTTP API with Lambda and DynamoDB](https://docs.aws.amazon.com/apigateway/latest/developerguide/http-api-dynamo-db.html)
- [Using Lambda with API Gateway](https://docs.aws.amazon.com/lambda/latest/dg/services-apigateway-tutorial.html)
- [API Gateway to Lambda to DynamoDB](https://serverlessland.com/patterns/apigw-http-api-lambda-dynamodb-python-cdk)
- [VPC endpoint Policy](https://docs.aws.amazon.com/vpc/latest/privatelink/vpc-endpoints-access.html#vpc-endpoint-policies)
- [Integrating API Gateway, Lambda and DynamoDB](https://medium.com/cloudnloud/microservices-d0e070d06c5c)
- [Data Perimeter White paper](https://docs.aws.amazon.com/whitepapers/latest/building-a-data-perimeter-on-aws/perimeter-implementation.html)

## Support & Operations

- Please reach out to BMO AWS Cloud Support Team using ServiceNow Portal.

## Detailed Architecture

- The below architecture diagrams shows the possible entry points into the pattern, through APIC, or a jump host.
- The pattern is not prescriptive regarding how the API is accessed.

![detailed architecture diagram](detailed-architecture.png)
