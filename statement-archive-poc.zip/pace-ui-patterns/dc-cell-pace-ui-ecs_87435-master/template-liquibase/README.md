# Liquibase Template Repository

Follow User Guide documentation: https://bmo.atlassian.net/wiki/spaces/CDAP/pages/656083068/Using+Liquibase+with+RDS
