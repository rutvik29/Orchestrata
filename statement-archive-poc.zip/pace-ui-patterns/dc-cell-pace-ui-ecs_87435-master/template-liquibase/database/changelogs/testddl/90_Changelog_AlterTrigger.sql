--liquibase formatted sql
--changeset sample_AlterTrigger_lastnamechanges:1 context:Altertriggerfortestingliquibase

ALTER TRIGGER last_name_changes
ON employees
RENAME TO first_name_changes;