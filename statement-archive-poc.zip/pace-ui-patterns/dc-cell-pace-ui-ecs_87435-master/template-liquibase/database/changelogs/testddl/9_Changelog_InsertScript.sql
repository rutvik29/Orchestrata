--liquibase formatted sql
--changeset sample_InsertScript_employees:1 context:Insertingfortestingliquibase

INSERT INTO employees (first_name, last_name)
VALUES ('John', 'Doe');

INSERT INTO employees (first_name, last_name)
VALUES ('Lily', 'Bush');