--liquibase formatted sql
--changeset sample_DropTrigger_firstnamechanges:1 context:Droppingtriggerfortestingliquibase

DROP TRIGGER IF EXISTS first_name_changes
ON employees;