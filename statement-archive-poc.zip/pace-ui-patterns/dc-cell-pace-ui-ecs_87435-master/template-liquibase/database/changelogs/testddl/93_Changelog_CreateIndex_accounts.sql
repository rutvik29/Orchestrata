--liquibase formatted sql

--changeset sample_createindex_idx_id:1 context:createIndexfortestingliquibase

CREATE INDEX idx_bal 
ON accounts(balance);