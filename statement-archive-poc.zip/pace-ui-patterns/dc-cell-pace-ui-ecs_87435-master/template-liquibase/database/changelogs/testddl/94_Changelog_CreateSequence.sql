--liquibase formatted sql

--changeset sample_createTable_Orderdetails:1 context:createProcedurefortestingliquibase

CREATE TABLE order_details(
    order_id SERIAL,
    item_id INT NOT NULL,
    item_text VARCHAR NOT NULL,
    price DEC(10,2) NOT NULL,
    PRIMARY KEY(order_id, item_id)
);

--changeset sample_createSequence_Orderitem:1 context:createProcedurefortestingliquibase

CREATE SEQUENCE order_item_id
START 10
INCREMENT 10
MINVALUE 10
OWNED BY order_details.item_id;