import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { createBmoCdkHelper } from '../config'
import { BMOEcrRepositoryConstruct } from '@bmo-cdk/ecr';

export class EcrStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props: cdk.StackProps) {
    super(scope, id, props);

    const helper = createBmoCdkHelper(this)

    new BMOEcrRepositoryConstruct(this, helper.namingHelpers.toResourceFullName('ecr'), {
      createEcrRepository: true,
      customImageTag: "v1",
      repositoryName: helper.application.serviceName,
      imageMutability: 'MUTABLE',
      encryptionType: 'KMS',
      kmsKey: helper.ssmParamemterName.kmsKey.lambdaKeyId,
      readWriteRoles: [helper.iamRoleArn.deployerRole],
      lifecyclePolicy: {
        lifecyclePolicyText: JSON.stringify({
          "rules": [
            {
              "rulePriority": 2,
              "description": "Expire images older than 60 days",
              "selection": {
                "tagStatus": "tagged",
                "tagPrefixList": ["latest"],
                "countType": "sinceImagePushed",
                "countUnit": "days",
                "countNumber": 60
              },
              "action": {
                "type": "expire"
              }
            }
          ]
        })
      },
      tags: helper.tags
    });
  }
}
