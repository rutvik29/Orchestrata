import * as cdk from 'aws-cdk-lib';
import { GetSSMValue } from '@bmo-cdk/common';
import { BMOAPIConstruct, BMOAPISTAGEConstruct, BMOAPIVPCLINKConstruct } from '@bmo-cdk/apigateway';
import { createOpenapi } from './swagger-api';
import { Construct } from 'constructs';
import { createBmoCdkHelper } from '../config'
import { BMOCWLGConstruct } from '@bmo-cdk/cloudwatch';
import { CustomResource } from 'aws-cdk-lib';
import { constants } from '../config/constants';

interface APIGatewayStackProps extends cdk.StackProps {
  nlbArn: string
  nlbDnsName: string
}

export class APIGatewayStack extends cdk.Stack {
  public readonly apiId: string

  constructor(scope: Construct, id: string, props: APIGatewayStackProps) {
    super(scope, id, props);

    const helper = createBmoCdkHelper(this)

    const vpcLink = new BMOAPIVPCLINKConstruct(this, helper.namingHelpers.toResourceFullName('vpc-link'), {
      name: helper.namingHelpers.toResourceFullName('vpc-link'),
      description: `VPC Link for ${helper.application.serviceName}`,
      targetArns: [props.nlbArn]
    })

    const apigateway = new BMOAPIConstruct(this, helper.namingHelpers.toResourceFullName(constants.apiGatewayShortName), {
      apiGatewayName: helper.namingHelpers.toResourceFullName(constants.apiGatewayShortName),
      description: `Api Gateway for ${helper.application.serviceName} (${helper.deployment.stage})`,
      endpointConfiguration: {
        types: ['PRIVATE'],
        vpcEndpointIds: [GetSSMValue(this, helper.ssmParamemterName.network.sharedWorkloadVpc.vpcId)]
      },
      body: createOpenapi(helper, vpcLink.vpclink.attrVpcLinkId, props.nlbDnsName),
      tags: helper.tags
    });
    this.apiId = apigateway.api.ref

    // --------------- API DEPLOYMENT ------------- //

    const apiDeployment = new CustomResource(this, 'ApiDeployment', {
      serviceToken: GetSSMValue(this, helper.ssmParamemterName.apigateway.customDeployment.serviceTokenArn),
      properties: {
        ForceUpdateValue: GetSSMValue(this, helper.ssmParamemterName.apigateway.customDeployment.forceUpdateValue),
        ApiId: this.apiId
      }
    });

    const logGroup = new BMOCWLGConstruct(this, 'APILogGroup', {
      logGroupName: helper.namingHelpers.toApigatewayLogGroupFullName(constants.apiGatewayShortName),
      retentionInDays: 30,
      kmsMasterKeyId: helper.namingHelpers.toKmsKeyArn(GetSSMValue(this, helper.ssmParamemterName.kmsKey.cloudWatchLogsKeyId)),
      tags: helper.tags
    });

    new BMOAPISTAGEConstruct(this, 'APIStage', {
      description: `API Stage ${helper.application.serviceName} ${helper.deployment.stage}`,
      restApiId: this.apiId,
      deploymentId: apiDeployment.getAttString('DeploymentId'),
      stageName: helper.deployment.stage,
      variables: { 'Stage': helper.deployment.stage },
      accessLogSetting: {
        destinationArn: logGroup.cwlLogGroup.attrArn,
        format: JSON.stringify({
          "_index": "awslogstash-$context.requestTime",
          "_type": "doc",
          "_id": "$context.requestId",
          "_version": 1,
          "_source": {
            "functionName": "$context.domainName",
            "corrId": "$context.requestId",
            "logger": "$context.apiId",
            "input_type": "log",
            "source": "/aws/api/$context.apiId",
            "epochMillis": "$context.requestTimeEpoch",
            "type": "aws:api",
            "serviceName": `${helper.application.serviceName}`,
            "tags": [],
            "jobID": "$context.requestId",
            "logstash": {
              "hostName": "",
              "location": "hub"
            },
            "@timestamp": "$context.requestTime",
            "logLevel": "INFO",
            "@version": "1",
            "beat": {
              "hostname": "",
              "name": "",
              "version": ""
            }, "host": "$context.domainName",
            "inputType": "cloudwatch",
            "detail": {
              "context.apiId": "$context.apiId",
              "context.authorizer.claims.property": "$context.authorizer.claims.property",
              "context.authorizer.principalId": "$context.authorizer.principalId",
              "context.awsEndpointRequestId": "$context.awsEndpointRequestId",
              "context.domainName": "$context.domainName",
              "context.domainPrefix": "$context.domainPrefix",
              "context.error.message": "$context.error.message",
              "context.error.messageString": "$context.error.messageString",
              "context.error.responseType": "$context.error.responseType",
              "context.error.validationErrorString": "$context.error.validationErrorString",
              "context.extendedRequestId": "$context.extendedRequestId",
              "context.httpMethod": "$context.httpMethod",
              "context.identity.accountId": "$context.identity.accountId",
              "context.identity.apiKey": "$context.identity.apiKey",
              "context.identity.apiKeyId": "$context.identity.apiKeyId",
              "context.identity.caller": "$context.identity.caller",
              "context.identity.sourceIp": "$context.identity.sourceIp",
              "context.identity.user": "$context.identity.user",
              "context.identity.userAgent": "$context.identity.userAgent",
              "context.identity.userArn": "$context.identity.userArn",
              "context.path": "$context.path",
              "context.protocol": "$context.protocol",
              "context.requestId": "$context.requestId",
              "context.responseOverride.status": "$context.responseOverride.status",
              "context.requestTime": "$context.requestTime",
              "context.requestTimeEpoch": "$context.requestTimeEpoch",
              "context.resourceId": "$context.resourceId",
              "context.resourcePath": "$context.resourcePath",
              "context.stage": "$context.stage",
              "context.wafResponseCode": "$context.wafResponseCode",
              "context.webaclArn": "$context.webaclArn",
              "context.xrayTraceId": "$context.xrayTraceId"
            },
            "esTimestamp": "$context.requestTime",
            "fields": {
              "appCatCode": `${helper.application.appCatId}`,
              "docType": "aws",
              "environmentType": "$context.stage"
            }
          },
          "fields": {
            "@timestamp": ["$context.requestTime"],
            "esTimestamp": ["$context.requestTime"]
          },
          "highlight": {
            "serviceName": [`@kibana-highlighted-field@${helper.application.serviceName}@/kibana-highlighted-field@`]
          },
          "sort": ["$context.requestTimeEpoch"]
        }),
      },
      tags: helper.tags
    });
  }
}
