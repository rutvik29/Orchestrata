import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { createBmoCdkHelper } from '../config'
import { GetSSMValue, GetSecretValue } from '@bmo-cdk/common';
import { BMOALBConstruct, BMOALBListenerConstruct, BMOALBTGConstruct } from '@bmo-cdk/alb';

export class AlbStack extends cdk.Stack {
  public readonly albArn: string;
  public readonly albTgArn: string;

  constructor(scope: Construct, id: string, props: cdk.StackProps) {
    super(scope, id, props);

    const helper = createBmoCdkHelper(this)

    const alb = new BMOALBConstruct(this, helper.namingHelpers.toResourceFullName('alb'), {
      loadBalancerName: helper.namingHelpers.toResourceFullName('alb'),
      vpcId: GetSSMValue(this, helper.ssmParamemterName.network.sharedWorkloadVpc.vpcId),
      availabilityZones: helper.deployment.region === 'ca-central-1' ?
        ['ca-central-1a', 'ca-central-1b', 'ca-central-1d']
        : ['us-east-1b', 'us-east-1c', 'us-east-1d'],
      privateSubnetIds: GetSSMValue(this,
        [
          helper.ssmParamemterName.network.sharedWorkloadVpc.subnet1Id,
          helper.ssmParamemterName.network.sharedWorkloadVpc.subnet2Id,
          helper.ssmParamemterName.network.sharedWorkloadVpc.subnet3Id
        ]
      ),
      securityGroupID: [GetSSMValue(this, helper.ssmParamemterName.network.sharedWorkloadVpc.lambdaSecurityGroupId)],
      tags: helper.tags
    });
    this.albArn = alb.alb.loadBalancerArn

    const albTargetGroup = new BMOALBTGConstruct(this, helper.namingHelpers.toResourceFullName('alb-tg'), {
      vpcId: GetSSMValue(this, helper.ssmParamemterName.network.sharedWorkloadVpc.vpcId),
      targetGroupName: helper.namingHelpers.toResourceFullName('alb-tg'),
      port: 8080,
      routingProtocol: 'HTTP',
      targetType: 'ip',
      albSecurityGroupID: GetSSMValue(this, helper.ssmParamemterName.network.sharedWorkloadVpc.lambdaSecurityGroupId),
      listenerCertificateARN: GetSecretValue(this, 'listener-certificate-arn-alb-tg', helper.ssmParamemterName.cert.clientRootCertificateSecretManagerArn),
      healthCheckPath: "/",
      healthCheckEnabled: true,
      healthCheckPort: "traffic-port",
      healthCheckIntervalSeconds: 300,
      healthCheckTimeoutSeconds: 120,
      healthyThresholdCount: 3,
      unhealthyThresholdCount: 3,
      exceptionCode: ['E011'],
      tags: helper.tags
    });
    this.albTgArn = albTargetGroup.albtg.attrTargetGroupArn

    new BMOALBListenerConstruct(this, helper.namingHelpers.toResourceFullName('alb-listener'), {
      albArn: alb.alb.loadBalancerArn,
      listenerPort: 443,
      protocol: 'HTTPS',
      listenerCertificateARN: GetSecretValue(this, 'listener-certificate-arn-alb', helper.ssmParamemterName.cert.clientRootCertificateSecretManagerArn),
      albSecurityGroupID: GetSSMValue(this, helper.ssmParamemterName.network.sharedWorkloadVpc.lambdaSecurityGroupId),
      defaultActions: [{
        type: 'forward',
        forwardConfig: {
          targetGroups: [
            {
              targetGroupArn: albTargetGroup.albtg.attrTargetGroupArn,
            }
          ]
        }
      }],
      listenerRule: [
        {
          priority: 1,
          actions: [
            {
              type: 'forward',
              forwardConfig: {
                targetGroups: [
                  {
                    targetGroupArn: albTargetGroup.albtg.attrTargetGroupArn,
                  }
                ]
              }
            }
          ],
          conditions: [
            {
              field: 'path-pattern',
              pathPatternConfig: {
                values: ['/'], // Change this to your service's context path
              }
            }
          ]
        }
      ]
    });
  }
}
