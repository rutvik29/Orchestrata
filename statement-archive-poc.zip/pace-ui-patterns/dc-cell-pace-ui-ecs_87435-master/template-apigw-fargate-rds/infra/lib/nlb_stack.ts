import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { createBmoCdkHelper } from '../config'
import { BMONLBConstruct, BMONLBTGConstruct } from '@bmo-cdk/nlb';
import { GetSSMValue, GetSecretValue } from '@bmo-cdk/common';

export interface NlbStackProps extends cdk.StackProps {
  albArn: string
}

export class NlbStack extends cdk.Stack {
  public readonly nlbArn: string;
  public readonly nlbDnsName: string;

  constructor(scope: Construct, id: string, props: NlbStackProps) {
    super(scope, id, props);

    const helper = createBmoCdkHelper(this)

    const nlb = new BMONLBConstruct(this, helper.namingHelpers.toResourceFullName('nlb'), {
      loadBalancerName: `${helper.application.serviceName}-${helper.deployment.stage}-nlb`,
      vpcId: GetSSMValue(this, helper.ssmParamemterName.network.sharedWorkloadVpc.vpcId),
      availabilityZones: helper.deployment.region === 'ca-central-1' ?
        ['ca-central-1a', 'ca-central-1b', 'ca-central-1d']
        : ['us-east-1b', 'us-east-1c', 'us-east-1d'],
      privateSubnetIds: GetSSMValue(this,
        [
          helper.ssmParamemterName.network.sharedWorkloadVpc.subnet1Id,
          helper.ssmParamemterName.network.sharedWorkloadVpc.subnet2Id,
          helper.ssmParamemterName.network.sharedWorkloadVpc.subnet3Id
        ]
      ),
      tags: helper.tags
    });
    this.nlbArn = nlb.nlb.loadBalancerArn
    this.nlbDnsName = nlb.nlb.loadBalancerDnsName

    new BMONLBTGConstruct(this, helper.namingHelpers.toResourceFullName('nlb-tg'), {
      vpcId: GetSSMValue(this, helper.ssmParamemterName.network.sharedWorkloadVpc.vpcId),
      targetGroupName: helper.namingHelpers.toResourceFullName('nlb-tg'),
      loadBalancerARN: nlb.nlb.loadBalancerArn,
      listenerCertificateARN: GetSecretValue(this, 'listener-certificate-arn', helper.ssmParamemterName.cert.clientRootCertificateSecretManagerArn),
      port: 443,
      targetType: 'alb',
      targets: [
        {
          id: props.albArn
        }
      ],
      listenerPort: 443,
      routingProtocol: 'TCP',
      tags: helper.tags
    });
  }
}
