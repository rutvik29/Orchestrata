import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { createBmoCdkHelper } from '../config'
import { GetSSMValue } from '@bmo-cdk/common';
import { BMOKMSConstruct } from '@bmo-cdk/kms';
import { BMORDSServerlessClusterConstruct } from '@bmo-cdk/rds';

export class RdsStack extends cdk.Stack {
  public readonly rdsEndpoint: string;
  constructor(scope: Construct, id: string, props: cdk.StackProps) {
    super(scope, id, props);

    const helper = createBmoCdkHelper(this)

    const rdsKmsKey = new BMOKMSConstruct(
      this,
      helper.namingHelpers.toResourceFullName('rds-kms-key'),
      {
        alias: helper.namingHelpers.toResourceFullName('rds-kms-key'),
        keyType: "platform",
        enabled: true,
        keyUsage: "ENCRYPT_DECRYPT",
        tags: helper.tags
      }
    );

    const commonConfig = {
      monitoringInterval: 60,
      monitoringRoleArn: `arn:aws:iam::${this.account}:role/SO0111-RDSMonitoring-remediationRole`,
      enableCloudwatchLogsExports: ["postgresql"]
    }

    const readerWriterConfig: Record<string, any> = {
      'ca-central-1': {
        rdsInstanceWriter: [
          {
            availabilityZone: 'ca-central-1a',
            ...commonConfig
          }
        ],
        rdsInstanceReader: [
          {
            availabilityZone: 'ca-central-1b',
            ...commonConfig
          },
          {
            availabilityZone: 'ca-central-1d',
            ...commonConfig
          }
        ]
      },
      'us-east-1': {
        rdsInstanceWriter: [
          {
            availabilityZone: 'us-east-1a',
            ...commonConfig
          }
        ],
        rdsInstanceReader: [
          {
            availabilityZone: 'us-east-1c',
            ...commonConfig
          },
          {
            availabilityZone: 'us-east-1d',
            ...commonConfig
          }
        ]
      }
    }

    const regionalRdsCluster = new BMORDSServerlessClusterConstruct(this, helper.namingHelpers.toResourceFullName('rds-cluster'), {
      rdsClusterParameterGroupFamily: 'aurora-postgresql15',
      rdsClusterParameter: {},
      rdsClusterNewSubnetGroup: true,
      rdsClusterSubnetGroupIDs: GetSSMValue(this,
        [
          helper.ssmParamemterName.network.sharedWorkloadVpc.subnet1Id,
          helper.ssmParamemterName.network.sharedWorkloadVpc.subnet2Id,
          helper.ssmParamemterName.network.sharedWorkloadVpc.subnet3Id
        ]
      ),
      rdsClusterVpcSecurityGroups: [GetSSMValue(this, helper.ssmParamemterName.network.sharedWorkloadVpc.lambdaSecurityGroupId)],
      rdsClusterKmsKeyId: rdsKmsKey.kmsKey.attrKeyId,
      rdsClusterDeletionProtection: false,
      rdsClusterEngine: 'aurora-postgresql',
      rdsClusterEngineVersion: '15',
      rdsClusterInstanceIdentifier: helper.namingHelpers.toResourceFullName('rds-cluster'),
      rdsClusterDbName: "postgres",
      rdsClusterPort: 5432,
      rdsClusterCopyTagsToSnapshot: true,
      rdsClusterStorageEncrypted: true,
      rdsClusterEnableCloudwatchLogsExports: ["postgresql"],
      rdsInstanceWriter: readerWriterConfig[helper.deployment.region].rdsInstanceWriter,
      rdsInstanceReader: readerWriterConfig[helper.deployment.region].rdsInstanceReader,
      rdsServerlessV2ScalingConfiguration: {
        maxCapacity: 32,
        minCapacity: 8,
      },
      rdsPreferredMaintenanceWindow: 'sat:04:00-sat:04:30',
      rdsClusterBackupRetentionPeriod: 35,
      customDBBackup: false,
      manageMasterUserPassword: true,
      tags: helper.tags
    })

    this.rdsEndpoint = `${regionalRdsCluster.rdsCluster.attrEndpointAddress}:${regionalRdsCluster.rdsCluster.attrEndpointPort}`
  }
}
