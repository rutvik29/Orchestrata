import * as cdk from 'aws-cdk-lib';
import { BMOIAMConstruct } from "@bmo-cdk/iam";
import { Construct } from 'constructs';
import { createBmoCdkHelper } from '../config'
import { constants } from '../config/constants';

export class IamStack extends cdk.Stack {

    constructor(scope: Construct, id: string, props: cdk.StackProps) {
        super(scope, id, props);

        const helper = createBmoCdkHelper(this)

        new BMOIAMConstruct(this, helper.namingHelpers.toResourceFullName(constants.ecsTaskRoleShortName), {
            roleName: helper.namingHelpers.toResourceFullName(constants.ecsTaskRoleShortName),
            roleDescription: `ECS Task Role for ${helper.application.serviceName}`,
            associatedAppCatID: [helper.application.appCatId],
            assumeRolePolicyDocument: {
                "Version": "2012-10-17",
                "Statement": [
                    {
                        "Sid": "AssumeRole",
                        "Effect": "Allow",
                        "Principal": {
                            "Service": ["cloudformation.amazonaws.com", "ecs-tasks.amazonaws.com", "ecs.application-autoscaling.amazonaws.com"]
                        },
                        "Action": "sts:AssumeRole"
                    }

                ]
            },
            policies: [
                {
                    policyName: 'AmazonECSTaskRolePolicy',
                    policyDocument: {
                        "Version": "2012-10-17",
                        "Statement": [
                            {
                                "Effect": "Allow",
                                "Action": [
                                    "ecr:GetAuthorizationToken",
                                    "ecr:BatchCheckLayerAvailability",
                                    "ecr:GetDownloadUrlForLayer",
                                    "ecr:BatchGetImage",
                                    "logs:CreateLogStream",
                                    "logs:PutLogEvents",
                                    "logs:DescribeLogStreams",
                                    "logs:CreateLogGroup",
                                ],
                                "Resource": "*"
                            }
                        ]
                    }
                },
            ],
            tags: helper.tags,
        });

        new BMOIAMConstruct(this, helper.namingHelpers.toResourceFullName(constants.ecsExecutionRoleShortName), {
            roleName: helper.namingHelpers.toResourceFullName(constants.ecsExecutionRoleShortName),
            roleDescription: `ECS Task Role for ${helper.application.serviceName}`,
            associatedAppCatID: [helper.application.appCatId],
            assumeRolePolicyDocument: {
                "Version": "2012-10-17",
                "Statement": [
                    {
                        "Sid": "AssumeRole",
                        "Effect": "Allow",
                        "Principal": {
                            "Service": ["cloudformation.amazonaws.com", "ecs-tasks.amazonaws.com", "ecs.application-autoscaling.amazonaws.com"]
                        },
                        "Action": "sts:AssumeRole"
                    }

                ]
            },
            policies: [
                {
                    policyName: 'AmazonECSExecutionRolePolicy',
                    policyDocument: {
                        "Version": "2012-10-17",
                        "Statement": [
                            {
                                "Effect": "Allow",
                                "Action": [
                                    "logs:CreateLogStream",
                                    "logs:PutLogEvents",
                                    "logs:DescribeLogStreams",
                                    "logs:CreateLogGroup",
                                ],
                                "Resource": "*"
                            }
                        ]
                    }
                },
            ],
            tags: helper.tags,
        });
    }
}
