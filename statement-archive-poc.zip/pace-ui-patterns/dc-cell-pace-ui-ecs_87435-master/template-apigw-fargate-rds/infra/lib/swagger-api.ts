import { GetSSMValue } from '@bmo-cdk/common';
import { ConfigurationHelperContext, PurposeCode } from '@bmo-cdk/common/lib/configurationHelper/CommonConfigurationHelperTypes';

export const createOpenapi = (helper: ConfigurationHelperContext<PurposeCode>, vpcLinkId: string, nlbDnsName: string) => {
  return {
    "openapi": "3.0.1",
    "info": {
      "version": "1.0.0",
      "title": `${helper.application.serviceName} API`,
      "description": `API for ${helper.application.serviceName}`
    },
    "paths": {
      "/": {
        "get": {
          "x-amazon-apigateway-integration": {
            "uri": `https://${nlbDnsName}`,
            "passthroughBehaviour": "when_no_match",
            "connectionType": "VPC_LINK",
            "connectionId": vpcLinkId,
            "httpMethod": "GET",
            "type": "http_proxy"
          },
          "summary": "Get response from API",
        },
        "post": {
          "x-amazon-apigateway-integration": {
            "uri": `https://${nlbDnsName}`,
            "passthroughBehaviour": "when_no_match",
            "connectionType": "VPC_LINK",
            "connectionId": vpcLinkId,
            "httpMethod": "POST",
            "type": "http_proxy"
          },
          "summary": "Post data to API",
        }
      }
    },
    "x-amazon-apigateway-policy": {
      "Version": "2012-10-17",
      "Statement": [
        {
          "Effect": "Allow",
          "Principal": "*",
          "Action": "execute-api:Invoke",
          "Resource": GetSSMValue(helper.construct, helper.ssmParamemterName.network.vpcEndpoint.executeApi),
          "Condition": {
            "StringEquals": {
              "aws:SourceVpc": GetSSMValue(helper.construct, helper.ssmParamemterName.network.sharedWorkloadVpc.vpcId)
            }
          }
        }
      ]
    }
  }
}