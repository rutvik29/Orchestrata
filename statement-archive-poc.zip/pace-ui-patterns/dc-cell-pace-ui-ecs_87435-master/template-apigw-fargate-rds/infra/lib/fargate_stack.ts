import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { createBmoCdkHelper } from '../config'
import { BMOECSClusterConstruct, BMOECSServiceConstruct, BMOECSTaskDefinitionConstruct } from '@bmo-cdk/ecs';
import { GetSSMValue } from '@bmo-cdk/common';
import { constants } from '../config/constants';

interface FargateStackProps extends cdk.StackProps {
  albTargetGroupArn: string
  rdsEndpoint: string
}

export class FargateStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props: FargateStackProps) {
    super(scope, id, props);

    const helper = createBmoCdkHelper(this)

    const containerName = helper.namingHelpers.toResourceFullName('container')
    const containerPort = 8080

    const ecsCluster = new BMOECSClusterConstruct(this, helper.namingHelpers.toResourceFullName('ecs-cluster'), {
      clusterName: helper.namingHelpers.toResourceFullName('ecs-cluster'),
      tags: helper.tags
    })

    const ecsTaskDef = new BMOECSTaskDefinitionConstruct(this, helper.namingHelpers.toResourceFullName('ecs-task-def'), {
      family: helper.namingHelpers.toResourceFullName('ecs-task-def'),
      disableAppmesh: true,
      memory: '1024',
      cpu: '512',
      executionRoleArn: helper.namingHelpers.toIamRoleArn(constants.ecsExecutionRoleShortName),
      taskRoleArn: helper.namingHelpers.toIamRoleArn(constants.ecsTaskRoleShortName),
      requiresCompatibilities: ["FARGATE"],
      containerDefinitions: [
        {
          name: containerName,
          essential: true,
          image: `${helper.deployment.accountId}.dkr.ecr.${helper.deployment.region}.amazonaws.com/${helper.application.serviceName}:v1`,
          logConfiguration: {
            logDriver: 'awsfirelens',
            options: {
              ["log_group_name"]: `/aws/ecs/${helper.application.serviceName}-${helper.deployment.stage}-container`,
              ["log_create_group"]: "true",
              ["log_format"]: "json",
              ["log_stream_prefix"]: "app",
              ["region"]: helper.deployment.region,
              ["Name"]: "cloudwatch"
            }
          },
          portMappings: [
            {
              containerPort,
              hostPort: containerPort,
              protocol: 'tcp',
            },
          ],
          readonlyRootFilesystem: true,
          environment: [
            {
              name: 'RDS_ENDPOINT',
              value: props.rdsEndpoint
            }
          ]
        }
      ],
      tags: helper.tags
    });

    new BMOECSServiceConstruct(this, helper.namingHelpers.toResourceFullName('ecs-service'), {
      cluster: ecsCluster.cluster.attrArn,
      serviceName: helper.namingHelpers.toResourceFullName('ecs-service'),
      taskDefinition: ecsTaskDef.taskdefinition.attrTaskDefinitionArn,
      subnetIds: GetSSMValue(this,
        [
          helper.ssmParamemterName.network.sharedWorkloadVpc.subnet1Id,
          helper.ssmParamemterName.network.sharedWorkloadVpc.subnet2Id,
          helper.ssmParamemterName.network.sharedWorkloadVpc.subnet3Id
        ]
      ),
      ecsLogRetentionInDays: 30,
      disableAppmesh: true,
      loadBalancers: [{
        containerPort,
        containerName,
        targetGroupArn: props.albTargetGroupArn,
      }],
      securityGroup: [GetSSMValue(this, helper.ssmParamemterName.network.sharedWorkloadVpc.lambdaSecurityGroupId)],
      deploymentConfiguration: {
        minimumHealthyPercent: 100,
        maximumPercent: 200,
        deploymentCircuitBreaker: {
          enable: true,
          rollback: true
        }
      },
      desiredCount: 1, // Number of Tasks to run
      healthCheckGracePeriodSeconds: 300,
      ecsLogGroupKmsKeyArn: helper.namingHelpers.toKmsKeyArn(GetSSMValue(this, helper.ssmParamemterName.kmsKey.cloudWatchLogsKeyId)),
      enableEcsManagedTags: true,
      propagateTags: "TASK_DEFINITION",
      tags: helper.tags
    });
  }
}
