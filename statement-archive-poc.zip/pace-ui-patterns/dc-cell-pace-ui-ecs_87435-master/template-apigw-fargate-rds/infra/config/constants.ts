/**
 * Add other variables here
 */
export const constants = {
    ecsTaskRoleShortName: "ecs-task-role",
    ecsExecutionRoleShortName: "ecs-execution-role",
    apiGatewayShortName: "my-apigateway",
}