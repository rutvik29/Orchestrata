# Container pattern (API Gateway + Fargate + RDS)
