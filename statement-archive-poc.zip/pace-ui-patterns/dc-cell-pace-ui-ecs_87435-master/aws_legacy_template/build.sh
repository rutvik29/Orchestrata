cd infra && pwd && ls -al
if [[ -f "package-lock.json" ]]; then echo "Running npm ci" && npm ci;fi;
echo "Running npm install" && npm install
FILE=package.json
cd ../service/lambda-functions/
if [ -f "$FILE" ]; then npm install;  fi   # for installing packages in lambda functions folder
