import * as cdk from 'aws-cdk-lib';
import {GetSSMValue} from '@bmo-cdk/common';
import {BMOAPIConstruct,BMOAPISTAGEConstruct} from '@bmo-cdk/apigateway';
import { CustomResource } from 'aws-cdk-lib';
import { BMOSSMConstruct } from '@bmo-cdk/ssm-parameter';
import {globals as G} from './globals';

import { Construct } from 'constructs';

export class SSMStack extends cdk.Stack {
  
  public readonly ServiceName:string;
  public readonly myLambdaFunctionTimeoutExport:BMOSSMConstruct;
  public readonly myLambdaFunctionMemorySizeExport:BMOSSMConstruct;
  public readonly myLambdaFunctionConcurrentExecutionsExport:BMOSSMConstruct;
  public readonly myUsagePlanName:BMOSSMConstruct;

  constructor(scope: Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    // The code that defines your stack goes here
    
    var Stage=this.node.tryGetContext('Stage');
    var accountID=this.node.tryGetContext('accountID');
    var stageShortCode=this.node.tryGetContext('stageShortCode');
    var regionShortCode=this.node.tryGetContext('regionShortCode');
    var Region=process.env.TargetAccountRegion;
    
    this.ServiceName = G.serviceName;
    
    // ---- SSM Parameter ------ //

    new BMOSSMConstruct(this, 'SSM-API-Name-Parameter', {
      ssmName: `/SCCG/${this.ServiceName}/${Stage}/CDK/APIGateway/Name`, 
      ssmDescription: 'API Parameter for SCCG-PartyArrangementReport CDK Version',
      ssmType: 'String',
      ssmValue: `${this.ServiceName}-${Stage}-API`,
      tags: G.taggingVars
    });

    new BMOSSMConstruct(this, 'SSM-Service-Name-Parameter', {
      ssmName: `/SCCG/${this.ServiceName}/${Stage}/CDK/ServiceName`, 
      ssmDescription: 'API Parameter for SCCG-Boilerplate CDK Version',
      ssmType: 'String',
      ssmValue: this.ServiceName,
      tags: G.taggingVars
    });

    const FunctionLogLevelExport = new BMOSSMConstruct(this, 'SSM-Function-Log-Level-Parameter', {
      ssmName: `/SCCG/${this.ServiceName}/${Stage}/CDK/Lambda/LogLevel`, 
      ssmDescription: 'API Parameter for SCCG-Boilerplate CDK Version',
      ssmType: 'String',
      ssmValue: 'DEBUG',
      tags: G.taggingVars
    });

    // GetFinancialSnapshot Lambda

    const FunctionTracingExport = new BMOSSMConstruct(this, 'SSM-Function-Tracing-Parameter', {
      ssmName: `/SCCG/${this.ServiceName}/${Stage}/CDK/Lambda/myLambdaFunction/Tracing`, 
      ssmDescription: 'API Parameter for SCCG-Boilerplate CDK Version',
      ssmType: 'String',
      ssmValue: 'Active',
      tags: G.taggingVars
    });

    const myLambdaFunctionNameExport = new BMOSSMConstruct(this, 'SSM-Function-Name-Parameter', {
      ssmName: `/SCCG/${this.ServiceName}/${Stage}/CDK/Lambda/myLambdaFunction/FunctionName`, 
      ssmDescription: 'API Parameter for SCCG-Boilerplate CDK Version',
      ssmType: 'String',
      ssmValue: `${this.ServiceName}-CDK-${Stage}-myLambdaFunction-Lambda`,
      tags: G.taggingVars
    });

    this.myLambdaFunctionConcurrentExecutionsExport = new BMOSSMConstruct(this, 'SSM-Concurrent-Executions-Parameter', {
      ssmName: `/SCCG/${this.ServiceName}/${Stage}/CDK/Lambda/myLambdaFunction/ReservedConcurrentExecutions`, 
      ssmDescription: 'API Parameter for SCCG-Boilerplate CDK Version',
      ssmType: 'String',
      ssmValue: '20',
      tags: G.taggingVars
    });

    this.myLambdaFunctionTimeoutExport = new BMOSSMConstruct(this, 'SSM-Timeout-Parameter', {
      ssmName: `/SCCG/${this.ServiceName}/${Stage}/CDK/Lambda/myLambdaFunction/Timeout`, 
      ssmDescription: 'API Parameter for SCCG-Boilerplate CDK Version',
      ssmType: 'String',
      ssmValue: '31', //28
      tags: G.taggingVars
    });

    this.myLambdaFunctionMemorySizeExport = new BMOSSMConstruct(this, 'SSM-Memory-Size-Parameter', {
      ssmName: `/SCCG/${this.ServiceName}/${Stage}/CDK/Lambda/myLambdaFunction/MemorySize`, 
      ssmDescription: 'API Parameter for SCCG-Boilerplate CDK Version',
      ssmType: 'String',
      ssmValue: '2048',
      tags: G.taggingVars
    });
  }
}
