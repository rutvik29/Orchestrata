//
//  IAM RESOURCES
//  - IAM resource changes will need cloud engineering approval. The webhook should be
//    changed to version=CloudEng (and changed back to version=v1 afterwards)
//  - CodeDeploy: the first time it runs when the prehool function is used it adds an IAM policy to the prehook function role,
//    subsequent runs will not create additional IAM changes
//

//  Stack for IAM roles
import * as cdk from 'aws-cdk-lib';
import { GetSSMValue } from '@bmo-cdk/common';
import {BMOIAMConstruct, BMOIAMPolicyConstruct} from "@bmo-cdk/iam";
import {globals as G} from "./globals";

import { Construct } from 'constructs';

export class IamStack extends cdk.Stack {

    constructor(scope: Construct, id: string, props?: cdk.StackProps) {
        super(scope, id, props);

        var _this: any = this;

        
        // mainFunction lambda role
        const mainFunctionRole = new BMOIAMConstruct(_this, 'mainFunctionRole',{
            roleName: G.mainFunctionName,
            roleDescription: 'MainFunction role',
            assumeRolePolicyDocument: {
                "Version": "2012-10-17",
                "Statement": [
                    {                                                       //  can be run by lambda service
                        "Sid": "LambdaAssumeRole",
                        "Effect": "Allow",
                        "Principal": {
                            "Service": "lambda.amazonaws.com"
                        },
                        "Action": "sts:AssumeRole"
                    },
                    // {                                                       //  can be run by api gateway
                    //     "Sid": "GatewayAssumeRole",
                    //     "Effect": "Allow",
                    //     "Principal": {
                    //         "Service": "apigateway.amazonaws.com"
                    //     },
                    //     "Action": "sts:AssumeRole"
                    //     // "SourceArn": `arn:aws:execute-api:${G.Region}:${G.accountID}:${G.apiGateway.api.ref}/*`
                    // },
                ],
            }, 
            managedPolicyArns: [                                            //  basic managed policies
                'arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole',
                'arn:aws:iam::aws:policy/service-role/AWSLambdaVPCAccessExecutionRole'
            ],
            associatedAppCatID: G.taggingVars.AppCatID,
            tags: G.taggingVars,
            exceptionCode: ["E043"],
        });
        
        // ~~~~~~~~~~~~~~~~~Extra roles/policies awaiting resource implementation ~~~~~~~~~~~~~~~~~

        // //  codeDeploy role
        // new BMOIAMConstruct(_this, 'CodeDeployTrustRole',{
        //     roleName: G.codeDeployRoleName,
        //     roleDescription: 'CodeDeploy service role',
        //     assumeRolePolicyDocument: {
        //         "Version": "2012-10-17",
        //         "Statement": [
        //             {
        //                 "Sid": "AssumeRole",
        //                 "Effect": "Allow",
        //                 "Principal": {
        //                     "Service": "codedeploy.amazonaws.com"
        //                 },
        //                 "Action": "sts:AssumeRole"
        //             }
        //         ]
        //     },
        //     managedPolicyArns: [`arn:aws:iam::aws:policy/service-role/AWSCodeDeployRoleForLambdaLimited`],
        //     associatedAppCatID: G.appCatID,
        //     tags: G.taggingVars,
        //     exceptionCode: ["E043"],
        // });

        /* Needed later *************
        // prehookFunction lambda role
        const prehookFunctionRole = new BMOIAMConstruct(_this, 'prehookFunctionRole',{
            roleName: G.prehookFunctionName,
            roleDescription: 'PrehookFunction role',
            assumeRolePolicyDocument: {
                "Version": "2012-10-17",
                "Statement": [
                    {                                                       //  can be run by lambda service
                        "Sid": "AssumeRole",
                        "Action": "sts:AssumeRole",
                        "Effect": "Allow",
                        "Principal": {
                            "Service": "lambda.amazonaws.com"
                        }
                    }
                ]
            },
            managedPolicyArns: [                                            //  basic managed policies
                'arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole',
                'arn:aws:iam::aws:policy/service-role/AWSLambdaVPCAccessExecutionRole'
            ],
            associatedAppCatID: G.appCatID,
            tags: G.taggingVars,
            exceptionCode: ["E043"],
        });
        // scannerFunction lambda role
        const scannerFunctionRole = new BMOIAMConstruct(_this, 'scannerFunctionRole',{
            roleName: G.scannerFunctionName,
            roleDescription: 'ScannerFunction role',
            assumeRolePolicyDocument: {
                "Version": "2012-10-17",
                "Statement": [
                    {                                                       //  can be run by lambda service
                        "Sid": "AssumeRole",
                        "Effect": "Allow",
                        "Principal": {
                            "Service": "lambda.amazonaws.com"
                        },
                        "Action": "sts:AssumeRole"
                    }
                ]
            },
            managedPolicyArns: [                                            //  basic managed policies
                'arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole',
                'arn:aws:iam::aws:policy/service-role/AWSLambdaVPCAccessExecutionRole'
            ],
            associatedAppCatID: G.appCatID,
            tags: G.taggingVars,
            exceptionCode: ["E043"],
        });
        ***************************************************/
        var policyName: any = null;
        var _this: any = this;

        // //  add dynamo db polices to mainFunctionRole
        // new BMOIAMPolicyConstruct(_this, 'readDynamoDB', {
        //     iamPolicy:[{
        //         managedPolicyName: G.applicationName + '-readDynamoDB',
        //         description: ``,
        //         policyDocument: {
        //             "Version": "2012-10-17",
        //             "Statement": [
        //                 {
        //                     "Action": [
        //                         "dynamodb:GetItem",
        //                         "dynamodb:Scan",
        //                         "dynamodb:Query",
        //                         "dynamodb:BatchGetItem",
        //                         "dynamodb:DescribeTable"
        //                     ],
        //                     "Resource": [
        //                         `arn:aws:dynamodb:${G.Region}:${G.accountID}:table/SCCG-CIAL-Products`
        //                     ],
        //                     "Effect": "Allow"
        //                 }
        //             ]
        //         },
        //         roles: [
        //             // `hub-cg-${stageShortCode}-cial-Lambda-helloWorld`,
        //             G.mainFunctionName,
        //         ]
        //     }
        //     ],
        //     associatedAppCatID: G.appCatID,
        //     tags: G.taggingVars,
        //     // exceptionCode: ["E043"],
        // });
        //
        // // add dynamo db write policies to helloWorldwrite lambda
        // new BMOIAMPolicyConstruct(_this, 'writeToDynamo', {
        //     iamPolicy:[{
        //         managedPolicyName: G.applicationName + '-writeToDynamo',
        //         description: ``,
        //         policyDocument: {
        //             "Version": "2012-10-17",
        //             "Statement": [
        //                 {
        //                     "Action": [
        //                         "dynamodb:PutItem",
        //                         "dynamodb:Scan",
        //                         "dynamodb:Query",
        //                         "dynamodb:BatchGetItem",
        //                         "dynamodb:DescribeTable"
        //                     ],
        //                     "Resource": [
        //                         `arn:aws:dynamodb:${G.Region}:${G.accountID}:table/SCCG-CIAL-Products`
        //                     ],
        //                     "Effect": "Allow"
        //                 }
        //             ]
        //         },
        //         roles: [
        //             // `hub-cg-${stageShortCode}-cial-Lambda-helloWorldwrite`
        //             G.mainFunctionName
        //         ]
        //     }
        //     ],
        //     associatedAppCatID: G.appCatID,
        //     tags: G.taggingVars,
        //     exceptionCode: ["E043"],
        // });

        // {
        //     'principal': 'apigateway.amazonaws.com',
        //     'action':'lambda:InvokeFunction',
        //     // 'sourceArn': `arn:aws:execute-api:${Region}:${accountID}:${GetSSMValue(_this,`/SCCG/CIAL/${G.Stage}/HelloWorldAPI/id`)}/*/POST/something`
        //     'sourceArn': `arn:aws:execute-api:${G.Region}:${G.accountID}:${G.apiGateway.api.ref}/*`
        //     // 'sourceArn': `arn:aws:execute-api:${G.Region}:${G.accountID}:${G.apiGateway.api.attrRootResourceId}/*`
        // },

        //  API resource policy  WILL NOT ALLOW POLICIES WITH PRINCIPAL
        // new BMOIAMPolicyConstruct(_this, 'api', {
        //     iamPolicy:[{
        //         managedPolicyName: `${G.applicationName}-api`,
        //         description: `Allow API to invoke lambda`,
        //         policyDocument: {
        //             "Version": "2012-10-17",
        //             "Statement": [
        //                 {
        //                     "Sid": "APIInvokeFunction",
        //                     "Action": [
        //                         "apigateway:GET",
        //                         "apigateway:POST",
        //                     ],
        //                     "Resource": [
        //                         `arn:aws:apigateway:${G.Region}:${G.accountID}:/apis/${G.apiGateway.api.ref}`
        //                     ],
        //                     "Effect": "Allow",
        //                 }
        //             ]
        //         },
        //     }],
        //     associatedAppCatID: G.appCatID,
        //     tags: G.taggingVars,
        // });
        
        /************************** Need later on
        //  add codeDeploy and lamda permissions to prehook lambda role
        new BMOIAMPolicyConstruct(_this, 'prehook', {
            iamPolicy:[{
                managedPolicyName: G.applicationName + '-prehook-codeDeploy',
                description: ``,
                policyDocument: {
                    "Version": "2012-10-17",
                    "Statement": [
                        {
                            "Action": [
                                "codedeploy:PutLifecycleEventHookExecutionStatus",
                            ],
                            "Resource": [
                                `arn:aws:codedeploy:${G.Region}:${G.accountID}:deploymentgroup:${G.applicationName}*`
                                // "*" // IMPORTANT: The console says "All resources" is required but it is WRONG
                            ],
                            "Effect": "Allow"
                        }
                    ]
                },
                roles: [
                    // `${G.prehookFunctionName}`
                    prehookFunctionRole.iamRole.ref
                ]
            },{
                managedPolicyName: G.applicationName + '-prehook-lambda',
                description: ``,
                policyDocument: {
                    "Version": "2012-10-17",
                    "Statement": [
                        {
                            "Action": [
                                "lambda:InvokeFunction",
                                "lambda:ListVersionsByFunction",
                                "lambda:ListAliases"
                            ],
                            "Resource": [
                                `arn:aws:lambda:${G.Region}:${G.accountID}:function:${G.applicationName}*`
                            ],
                            "Effect": "Allow"
                        }
                    ]
                },
                roles: [
                   // `${G.prehookFunctionName}`
                    prehookFunctionRole.iamRole.ref
                ]
            }],
            associatedAppCatID: G.appCatID,
            tags: G.taggingVars,
            exceptionCode: ["E043"],
        });
        //  Scanner policy
        new BMOIAMPolicyConstruct(_this, 'scanner', {
            iamPolicy:[{
                managedPolicyName: G.applicationName + '-scanner-lambda',
                description: ``,
                policyDocument: {
                    "Version": "2012-10-17",
                    "Statement": [
                        {
                            "Action": [
                                "lambda:List*",
                                "lambda:InvokeFunction",
                                // "lambda:ListVersionsByFunction",
                                // "lambda:ListAliases"
                            ],
                            "Resource": [
                                `arn:aws:lambda:${G.Region}:${G.accountID}:function:${G.applicationName}*`
                            ],
                            "Effect": "Allow"
                        }
                    ]
                },
                roles: [
                    // `${G.scannerFunctionName}`,
                    // `${G.mainFunctionName}`,
                    // `${G.prehookFunctionName}`
                    scannerFunctionRole.iamRole.ref,
                    mainFunctionRole.iamRole.ref,
                    prehookFunctionRole.iamRole.ref
                ]
            }],
            associatedAppCatID: G.appCatID,
            tags: G.taggingVars,
            exceptionCode: ["E043"],
        });
        *******************************/
    }
}
