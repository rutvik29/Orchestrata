import * as cdk from 'aws-cdk-lib';
import { GetSSMValue } from '@bmo-cdk/common';
import {BMOAPIConstruct} from '@bmo-cdk/apigateway';
import { CustomResource } from 'aws-cdk-lib';
import {SwaggerApi} from './swagger-api';
import { BMOSSMConstruct } from '@bmo-cdk/ssm-parameter';
import {globals as G} from './globals';

import { Construct } from 'constructs';

// interface APIGatewayStackProps extends cdk.StackProps {
//   readonly usagePlan?: BMOSSMConstruct; 
//   readonly usagePlanId?: String
// }

export class APIGatewayStack extends cdk.Stack {
  public readonly myapigw: BMOAPIConstruct;
  //public readonly usagePlanId: String

  constructor(scope: Construct, id: string, props: cdk.StackProps) {
    super(scope, id, props);
     
    let Stage = this.node.tryGetContext('Stage');
    let accountID = this.node.tryGetContext('accountID');
    let stageShortCode = this.node.tryGetContext('stageShortCode');
    let regionShortCode = this.node.tryGetContext('regionShortCode');
    let Region = process.env.TargetAccountRegion;
    let ServiceName = G.serviceName;

    let vpceIdSharedServices = GetSSMValue(this,`/tie/cea/sharedservices/${Region}/execute-api/vpc/endpoint/id`);
    const swapperAPI = new SwaggerApi(this, 'ImportSwaggerAPI');

    this.myapigw = new BMOAPIConstruct(this, 'MyAPIGW', {
      apiGatewayName:`${ServiceName}-CDK-API`,
      description: 'Api Gateway for SCCG-Boilerplate CDK Version',
      endpointConfiguration: {
          types: ['PRIVATE'],
          vpcEndpointIds: [vpceIdSharedServices]
        },
      body: swapperAPI.swaggerApiJson,
      tags: G.taggingVars
    });
    
    new BMOSSMConstruct(this, 'SSM-API-Id-Parameter', {
      ssmName: `/SCCG/${ServiceName}/CDK/APIGateway/Id`,
      ssmDescription: 'API Parameter for Boilerplate CDK Version',
      ssmType: 'String',
      ssmValue: this.myapigw.api.ref,
      tags: G.taggingVars
    });

  //   if (props.usagePlan) {
  //     let UsagePlanName = `${GetSSMValue(this, `${props.usagePlan.ssmparameter.name}`)}`

  //     console.log(`UsagePlanName: ${UsagePlanName}`)
  //     const usagePlanResource = new CustomResource(this, 'create-usage-plan', {
  //       // "arn:aws:lambda:us-east-1:520049198415:function:SCCG-CustomResource-ApiUsagePlanCustomResource-sandbox-Lambda",
  //       serviceToken: GetSSMValue(this, `/SCCG/CustomResource/ApiUsagePlanCustomResource/${Stage}/${Region}/LambdaArn`),
  //       properties: {
  //         UsagePlanName: UsagePlanName,
  //         ForceUpdateValue: true,
  //         Description: "Testing usage plan creation through custom resource, updated description and throttle, and updated",
  //         ThrottleRateLimit: 19,
  //         ThrottleBurstLimit: 15
  //       }
  //     })

  //     this.usagePlanId = usagePlanResource.ref.toString()
  //     new BMOSSMConstruct(this, 'SSM-Usage-Plan-Id', {
  //       ssmName: `/SCCG/SharedUsage/${Stage}/CDK/${UsagePlanName}/Id`, 
  //       ssmDescription: `UsagePlan Id for name: ${UsagePlanName}`,
  //       ssmType: 'String',
  //       ssmValue: `${UsagePlanName}`,
  //       tags: G.taggingVars
  //     })
  //   } else if (props.usagePlanId) {
  //     this.usagePlanId = props.usagePlanId
  //   } else {
  //     throw "Please either provide a usagePlan Name or usagePlan Id"
  //   }
   }
}
