import * as cdk from 'aws-cdk-lib';
import {GetSSMValue} from '@bmo-cdk/common';
import {BMOSSMConstruct} from '@bmo-cdk/ssm-parameter';
import {BMOLambdaConstruct} from '@bmo-cdk/lambdafunction';
import {BMOAPISTAGEConstruct} from '@bmo-cdk/apigateway';
import {BMOCWLGConstruct, BMOCWAConstruct } from '@bmo-cdk/cloudwatch';
import {globals as G} from './globals';
import { CustomResource } from 'aws-cdk-lib';

import { Construct } from 'constructs';
//import { BMOLambdaDeploymentGroupConstruct, CANARY_10PERCENT_5MINUTES } from '@bmo-cdk/codedeploy';


interface FunctionStackProps extends cdk.StackProps {
    readonly timeout:BMOSSMConstruct;
    readonly memsize:BMOSSMConstruct;
    readonly concexe:BMOSSMConstruct;
    readonly apiId: string;
}

export class FunctionStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props: FunctionStackProps) {
    super(scope, id, props);
    
    let Stage=this.node.tryGetContext('Stage');
    let accountID=this.node.tryGetContext('accountID');
    let stageShortCode=this.node.tryGetContext('stageShortCode');
    let regionShortCode=this.node.tryGetContext('regionShortCode');
    let Region=process.env.TargetAccountRegion;
    
    let ServiceName = G.serviceName;

    // --------------- MAPPING ------------- // 
    let myMappedVariable;

    switch (Stage) {
      case 'sandbox':
        myMappedVariable = "string";
        break;
      case 'dev':
        myMappedVariable = "string";
        break;
      case 'sit2':
        myMappedVariable = "string";
        break;
      case 'perf':
        myMappedVariable = "string";
        break;
      case 'prod':
        myMappedVariable = "string";
        break;
    }

    var isAccountStage;

    if (Stage == "sandbox" || Stage == "dev" || Stage == "prod") {
        isAccountStage = true;
    } else {
        isAccountStage = false;
    }

    var apiId;
    
    if (isAccountStage){
      apiId = props.apiId;
    } else {
      apiId = GetSSMValue(this, `/SCCG/${ServiceName}/CDK/APIGateway/Id`)
    };
    // --------------- ENVIRONMENT VARIABLES ------------- //
    var environmentVariables = {
      'LOGGING_LEVEL': 'DEBUG',
      'REGION': (Region) ? Region : '',
      'STAGE': (Stage) ? Stage : '', 
      'SERVICE_NAME': (ServiceName) ? ServiceName : '', 
      'CLIENTISSUINGCERTSCRTID': `/tie/cea/${Stage}/${Region}/26777/DP/MutualCerts/ClientSideCerts/ClientIssuingCert`,
      'CLIENTROOTCERTSCRTID': `/tie/cea/${Stage}/${Region}/26777/DP/MutualCerts/ClientSideCerts/ClientRootCert`,
      'SERVERCERTSCRTID': `/tie/cea/${Stage}/${Region}/26777/IngressNLB/MutualCerts/ServerSideCerts/ServerCert`,
      'SERVERKEYSCRTID': `/tie/cea/${Stage}/${Region}/26777/IngressNLB/MutualCerts/ServerSideCerts/ServerKey`
    }
    
    // --------------- LAMBDA FUNCTION ---------------- //
    console.log("Setting Reserved Concurrency --> "+ Stage=='prod'?"1":"none");
    const Boilerplate_Lambda = new BMOLambdaConstruct(this, 'Lambda-Boilerplate', {
      functionName: `${ServiceName}-CDK-${Stage}-myLambdaFunction`, 
      functionRelativePath: '../service/lambda-functions', 
      handler: 'index.myLambdaFunction', 
      functionLayerARNs: GetSSMValue(this,[`/tie/cea/${Stage}/${Region}/lambda/dynatrace/layer/nodejs`]),
      resourceBasedPolicyConf: [{ 'principal': 'apigateway.amazonaws.com', 'action':'lambda:InvokeFunction', 'sourceArn': `arn:aws:execute-api:${Region}:${accountID}:${apiId}/*/*/*`}],
      environmentVariables: environmentVariables,
      runtime: 'nodejs14.x', 
      tags: G.taggingVars,
      subnetIds: GetSSMValue(this,[`/tie/cea/${Stage}/${Region}/subnet-id-priv1`,`/tie/cea/${Stage}/${Region}/subnet-id-priv2`]),
      securityGroupIds: GetSSMValue(this,[`/tie/cea/${Stage}/${Region}/vpcsecuritygroupid`]),
      lambdaLogGroupKmsKeyArn: `arn:aws:kms:${Region}:${accountID}:key/`+GetSSMValue(this,`/tie/cea/${Stage}/${Region}/cloudwatch/kms/key/name`),
      lambdaLogRetentionInDays: 30,
      // Custom role
      reservedConcurrentExecutions: Stage=='prod'?1:undefined,
      existingRoleArn: `arn:aws:iam::${accountID}:role/${G.taggingVars.AppCatID}/${G.serviceName}/${G.mainFunctionName}`,
      // Sandbox 1 debug role
      //existingRoleArn: `arn:aws:iam::${accountID}:role/lambda-role/hub-cg-${stageShortCode}-${regionShortCode}-sccg-PAR-GetFinSnapshotRole`,
      // Sandbox 2 debug role
      //existingRoleArn: `arn:aws:iam::015329035773:role/lambda-role/tie-hc-sbx01-ue1-ApiDeploymentCustomResource-LambdaRole`,
      dynatraceConfig: true,
      timeout: parseInt(props.timeout.ssmparameter.value)
    } as any);
    
    // --------------- API DEPLOYMENT CUSTOM RESOURCE ------------- //

    const APIDeploymentCustom = new CustomResource(this, 'ApiDeployment', { 
        serviceToken: GetSSMValue(this,`/tie/hc/ApiDeploymentCustomResource/${Stage}/${process.env.TargetAccountRegion}/LambdaArn`),
        properties: {ForceUpdateValue: GetSSMValue(this,"/tie/hc/CustomResourceForceUpdate/Value"), ApiId: apiId}
    });
    console.log(`/tie/hc/ApiDeploymentCustomResource/${Stage}/${process.env.TargetAccountRegion}/LambdaArn`)
    console.log(apiId)

    // --------------- API LOG GROUP ------------- //

    const API_LogGroup = new BMOCWLGConstruct(this, 'APILogGroup', {
      logGroupName:`/aws/apigateway/sccg/accesslogs/${ServiceName}-CDK-API-${Stage}`,
      retentionInDays: 30,
      kmsMasterKeyId: `arn:aws:kms:${Region}:${accountID}:key/`+GetSSMValue(this,`/tie/cea/${Stage}/${Region}/cloudwatch/kms/key/name`),
      tags: G.taggingVars
    });

    // --------------- API STAGE DEPLOYMENT ------------- //

    const API_Stage = new BMOAPISTAGEConstruct(this, 'APIStage',{
      description: 'API Stage for SCCG-Boilerplate-CDK-API', 
      restApiId:  apiId, 
      deploymentId: APIDeploymentCustom.getAttString('DeploymentId'),
      stageName: Stage,
      variables: {'Stage': Stage},
      accessLogSetting: {
        destinationArn: API_LogGroup.cwlLogGroup.attrArn,
        format: "{\"_index\":\"awslogstash-$context.requestTime\",\"_type\":\"doc\",\"_id\":\"$context.requestId\",\"_version\":1,\"_source\":{\"offset\":2582,\"appRuntime\":\"SCCG-PartyArrangementReport\",\"functionName\":\"$context.domainName\",\"corrId\":\"$context.requestId\",\"logger\":\"$context.apiId\",\"input_type\":\"log\",\"source\":\"/aws/api/$context.apiId\",\"epochMillis\":$context.requestTimeEpoch,\"type\":\"aws:api\",\"serviceName\":\"SCCG-SCCG-PartyArrangementReport\",\"tags\":[],\"jobID\":\"$context.requestId\",\"logstash\":{\"hostName\":\"\",\"location\":\"hub\"},\"@timestamp\":\"$context.requestTime\",\"logLevel\":\"INFO\",\"@version\":\"1\",\"beat\":{\"hostname\":\"\",\"name\":\"\",\"version\":\"\"},\"host\":\"$context.domainName\",\"inputType\":\"cloudwatch\",\"detail\":\"{context.apiId:$context.apiId,context.authorizer.claims.property:$context.authorizer.claims.property,context.authorizer.principalId:$context.authorizer.principalId,context.awsEndpointRequestId:$context.awsEndpointRequestId,context.domainName:$context.domainName,context.domainPrefix:$context.domainPrefix,context.error.message:$context.error.message,context.error.messageString:$context.error.messageString,context.error.responseType:$context.error.responseType,context.error.validationErrorString:$context.error.validationErrorString,context.extendedRequestId:$context.extendedRequestId,context.httpMethod:$context.httpMethod,context.identity.accountId:$context.identity.accountId,context.identity.apiKey:$context.identity.apiKey,context.identity.apiKeyId:$context.identity.apiKeyId,context.identity.caller:$context.identity.caller,context.identity.sourceIp:$context.identity.sourceIp,context.identity.user:$context.identity.user,context.identity.userAgent:$context.identity.userAgent,context.identity.userArn:$context.identity.userArn,context.path:$context.path,context.protocol:$context.protocol,context.requestId:$context.requestId,context.responseOverride.status:$context.responseOverride.status,context.requestTime:$context.requestTime,context.requestTimeEpoch:$context.requestTimeEpoch,context.resourceId:$context.resourceId,context.resourcePath:$context.resourcePath,context.stage:$context.stage,context.wafResponseCode:$context.wafResponseCode,context.webaclArn:$context.webaclArn,context.xrayTraceId:$context.xrayTraceId}\",\"esTimestamp\":\"$context.requestTime\",\"fields\":{\"appCatCode\":\"6184\",\"cioName\":\"smartCore\",\"docType\":\"aws\",\"environmentType\":\"$context.stage\"}},\"fields\":{\"@timestamp\":[\"$context.requestTime\"],\"esTimestamp\":[\"$context.requestTime\"]},\"highlight\":{\"serviceName\":[\"@kibana-highlighted-field@SCCG-SCCG-PartyArrangementReport@/kibana-highlighted-field@\"]},\"sort\":[$context.requestTimeEpoch]}"
      },
      tags: G.taggingVars
    });
    
    // --------------- CLOUDWATCH BLUE / GREEN CANARY DEPLOYMENT ALARM  ------------- //

    const alarm = new BMOCWAConstruct(this, 'MyCWAlarm', {
      comparisonOperator: 'GreaterThanThreshold',
      threshold: 1, // alarm threshold
      period: 60,
      evaluationPeriods: 1, // all the data points within each evaluation period must be greater than or equal to the threshold for the alarm to trigger
      datapointsToAlarm: 1, // the number of data points within the Evaluation Periods that must be breaching to cause the alarm to go to the ALARM state. The breaching data points don't have to be consecutive, they just must all be within the last number of data points equal to Evaluation Period
      alarmName: `${ServiceName}-${Stage}-DeploymentAlarm`,
      alarmDescription: `Lambda CloudWatch Alarm for ${ServiceName}-${Stage}-myLambdaFunction`,
      metricName: "Errors", // ask cloud team for array of string inputs
      metricNamespace: `AWS/Lambda`,
	    dimensions: [{"name":"FunctionName","value":`${ServiceName}-CDK-${Stage}-myLambdaFunction`}],
      statistic: "Sum"
    });

    // new BMOLambdaDeploymentGroupConstruct (this, "deployment", {
    //   alias: Boilerplate_Lambda.lambdaFunction.currentVersion.addAlias('lambdaDeploy'),
    //   alarms: [alarm.cwAlarm.attrArn], // Code deploy will auto-rollback to previous version if cloudwatch alarm threshold is breached, 
    //   role:`arn:aws:iam::${accountID}:role/Lambda-Service-Role-CodeDeploy`, // used to identify a particular resource in the Amazon Web Services (AWS) public cloud (ask cloud team to create a role for both codedeploy and cloudwatch)
    //   deploymentGroupName: `${ServiceName}-CDK-${Stage}-myLambdaFunction-DeploymentGroup`,
    //   deploymentConfig: CANARY_10PERCENT_5MINUTES, // 10% is shifted from the original to the new lambda version, and then after 5 minutes, if there are no errors then the rest (90%) will shift to new lambda
    //   autoRollback: {
    //     failedDeployment: true,
    //     stoppedDeployment: true,
    //     deploymentInAlarm: true
    //   },
    // });
  }
}
