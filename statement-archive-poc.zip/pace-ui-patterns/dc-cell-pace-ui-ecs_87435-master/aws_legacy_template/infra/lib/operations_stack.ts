import * as cdk from 'aws-cdk-lib';
import {GetSSMValue} from '@bmo-cdk/common';
import {BMOCWAConstruct, BMOCWDConstruct} from '@bmo-cdk/cloudwatch';
import {globals as G} from './globals';
import { CustomResource } from 'aws-cdk-lib';

import { Construct } from 'constructs';

interface OperationsStackProps extends cdk.StackProps {
  // readonly apiId: String
  // readonly usagePlanId: String
}

export class OperationsStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props: OperationsStackProps) {
    super(scope, id, props);
     
    var Stage=this.node.tryGetContext('Stage');
    var accountID=this.node.tryGetContext('accountID');
    var stageShortCode=this.node.tryGetContext('stageShortCode');
    var regionShortCode=this.node.tryGetContext('regionShortCode');
    var Region=process.env.TargetAccountRegion;
    
    var ServiceName = G.serviceName;

    // ---------- OPERATIONAL ALARMS -------- // 
    // const Lambda_Error_Alarm = new BMOCWAConstruct(this, 'lambda_error_alarm', {
    //   comparisonOperator: 'GreaterThanOrEqualToThreshold',
    //   threshold: 1, // alarm threshold
    //   period: 300,
    //   evaluationPeriods: 1, // all the data points within each evaluation period must be greater than or equal to the threshold for the alarm to trigger
    //   datapointsToAlarm: 1, // the number of data points within the Evaluation Periods that must be breaching to cause the alarm to go to the ALARM state. The breaching data points don't have to be consecutive, they just must all be within the last number of data points equal to Evaluation Period
    //   alarmName: `${ServiceName}-${Stage}-myLambdaFunction-ErrorAlarm`,
    //   alarmDescription: `Lambda CloudWatch Alarm for ${ServiceName}-CDK-${Stage}-myLambdaFunction Errors`,
    //   metricName: "Errors", 
    //   metricNamespace: `AWS/Lambda`,
    //   dimensions: [{"name":"FunctionName","value":`SCCG-PAR-CDK-${Stage}-GetFinancialSnapshot`}],
    //   statistic: "Sum",
    //   alarmActions: [GetSSMValue(this,`/SCCG/SD/SCCG-OpernAlerts/${Stage}/DeliverAlert/SNS/ARN`)]
    // });

    // new BMOCWAConstruct(this, 'lambda_throttle_alarm', {
    //   comparisonOperator: 'GreaterThanOrEqualToThreshold',
    //   threshold: 1,
    //   period: 300,
    //   evaluationPeriods: 1, // all the data points within each evaluation period must be greater than or equal to the threshold for the alarm to trigger
    //   datapointsToAlarm: 1, // the number of data points within the Evaluation Periods that must be breaching to cause the alarm to go to the ALARM state. The breaching data points don't have to be consecutive, they just must all be within the last number of data points equal to Evaluation Period
    //   alarmName: `${ServiceName}-${Stage}-myLambdaFunction-ThrottlesAlarm`,
    //   alarmDescription: `Lambda CloudWatch Alarm for ${ServiceName}-CDK-${Stage}-GetFinancialSnapshot Throttles`,
    //   metricName: "Throttles", 
    //   metricNamespace: `AWS/Lambda`,
	  //   dimensions: [{"name":"FunctionName","value":`SCCG-PAR-CDK-${Stage}-GetFinancialSnapshot`}],
    //   statistic: "Sum",
    //   alarmActions: [GetSSMValue(this,`/SCCG/SD/SCCG-OpernAlerts/${Stage}/DeliverAlert/SNS/ARN`)]
    // });

    // Operational Dashboard
    new BMOCWDConstruct(this, 'cw-dashboard', { 
      dashboardName:`${ServiceName}-CDK-${Stage}-Dashboard`, 
      dashboardBody: `{
        "widgets": [
            {
                "type": "metric",
                "x": 0,
                "y": 0,
                "width": 6,
                "height": 6,
                "properties": {
                    "view": "timeSeries",
                    "stacked": false,
                    "metrics": [
                        [ "AWS/Lambda", "Duration", "FunctionName", "SCCG-PAR-CDK-${Stage}-GetFinancialSnapshot" ]
                    ],
                    "region": "${Region}",
                    "title": "SCCG-PartyArrangementReport Lambda Metric: Duration"
                }
            },
            {
                "type": "metric",
                "x": 6,
                "y": 0,
                "width": 6,
                "height": 6,
                "properties": {
                    "view": "timeSeries",
                    "stacked": false,
                    "metrics": [
                        [ "AWS/Lambda", "Errors", "FunctionName", "SCCG-PAR-CDK-${Stage}-GetFinancialSnapshot", "Resource", "SCCG-PAR-CDK-${Stage}-GetFinancialSnapshot" ]
                    ],
                    "region": "${Region}",
                    "title": "SCCG-PartyArrangementReport Lambda Metric: Errors"
                }
            },
            {
                "type": "metric",
                "x": 12,
                "y": 0,
                "width": 6,
                "height": 6,
                "properties": {
                    "view": "timeSeries",
                    "stacked": false,
                  "metrics": [
                        [ "AWS/Lambda", "Throttles", "FunctionName", "SCCG-PAR-CDK-${Stage}-GetFinancialSnapshot", "Resource", "SCCG-PAR-CDK-${Stage}-GetFinancialSnapshot" ]
                    ],
                    "region": "${Region}",
                    "title": "SCCG-PartyArrangementReport Lambda Metric: Throttles"
                }
            },
              {
                "type": "metric",
                "x": 18,
                "y": 0,
                "width": 6,
                "height": 6,
                "properties": {
                    "view": "timeSeries",
                    "stacked": false,
                    "metrics": [
                        [ "AWS/Lambda", "Invocations", "FunctionName", "SCCG-PAR-CDK-${Stage}-GetFinancialSnapshot", "Resource", "SCCG-PAR-CDK-${Stage}-GetFinancialSnapshot" ]
                    ],
                    "region": "${Region}",
                    "title": "SCCG-PartyArrangementReport Lambda Metric: Invocations"
                }
            },
              {
                "type": "metric",
                "x": 0,
                "y": 6,
                "width": 6,
                "height": 6,
                "properties": {
                    "view": "timeSeries",
                    "stacked": false,
                    "metrics": [
                        [ "AWS/Lambda", "ConcurrentExecutions", "FunctionName", "SCCG-PAR-CDK-${Stage}-GetFinancialSnapshot", "Resource", "SCCG-PAR-CDK-${Stage}-GetFinancialSnapshot" ]
                    ],
                    "region": "${Region}",
                    "title": "SCCG-PartyArrangementReport Lambda Metric: ConcurrentExecutions"
                }
            },
            {
              "type": "metric",
              "x": 12,
              "y": 6,
              "width": 6,
              "height": 6,
              "properties": {
                "view": "timeSeries",
                "stacked": true,
                "metrics": [
                  [ "AWS/ApiGateway", "4XXError", "ApiName", "SCCG-PartyArrangementReport-CDK-API" ],
                  [ ".", "5XXError", ".", "." ]
                ],
                "region": "${Region}",
                "title": "SCCG-PartyArrangementReport API Errors"
              }
            }
        ]
    }`,
      //tags: G.taggingVars,
    });

    // var isAccountStage;
    // if (Stage == "sandbox" || Stage == "dev" || Stage == "prod") {
    //     isAccountStage = true;
    // } else {
    //     isAccountStage = false;
    // }

    // var apiId;
    
    // if (isAccountStage){
    //   apiId = props.apiId;
    // } else {
    //   apiId = GetSSMValue(this, `/SCCG/${ServiceName}/CDK/APIGateway/Id`)
    // };

    // console.log(`operations stack, props.usageplan: ${props.usagePlanId}`)
    // new CustomResource(this, 'attache-usage-plan', {
    //   //"arn:aws:lambda:us-east-1:520049198415:function:SCCG-CustomResource-ApiStageCustomResource-sandbox-Lambda",
    //   serviceToken: GetSSMValue(this, `/SCCG/CustomResource/ApiStageCustomResource/${Stage}/us-east-1/LambdaArn`), 
    //   properties: {
    //     ForceUpdateValue: GetSSMValue(this,"/tie/hc/CustomResourceForceUpdate/Value"),
    //     ApiId: apiId,
    //     UsagePlanId: props.usagePlanId,
    //     Stage: Stage
    //   }
    // })
  }
}
