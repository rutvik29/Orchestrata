import * as cdk from 'aws-cdk-lib';
import { GetSSMValue } from '@bmo-cdk/common';
import { CustomResource } from 'aws-cdk-lib';
import { BMOUSAGEPLANKEYConstruct, BMOAPIKEYConstruct } from '@bmo-cdk/apigateway';

import {globals as G} from './globals';

import { Construct } from 'constructs';

interface OperationsStackProps extends cdk.StackProps {
    readonly apiId: String
    //readonly usagePlanId: String; 
}

export class UsagePlanStack extends cdk.Stack {
    constructor(scope: Construct, id: string, props: OperationsStackProps) {
        super(scope, id, props);

        var Stage=this.node.tryGetContext('Stage');
        var accountID=this.node.tryGetContext('accountID');
        var stageShortCode=this.node.tryGetContext('stageShortCode');
        var regionShortCode=this.node.tryGetContext('regionShortCode');
        var Region=process.env.TargetAccountRegion;

        var ServiceName = G.serviceName;

        var isAccountStage;
        if (Stage == "sandbox" || Stage == "dev" || Stage == "prod") {
            isAccountStage = true;
        } else {
            isAccountStage = false;
        }

        var apiId;
        
        if (isAccountStage){
            apiId = props.apiId;
        } else {
            apiId = GetSSMValue(this, `/SCCG/${ServiceName}/CDK/APIGateway/Id`)
        };

        let TPS=500;
        //Please find the available TPS value in the following repo: 
        //https://bitbucket.bmogc.net/projects/CLOUDINTAP/repos/bmo-cdk-usage-plan-shared-list/browse

        // new CustomResource(this, 'attach-usage-plan', {
        //     //"arn:aws:lambda:us-east-1:520049198415:function:SCCG-CustomResource-ApiStageCustomResource-sandbox-Lambda",
        //     serviceToken: `${GetSSMValue(this, `/SCCG/CustomResource/ApiStageCustomResource/${Stage}/${Region}/LambdaArn`)}`, 
        //     properties: {
        //       ForceUpdateValue: GetSSMValue(this,"/tie/hc/CustomResourceForceUpdate/Value"),
        //       ApiId: apiId,
        //       UsagePlanId: GetSSMValue(this,`/SCCG/SharedUsage/${Stage}/CDK/Shared-Usage-Plan-${TPS}TPS/Id`),
        //       Stage: Stage
        //     }
        // })

        /**
         * PLEASE NOTE:
         *   the following APIKey creation is not allowed in DEV and PROD
         *   this is only for sandbox only. This is so that the keys can be rotated manually
         */
        // const apikey = new BMOAPIKEYConstruct(this, 'apikey', {
        //     name:`tie-hc-${process.env.TargetAccountStage}-SCCG-CDK-${G.custom_service_prefix}services`,
        //     description: `usage plan apikey`,
        //     enabled: true,
        //     tags: G.taggingVars
        // })
        
        // new BMOUSAGEPLANKEYConstruct(this, 'usage-plan-key', {
        //     keyId: apikey.key.attrApiKeyId,
        //     keyType: 'API_KEY',
        //     usagePlanId: GetSSMValue(this,`/SCCG/SharedUsage/${Stage}/CDK/Shared-Usage-Plan-${TPS}TPS/Id`)
        // })
    }
}