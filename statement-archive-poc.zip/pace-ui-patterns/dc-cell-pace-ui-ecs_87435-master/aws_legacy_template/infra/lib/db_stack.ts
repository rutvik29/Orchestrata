import * as cdk from 'aws-cdk-lib';
import {globals as G} from './globals';
import { BMODDBConstruct } from '@bmo-cdk/dynamodb';

import { Construct } from 'constructs';

export class DBStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    // ---------- STACK PARAMETERS -------- //    
    
    var Stage=this.node.tryGetContext('Stage');
    var accountID=this.node.tryGetContext('accountID');
    var stageShortCode=this.node.tryGetContext('stageShortCode');
    var regionShortCode=this.node.tryGetContext('regionShortCode');
    var Region=process.env.TargetAccountRegion;
    var ServiceName = G.serviceName;

    // ---------- DYNAMODB -------- // 

    new BMODDBConstruct(this, 'MyDDBtable', {
      tableName: `${ServiceName}-${Stage}-DynamoDB`,
      billingMode: 'PAY_PER_REQUEST', //'PROVISIONED' or 'PAY_PER_REQUEST'
      keySchema: [
        {
          attributeName : "Album",
          keyType : "HASH"
        },
        {
          attributeName : "Artist",
          keyType : "RANGE"
        }
      ],
      attributeDefinitions:[
        {
          attributeName : "Album",
          attributeType : "S"
        },
        {
          attributeName : "Artist",
          attributeType : "S"
        }
      ],
      kmsMasterKeyId: 'alias/aws/dynamodb',
      tags: G.taggingVars,
      exceptionCode: ["E060"],
      // globalSecondaryIndexes: [],
      // kinesisStreamArn: '',
      // localSecondaryIndexes: [],
      pointInTimeRecoverySpecificationEnabled: true,
      // streamSpecification: {},
      // timeToLiveSpecification: {}
    } as any);

  }
}
