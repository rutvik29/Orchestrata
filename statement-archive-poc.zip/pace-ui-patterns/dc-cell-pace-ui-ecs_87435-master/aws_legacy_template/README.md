# aws-template-repo serverless

Refer [Quickstart guide for Serveless API Deployment](https://bmo.atlassian.net/wiki/spaces/AUTOMATE/pages/487006549/My+first+stack+quickstart) for step-by-step instructions
