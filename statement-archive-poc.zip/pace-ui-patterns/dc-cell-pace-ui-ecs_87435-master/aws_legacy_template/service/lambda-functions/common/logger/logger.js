const util = require("./utilities.js");
var loggingLevel = process.env.LOGGING_LEVEL || "DEBUG";
// BASIC LOG /////////////////////////////////////////////////////////////////

const createELKLog = function(message, customLogLevel, options, corrId) {
	let timestamp = new Date().toISOString();

	if (global.executionContext["sanitizeArray"] && util.isJson(message)) {
		var json = typeof message == "string" ? JSON.parse(message) : JSON.parse(JSON.stringify(message));
		message = JSON.stringify(
			util.sanitizeData(json, global.executionContext["sanitizeArray"])
		);
	}
	if (options && options.description) {
		message = options.description + ":::" + message;
	}
	let simpleLogMessage = {
		_index: "awslogstash-" + util.getTimestamp(),
		_type: "doc",
		_id: util.uuid(),
		_version: 1,
		_source: {
			offset: Date.now() - global.executionContext.epochMillis,
			appRuntime: `${global.executionContext.serviceName}_AWS`,
			functionName: global.executionContext.functionName,
			corrId: corrId || global.executionContext.correlationId,
			logger: global.executionContext.functionName,
			input_type: "log",
			source: "/aws/lambda/" + global.executionContext.functionName,
			epochMillis: global.executionContext.epochMillis,
			type: "aws:lambda",
			serviceName: global.executionContext.serviceName,
			tags: [],
			jobID: global.executionContext.amzTraceId,
			jobID2: options && options.jobID ? options.jobID : undefined,
			durationComponent:
				options && options.duration ? options.duration : undefined,
			calledComponent: options && options.backend ? options.backend : undefined,
			logstash: {
				hostName: "",
				location: "hub"
			},
			"@timestamp": timestamp,
			logLevel: customLogLevel ? customLogLevel : loggingLevel,
			"@version": "1",
			beat: {
				hostname: "",
				name: "",
				version: ""
			},
			host: "",
			inputType: "cloudwatch",
			detail: message,
			esTimestamp: timestamp,
			fields: {
				appCatCode: "6184",
				cioName: "smartCore",
				docType: "aws",
				environmentType: global.executionContext.stage
			}
		},
		fields: {
			"@timestamp": [timestamp],
			esTimestamp: [timestamp]
		},
		highlight: {
			serviceName: [
				"@kibana-highlighted-field@" +
					global.executionContext.serviceName +
					"@/kibana-highlighted-field@"
			]
		},
		sort: [global.executionContext.epochMillis]
	};

	return simpleLogMessage;
};

// OUTSIDE LOGGING STRUCTURE /////////////////////////////////////////////////////////////////
const writeLog = function(logMessage) {
	console.log(JSON.stringify(logMessage));
};

// EXPORTS  /////////////////////////////////////////////////////////////////

module.exports = {
	logOutboundEvent: async event => {
		var outboundEventJson;
		if (loggingLevel == "INFO" && global.executionContext["overrideInfoEventLogs"] === true){
			outboundEventJson = createELKLog(JSON.stringify(event), "INFO", {
				description: "Logging Outbound Event"
			});

			if (outboundEventJson) writeLog(outboundEventJson);
		}
		else if (loggingLevel == "DEBUG") {
			outboundEventJson = createELKLog(JSON.stringify(event), "DEBUG", {
				description: "Logging Outbound Event"
			});

			if (outboundEventJson) writeLog(outboundEventJson);
		}
	},
	logInboundEvent: async event => {
		var inboundEventJson;
		if (loggingLevel == "INFO" && global.executionContext["overrideInfoEventLogs"] === true) {
			inboundEventJson = createELKLog(JSON.stringify(event), "INFO", {
				description: "Logging Inbound Event",
			});

			if (inboundEventJson) writeLog(inboundEventJson);
		}
		else if (loggingLevel == "DEBUG") {
			inboundEventJson = createELKLog(JSON.stringify(event), "DEBUG", {
				description: "Logging Inbound Event",
			});

			if (inboundEventJson) writeLog(inboundEventJson);
		}
	},
	logBackendServiceRequest: async (backend, request, corrId, xml) => {
		
		if(xml){
		    request = util.sanitizeXml(request, global.executionContext["sanitizeArray"]);
		}
		if (loggingLevel == "INFO" || loggingLevel == "DEBUG") {
			var backendServiceRequestInfoLog;
			backendServiceRequestInfoLog = createELKLog(
				`${backend} is being called`,
				"INFO",
				{ backend },
				corrId
			);
			if (backendServiceRequestInfoLog) writeLog(backendServiceRequestInfoLog);
		}
		
		if (loggingLevel == "INFO" && global.executionContext["overrideInfoBackendLogs"] === true) {
			var backendServiceRequestInfoOverrideLog;
			backendServiceRequestInfoOverrideLog = createELKLog(
				request,
				"INFO",
				{ backend, description: `${backend} Request`, xml },
				corrId
			);
			if (backendServiceRequestInfoOverrideLog)
				writeLog(backendServiceRequestInfoOverrideLog);
		}
		else if (loggingLevel == "DEBUG") {
			var backendServiceRequestDebugLog;
			backendServiceRequestDebugLog = createELKLog(
				request,
				"DEBUG",
				{ backend, description: `${backend} Request`, xml },
				corrId
			);
			if (backendServiceRequestDebugLog)
				writeLog(backendServiceRequestDebugLog);
		}
	},
	logBackendServiceResponse: async (
		backend,
		startTime,
		response,
		jobID,
		corrId,
		xml
	) => {
		let endTime = Date.now();
		let duration = endTime - startTime;

		if(xml){
		    response = util.sanitizeXml(response, global.executionContext["sanitizeArray"]);
		}
		
		if (loggingLevel == "INFO" || loggingLevel == "DEBUG") {
			var backendServiceResponseInfoLog;
			backendServiceResponseInfoLog = createELKLog(
				`${backend} responsed successfully in ${duration} ms`,
				"INFO",
				{ backend, duration, jobID },
				corrId
			);
			if (backendServiceResponseInfoLog)
				writeLog(backendServiceResponseInfoLog);
		}
		if (loggingLevel == "INFO" && global.executionContext["overrideInfoBackendLogs"] === true) {
			var backendServiceResponseInfoOverrideLog;
			backendServiceResponseInfoOverrideLog = createELKLog(
				response,
				"INFO",
				{ backend, jobID, description: `${backend} Response`, xml },
				corrId
			);
			if (backendServiceResponseInfoOverrideLog)
				writeLog(backendServiceResponseInfoOverrideLog);
		}
		else if (loggingLevel == "DEBUG") {
			var backendServiceResponseDebugLog;
			backendServiceResponseDebugLog = createELKLog(
				response,
				"DEBUG",
				{ backend, jobID, description: `${backend} Response`, xml },
				corrId
			);
			if (backendServiceResponseDebugLog)
				writeLog(backendServiceResponseDebugLog);
		}
	},

	logBackendServiceTimeout: async (
		backend,
		startTime,
		response,
		jobID,
		corrId,
		xml
	) => {
		let endTime = Date.now();
		let duration = endTime - startTime;

		if(xml){
		    response = util.sanitizeXml(response, global.executionContext["sanitizeArray"]);
		}
		if (loggingLevel == "INFO" || loggingLevel == "DEBUG") {
			var backendServiceTimeoutInfoLog;
			backendServiceTimeoutInfoLog = createELKLog(
				`${backend} timed out in ${duration} ms`,
				"INFO",
				{ backend, duration, jobID },
				corrId
			);
			if (backendServiceTimeoutInfoLog) writeLog(backendServiceTimeoutInfoLog);
		}
		if (loggingLevel == "DEBUG" || loggingLevel == "INFO") {
			var backendServiceTimeoutDebugLog;
			backendServiceTimeoutDebugLog = createELKLog(
				response,
				"ERROR",
				{ backend, jobID, description: `${backend} Timeout Error`, xml },
				corrId
			);
			if (backendServiceTimeoutDebugLog)
				writeLog(backendServiceTimeoutDebugLog);
		}
	},

	logBackendServiceError: async (backend, startTime, error, jobID, corrId, xml) => {
		let endTime = Date.now();
		let duration = endTime - startTime;
		
		if(xml){
		    error = util.sanitizeXml(error, global.executionContext["sanitizeArray"]);
		}

		if (loggingLevel == "INFO" || loggingLevel == "DEBUG") {
			var backendServiceErrorInfoLog;
			backendServiceErrorInfoLog = createELKLog(
				`${backend} failed in ${duration} ms`,
				"INFO",
				{ backend, duration, jobID },
				corrId
			);
			if (backendServiceErrorInfoLog) writeLog(backendServiceErrorInfoLog);
		}
		if (loggingLevel == "DEBUG" || loggingLevel == "INFO") {
			var backendServiceErrorDebugLog;
			backendServiceErrorDebugLog = createELKLog(
				error,
				"ERROR",
				{ backend, jobID, description: `${backend} Error Response`, xml },
				corrId
			);
			if (backendServiceErrorDebugLog) writeLog(backendServiceErrorDebugLog);
		}
	},

	logInitializationMessage: async () => {
		writeLog(createELKLog("STARTED", "INFO"));
	},
	logFinalizeMessage: async () => writeLog(createELKLog("COMPLETED", "INFO")),

	trace: (message, corrId) => {
		if (loggingLevel === "TRACE")
			writeLog(createELKLog(message, "TRACE", null, corrId));
	},
	debug: async (message, corrId, xml) => {
		if (loggingLevel === "DEBUG" || loggingLevel === "TRACE") {
			if(xml){
			    message = util.sanitizeXml(message, global.executionContext["sanitizeArray"]);
			}
			writeLog(createELKLog(message, "DEBUG", { xml }, corrId));
		}
	},
	debugWithSanitize: async (message, description, corrId, xml) => {
		if (loggingLevel === "DEBUG" || loggingLevel === "TRACE") {
			var debugWithSanitize;
			if(xml){
			    message = util.sanitizeXml(message, global.executionContext["sanitizeArray"]);
			}
			debugWithSanitize = createELKLog(
				message,
				"DEBUG",
				{ description },
				corrId
			);
			if (debugWithSanitize) writeLog(debugWithSanitize);
		}
	},
	info: async (message, corrId, xml) => {
		if(xml){
		    message = util.sanitizeXml(message, global.executionContext["sanitizeArray"]);
		}
		writeLog(createELKLog(message, "INFO", corrId));
	},
	
	infoWithSanitize: async (message, description, corrId, xml) => {
		if(xml){
		    message = util.sanitizeXml(message, global.executionContext["sanitizeArray"]);
		}		
		writeLog(createELKLog(message, "INFO", { description, xml }, corrId));

	},
	error: async (message, stacktrace, corrId, xml) => {
		if (loggingLevel == "INFO") {
			if(xml){
			    message = util.sanitizeXml(message, global.executionContext["sanitizeArray"]);
			}
			writeLog(createELKLog("[ERROR] Message: " + message, "ERROR", { xml }, corrId));
		}
			
		else if (loggingLevel == "DEBUG" || global.executionContext["overrideErrorInfoLogs"] === true) {
			if(xml){
			    message = util.sanitizeXml(message, global.executionContext["sanitizeArray"]);
			}
			writeLog(createELKLog("[ERROR] Stacktrace: " + stacktrace, "ERROR", { xml }, corrId));
		}
	}
};