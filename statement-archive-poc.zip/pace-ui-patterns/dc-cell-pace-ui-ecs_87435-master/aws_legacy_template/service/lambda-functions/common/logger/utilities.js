const timezone = require("moment-timezone");
const { cloneDeepWith, isObject, toLower, some } = require("lodash");
const request = require("request");
const framework = require("./framework");
let warm = false;

let containerId = null;

module.exports = {
	// LAMBDA UTILITIES

	warmer: function(event) {
		const functionName = process.env.FUNCTION_NAME;
		const delay = ms => new Promise(res => setTimeout(res, ms));

		if (event["warmer"]) {
			let concurrency =
				event["concurrency"] &&
				!isNaN(event["concurrency"]) &&
				event["concurrency"] > 1
					? event["concurrency"]
					: 1;

			let invokeCount =
				event["__WARMER_INVOCATION__"] && !isNaN(event["__WARMER_INVOCATION__"])
					? event["__WARMER_INVOCATION__"]
					: 1;

			let invokeTotal =
				event["__WARMER_CONCURRENCY__"] &&
				!isNaN(event["__WARMER_CONCURRENCY__"])
					? event["__WARMER_CONCURRENCY__"]
					: concurrency;

			containerId = containerId ? containerId : this.uuid();

			console.log({
				action: "warmer",
				function: functionName,
				count: invokeCount,
				concurrency: invokeTotal,
				warm,
				pingedAt: this.getTimestamp(),
				containerId: containerId
			});

			// flag as warm
			warm = true;

			// Fan out if concurrency is set higher than 1
			if (concurrency > 1) {
				// init Lambda service
				let lambda = require("./lib/lambda-service");

				// init promise array
				let invocations = [];

				// loop through concurrency count
				for (let i = 2; i <= concurrency; i++) {
					// Set the params and wait for the final function to finish
					let params = {
						FunctionName: functionName,
						InvocationType: i === concurrency ? "RequestResponse" : "Event",
						LogType: "None",
						Payload: new Buffer(
							JSON.stringify({
								warmer: true, // send warmer flag
								__WARMER_INVOCATION__: i, // send invocation number
								__WARMER_CONCURRENCY__: concurrency // send total concurrency
							})
						)
					};

					// Add promise to invocations array
					invocations.push(lambda.invoke(params).promise());
				} // end for

				// Invoke concurrent functions
				return Promise.all(invocations).then(res => true);
			} else if (invokeCount > 1) {
				return delay(75).then(() => true);
			}

			return Promise.resolve(true);
		} else {
			warm = true;
			return Promise.resolve(false);
		}
	},

	// DATE / TIME FUNCTIONS

	getTimestamp: function() {
		var moment = timezone(Date.now());
		moment =
			moment.tz("America/Toronto").format("DD-MMM-YY hh:mm:ss z") +
			" America/Toronto";
		return moment;
	},

	getTimestampBMO: function() {
		var moment = timezone(Date.now());
		moment = moment.tz("America/Toronto").format("DD-MMM-YY hh:mm:ss z");
		return moment;
	},

	getDate: function() {
		var moment = timezone(Date.now());
		moment = moment.tz("America/Toronto").format("YYYYMMDD");
		return moment;
	},
	// API HEADER FUNCTIONS

	getAPIHeaderRequest: async function(callPath, API, APIFunction) {
		var moment = timezone(Date.now());
		moment = moment.tz("America/Toronto").format();
		var requestId = global.executionContext.correlationId;
		return {
			headerVersion: "1.0",
			digitalSignature: "",
			correlation: {
				requestId: requestId,
				myId: requestId,
				myTimeStamp: moment,
				callPath: callPath
			},
			what: {
				keyValues: " ",
				API: API,
				APIFunction: APIFunction
			},
			additionalInfo: []
		};
	},

	setAPIHeaderResponse: async function(callPath) {
		var moment = timezone(Date.now());
		moment = moment.tz("America/Toronto").format();
		var requestId = global.executionContext.correlationId;
		return {
			correlation: {
				requestId: requestId,
				myId: requestId,
				myTimeStamp: moment,
				callPath: callPath,
				keyValues: " "
			},
			responseStatus: "SUCCESS",
			additionalInfo: null
		};
	},
	// OTHER FUNCTIONS
	
	sanitizeXml : function(collection, blacklist, replacement) {
		var result = maskXml(blacklist, {})(collection);
		return result;
		
		function maskXml(collection, {
			  ignoreCase = false,
			  replacement = '********'
			} = {}) {
			  return value => {
			    if (typeof value !== 'string') {
			      return value;
			    }
			
			    for (const element of collection) {
                  const search = new RegExp(`(<${element}>).*(?=.{4}(<\/${element}>))`, `g${ignoreCase ? 'i' : ''}`);
                  value = value.replace(search, `$1${replacement}`);  
			    }
			
			    return value;
			  };
		}
	},


	sanitizeData: function(collection, blacklist, replacement) {
		var result = maskJson(blacklist, { replacement: replacement })(collection);
		return result;

		function maskJson(
			collection,
			{ ignoreCase = false, replacement = "*" } = {}
		) {
			return function(values) {
				return cloneDeepWith(values, (value, key) => {
					// Strip matching keys.
					if (
						some(
							collection,
							item =>
								ignoreCase ? toLower(key) === toLower(item) : key === item
						)
					) {
						if (value) {
							let object_type = Object.prototype.toString.call(value);

							if (object_type == "[object Array]") {
								return value;
							} else {
								return mask(value, object_type, replacement);
							}
						} else {
							return value;
						}
					}

					// Allow cloneDeep to recurse into nested objects.
					if (isObject(value)) {
						return;
					}

					// Otherwise return the value.
					return value;
				});
			};
		}
	},

	uuid: function uuid() {
		return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(c) {
			var r = (Math.random() * 16) | 0,
				v = c == "x" ? r : (r & 0x3) | 0x8;
			return v.toString(16);
		});
	},

	isJson: function(item) {
		item = typeof item !== "string" ? JSON.stringify(item) : item;

		try {
			item = JSON.parse(item);
		} catch (e) {
			return false;
		}

		if (typeof item === "object" && item !== null) {
			return true;
		}

		return false;
	}
};

function isJson(item) {
	item = typeof item !== "string" ? JSON.stringify(item) : item;

	try {
		item = JSON.parse(item);
	} catch (e) {
		return false;
	}

	if (typeof item === "object" && item !== null) {
		return true;
	}

	return false;
}

function mask(value, object_type, replacement) {
	if (object_type == "[object String]") {
		if (value.length > 4)
			return (
				replacement.repeat(value.length - 4) + value.substr(value.length - 4)
			);
		else if (value.length > 1 && value.length <= 4)
			return (
				replacement.repeat(value.length - 1) + value.substr(value.length - 1)
			);
		else return value;
	} else if (object_type == "[object Number]") {
		let length = value.toString().length;
		if (length > 4)
			return (
				replacement.repeat(length - 4) + value.toString().substr(length - 4)
			);
		else if (length > 1 && length <= 4)
			return (
				replacement.repeat(value.length - 1) +
				value.toString().substr(value.length - 1)
			);
		else return value;
	} else if (object_type == "[object Boolean]") {
		return value;
	} else {
		if (value.length > 4)
			return (
				replacement.repeat(value.length - 4) + value.substr(value.length - 4)
			);
		else if (value.length > 1 && value.length <= 4)
			return (
				replacement.repeat(value.length - 1) + value.substr(value.length - 1)
			);
		else return value;
	}
}
