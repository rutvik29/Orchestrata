const logger = require("./logger.js");
const common = require("./commonObjects.js");
const utilities = require("./utilities.js");
const loggingLevel =
	process.env.LOGGING_LEVEL != undefined ? process.env.LOGGING_LEVEL : "INFO";
const stage = process.env.STAGE != undefined ? process.env.STAGE : "undefined";
const serviceName =
	process.env.SERVICE_NAME != undefined
		? process.env.SERVICE_NAME
		: "undefined";
const default_sanitize = ["x-api-key", "cert", "key", "ca"];

module.exports = {
	// GLOBAL CONTEXT / GLOBAL FUNCTIONS

	setGlobalExecutionContext: function(event, context, options) {
		if (options.sanitizeArray) {
			global.executionContext["sanitizeArray"] = default_sanitize.concat(
				options.sanitizeArray
			);
		} 
		else {
			global.executionContext["sanitizeArray"] = default_sanitize;
		}
		
		if (options.xml) {
			global.executionContext["xml"] = true;
		}
		
		if (options.overrideInfoEventLogs) {
			global.executionContext["overrideInfoEventLogs"] = true;
		}
		
		if (options.overrideInfoBackendLogs) {
			global.executionContext["overrideInfoBackendLogs"] = true;
		}
		
		if (options.overrideInfoBackendLogs) {
			global.executionContext["overrideErrorInfoLogs"] = true;
		}
		
		let eventDetails = common.getDetailsFromEvent(event, context);
		if (eventDetails == null) {
			logger.debug("Unable to get details from Event: " + event);
		} else {
			global.executionContext["correlationId"] = eventDetails.correlationId;
			global.executionContext["amzTraceId"] = eventDetails.amzTraceId;
			global.executionContext["eventSource"] = eventDetails.eventSource;
			global.executionContext["incomingEvent"] = event;
			global.executionContext["context"] = context;
			global.executionContext["functionName"] = eventDetails.functionName;
			global.executionContext["proxy"] = eventDetails.proxy;
			global.executionContext["epochMillis"] = Date.now();
			global.executionContext["stage"] = stage;
			global.executionContext["serviceName"] = serviceName;
		}
		if (options.customCorrId){
			global.executionContext["correlationId"] = options.customCorrId;
		}
	},

	extractPayload: function(event) {
		if (global.executionContext.eventSource === "API") {
			if (global.executionContext.proxy === true && global.executionContext["xml"] === true) 
				return event.body;
			else if (global.executionContext.proxy === true)	
				return JSON.parse(event.body);
			else {
				return event;
			}
		} else if (global.executionContext.eventSource === "STACK") {
			return event;
		} else if (global.executionContext.eventSource === "S3") {
			return event; // to do: need to clarify how much to pass to user for s3 event
		} else if (global.executionContext.eventSource === "SNS") {
			return event;
		} else if (global.executionContext.eventSource === "SQS") {
			return event;
		} else if (global.executionContext.eventSource === "AUTHORIZER") {
			return event;
		} else if (global.executionContext.eventSource === "KINESIS") {
			return event;
		} else if (global.executionContext.eventSource === "CUSTOM") {
			return event.message;
		} else if (global.executionContext.eventSource === "CLOUDWATCH_CRON") {
			return event;
		} else if (global.executionContext.eventSource === "CODEPIPELINE") {
			return event;
		} else if (global.executionContext.eventSource === "CFN_MACRO") {
			return event;
		} else if (global.executionContext.eventSource === "LAMBDA") {
			return event;
		} else if (global.executionContext.eventSource === "STEPFUNCTION") {
			return event;
		} else {
			return new Error("Unsupported.Event.Type");
		}
	},

	// INITIALIZE & FINALIZE

	initialize: async function() {
		logger.logInitializationMessage();

		if (global.executionContext.eventSource === "API") {
			if (global.executionContext["sanitizeArray"]) {
				let body;
				if (global.executionContext["xml"]) {
					body = utilities.sanitizeXml(global.executionContext.incomingEvent.body, global.executionContext["sanitizeArray"]);
				}
				else {
					body = JSON.parse(global.executionContext.incomingEvent.body);
				}
				let parsedAPIEvent = {
					path: global.executionContext.incomingEvent.path,
					method: global.executionContext.incomingEvent.httpMethod,
					headers: global.executionContext.incomingEvent.headers,
					body: body
				};
				logger.logInboundEvent(parsedAPIEvent);
			} else {
				logger.logInboundEvent(global.executionContext.incomingEvent);
			}
		} else if (global.executionContext.eventSource === "CFN_MACRO") {
			if (loggingLevel === "DEBUG") {
				logger.logInboundEvent(global.executionContext.incomingEvent);
				logger.debug(
					"Logging STACK Event Details:::" +
						JSON.stringify(global.executionContext.incomingEvent)
				);
			}
		} else if (global.executionContext.eventSource === "STEPFUNCTION") {
			if (loggingLevel === "DEBUG") {
				logger.logInboundEvent(global.executionContext.incomingEvent);
			}
		} else if (global.executionContext.eventSource === "CLOUDWATCH_CRON") {
			if (loggingLevel === "DEBUG") {
				logger.logInboundEvent(global.executionContext.incomingEvent);
				logger.debug(
					"Logging STACK Event Details:::" +
						JSON.stringify(global.executionContext.incomingEvent)
				);
			}
		} else if (global.executionContext.eventSource === "CODEPIPELINE") {
			if (loggingLevel === "DEBUG") {
				logger.logInboundEvent(global.executionContext.incomingEvent);
				logger.debug(
					"Logging STACK Event Details:::" +
						JSON.stringify(global.executionContext.incomingEvent)
				);
			}
		} else if (global.executionContext.eventSource === "AUTHORIZER") {
			let AuthorizerEventDetails = common.AutorizerEventDetails();

			if (loggingLevel === "DEBUG") {
				logger.logInboundEvent(global.executionContext.incomingEvent);
				logger.debug(
					"Logging Authorizer Event Details:::" +
						JSON.stringify(AuthorizerEventDetails)
				);
			}
		} else if (global.executionContext.eventSource === "STACK") {
			if (loggingLevel === "DEBUG") {
				logger.logInboundEvent(global.executionContext.incomingEvent);
				logger.debug(
					"Logging STACK Event Details:::" +
						JSON.stringify(global.executionContext.incomingEvent)
				);
			}
		} else if (global.executionContext.eventSource === "CUSTOM") {
			if (loggingLevel === "DEBUG") {
				logger.logInboundEvent(global.executionContext.incomingEvent);
				logger.debug(
					"Logging Custom Event Details:::" +
						JSON.stringify(global.executionContext.incomingEvent)
				);
			}
		} else if (global.executionContext.eventSource === "KINESIS") {
			var kinesisEventDetails = common.kinesisEventDetails;
			if (loggingLevel === "DEBUG") {
				logger.logInboundEvent(global.executionContext.incomingEvent);
				logger.debug(
					"Logging Kinesis Event Details:::" +
						JSON.stringify(kinesisEventDetails)
				);
			}
		} else if (global.executionContext.eventSource === "S3") {
			var s3EventDetails = common.s3EventDetails();
			if (loggingLevel === "DEBUG") {
				logger.logInboundEvent(global.executionContext.incomingEvent);
				logger.debug(
					"Logging S3 Event Details:::" + JSON.stringify(s3EventDetails)
				);
			}
		} else if (global.executionContext.eventSource === "SNS") {
			var snsEventDetails = common.snsEventDetails();
			if (loggingLevel === "DEBUG") {
				logger.logInboundEvent(global.executionContext.incomingEvent);
				logger.debug(
					"Logging SNS Event Details:::" + JSON.stringify(snsEventDetails)
				);
			}
		} else if (global.executionContext.eventSource === "SQS") {
			var sqsEventDetails = common.sqsEventDetails();
			if (loggingLevel === "DEBUG") {
				logger.logInboundEvent(global.executionContext.incomingEvent);
				logger.debug(
					"Logging SQS Event Details:::" + JSON.stringify(sqsEventDetails)
				);
			}
		}
	},
    finalize: async function(response, body, override) {
        if (global.executionContext["sanitizeArray"]) {
            let sanitizedBody;
            if(global.executionContext["xml"]){
                sanitizedBody = await utilities.sanitizeXml(
                    body,
                    global.executionContext["sanitizeArray"]
                );
            }
            else {
                //modified log
                let outboundResponse = {
                    statusCode: response.statusCode,
                    headers: response.headers,
                    body: typeof response.body == 'string' ? JSON.parse(response.body) : response.body,
                    isBase64Encoded: response.isBase64Encoded
                };
                sanitizedBody = await utilities.sanitizeData(
                    outboundResponse,
                    global.executionContext["sanitizeArray"]
                );
            }
            logger.logOutboundEvent(sanitizedBody);
        } else logger.logOutboundEvent(response);

        logger.logFinalizeMessage();
	}
};
