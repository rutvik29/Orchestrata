const logger = require("./logger.js");
const wrapper = require("./wrapper");
const utils = require("./utilities.js");

module.exports = {
	// EXECUTION FUNCTIONS

	execute: function(event, context, callback, functionToInvoke, options) {
		try {
			var startTime = Date.now();
			wrapper.execute(event, context, callback, functionToInvoke, options);
		} catch (err) {
			logger.error("unhandledError", err.stack);
			wrapper.processFailure("unhandledError", err, callback, startTime);
		}
	},

	// UTILITIES

	warmer: async function(event, callback) {
		await utils.warmer(event);
		callback(null, "warmed");
	},

	getUUID: function() {
		return utils.uuid();
	},

	getCorrelationId: function() {
		return global.executionContext.correlationId;
	},

	getDate: function() {
		return utils.getDate();
	},

	getDateTime: function() {
		return utils.getDateTime();
	},

	getTimestamp: function() {
		return utils.getTimestampBMO();
	},

	getAPIHeaderRequest: function(callPath, API, APIFunction) {
		return utils.getAPIHeaderRequest(callPath, API, APIFunction);
	},

	// S3 Functions:
	s3: {
		getObject: async function(s3_initial, s3_retries, params) {
			return new Promise(async function(resolve, reject) {
				await s3_initial
					.getObject(params)
					.promise()
					.then(async function(res) {
						resolve(res);
					})
					.catch(async function(err) {
						if (err.code == "TimeoutError") {
							s3_retries
								.getObject(params)
								.promise()
								.then(async function(res) {
									resolve(res);
								})
								.catch(async function(err) {
									reject(err);
								});
						} else reject(err);
					});
			});
		},
		putObject: function(s3_initial, s3_retries, params) {
			return new Promise(async function(resolve, reject) {
				await s3_initial
					.putObject(params)
					.promise()
					.then(async function(res) {
						resolve(res);
					})
					.catch(async function(err) {
						if (err.code == "TimeoutError") {
							s3_retries
								.putObject(params)
								.promise()
								.then(async function(res) {
									resolve(res);
								})
								.catch(async function(err) {
									reject(err);
								});
						} else reject(err);
					});
			});
		},
		listObjects: function(s3_initial, s3_retries, params) {
			return new Promise(async function(resolve, reject) {
				await s3_initial
					.listObjectsV2(params)
					.promise()
					.then(async function(data) {
						resolve(data);
					})
					.catch(async function(err) {
						if (err.code == "TimeoutError") {
							s3_retries
								.listObjectsV2(params)
								.promise()
								.then(async function(res) {
									resolve(res);
								})
								.catch(async function(err) {
									reject(err);
								});
						} else reject(err);
					});
			});
		},
		deleteObject: function(s3_initial, s3_retries, params) {
			return new Promise(async function(resolve, reject) {
				await s3_initial
					.deleteObject(params)
					.promise()
					.then(async function(res) {
						resolve(res);
					})
					.catch(async function(err) {
						if (err.code == "TimeoutError") {
							s3_retries
								.deleteObject(params)
								.promise()
								.then(async function(res) {
									resolve(res);
								})
								.catch(async function(err) {
									reject(err);
								});
						} else reject(err);
					});
			});
		}
	},

	// LOGGING FUNCTIONS

	debug: function(message, corrId, xml) {
		logger.debug(message, corrId, xml);
	},

	debugWithSanitize: function(message, description, corrId, xml) {
		logger.debugWithSanitize(message, description, corrId, xml);
	},

	info: function(message, corrId, xml) {
		logger.info(message, corrId, xml);
	},

	infoWithSanitize: function(message, description, corrId, xml) {
		logger.infoWithSanitize(message, description, corrId, xml);
	},

	logError: function(message, error, corrId, xml) {
		let stack = error instanceof Error ? error.stack : error;
		logger.error(message, stack, corrId, xml);
	},

	error: function(message, error, xml) {
		let stack = error instanceof Error ? error.stack : error;
		return {
			message,
			stack
		};
	},

	trace: function(message, corrId) {
		logger.trace(message, corrId);
	},

	logBackendServiceRequest: function(backend, request, corrId, xml) {
		logger.logBackendServiceRequest(backend, request, corrId, xml);
		return Date.now();
	},

	logBackendServiceResponse: function(
		backend,
		startTime,
		response,
		jobID,
		corrId, 
		xml
	) {
		logger.logBackendServiceResponse(
			backend,
			startTime,
			response,
			jobID,
			corrId,
			xml
		);
	},

	logBackendServiceTimeout: function(
		backend,
		startTime,
		response,
		jobID,
		corrId,
		xml
	) {
		logger.logBackendServiceTimeout(
			backend,
			startTime,
			response,
			jobID,
			corrId,
			xml
		);
	},

	logBackendServiceError: function(backend, startTime, error, jobID, corrId, xml) {
		let debug_err = error instanceof Error ? error.stack : error;
		logger.logBackendServiceError(
			backend,
			startTime,
			debug_err,
			jobID,
			corrId,
			xml
		);
	}
};
