const init = require("./global.js");
const logger = require("./logger.js");
global.executionContext = {};

module.exports = {
	execute: function(event, context, callback, functionToInvoke, options) {
		let startTime = Date.now();

		init.setGlobalExecutionContext(event, context, options);
		logger.trace("setting global execution context");

		logger.trace("starting initialization");
		init.initialize();

		logger.trace("extracted the details");
		let payload = init.extractPayload(event);

		logger.trace("invoking the service");

		functionToInvoke(payload, options.args)
			.then(data => {
				processSuccess(data, callback, startTime, options.override);
			})
			.catch(err => {
				logger.error(err.message, err.stack);
				if (options.stepFunction) {
					processStepFunctionFailure(err, callback);
				} else if (options.overrideError) {
					processFailureWithOverride(
						err.error,
						err.statusCode,
						err.headers,
						callback
					);
				} else processFailure(err.message, callback);
			});

		process.on("unhandledRejection", err => {
			logger.error("unhandledRejection", err.stack);
			processFailure("unhandledRejection", callback);
		});
	},

	processFailure: function(message, callback) {
		processFailure(message, callback);
	}
};

const processSuccess = async function(data, callback, startTime, override) {
	logger.trace("processing success");
	var response;

	if (override === true) {
		response = data;
	} else {
		response = {
			statusCode: 200,
			headers: {
				"bmo-request-id": global.executionContext.correlationId,
				"Content-Type": "application/json;charset=utf-8"
			},
			body: JSON.stringify(data)
		};
	}
	callback(null, response);
	await init.finalize(response, data, override);

};

const processFailure = function(message, callback) {
	logger.trace("processing failure");

	let response;
	if (typeof message === "object") {
		response = JSON.stringify(message);
	} else response = message;

	logger.debug("Logging Error response:::" + response);
	init.finalize(response);

	callback(response);
};

const processStepFunctionFailure = async function(error, callback) {
	const message = error.message;
	const code = error.code;
	var stack;
	if (error.stack !== undefined) {
		stack = error.stack;
	}

	CustomError.prototype = new Error();
	const customError = new CustomError(message, code, stack);
	callback(customError);
};

function CustomError(message, code, stack) {
	this.name = code;
	this.message = message;
	if (stack !== undefined) {
		this.stack = stack;
	}
}
const processFailureWithOverride = async function(
	error,
	statusCode,
	headers,
	callback
) {
	if (require("./utilities.js").isJson(error)) {
		var errstr = typeof message !== "string" ? JSON.stringify(error) : error;
	} else {
		errstr = error;
	}
	logger.debug(errstr);

	var response = {
		statusCode: statusCode ? statusCode : 500,
		headers: headers
			? headers
			: {
					"bmo-request-id": global.executionContext.correlationId,
					"Content-Type": "application/json;charset=utf-8"
			  },
		body: errstr
	};

	init.finalize(response, errstr);

	callback(null, response);
};
