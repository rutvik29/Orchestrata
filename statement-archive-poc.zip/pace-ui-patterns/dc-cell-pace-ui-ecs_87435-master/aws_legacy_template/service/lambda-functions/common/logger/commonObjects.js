module.exports = {
	// EVENT OBJECTS //

	AutorizerEventDetails: function() {
		let AutorizerEventDetails = {
			type: global.executionContext.incomingEvent.type,
			token: global.executionContext.incomingEvent.authorizationToken
		};

		return AutorizerEventDetails;
	},

	kinesisEventDetails: function() {
		let kinesisEventDetails = {
			kinesis: global.executionContext.incomingEvent.Records[0].kinesis
		};

		return kinesisEventDetails;
	},

	s3EventDetails: function() {
		let s3EventDetails = {
			action: global.executionContext.incomingEvent.Records[0].eventName,
			bucket: global.executionContext.incomingEvent.Records[0].s3.bucket.name,
			key: global.executionContext.incomingEvent.Records[0].s3.object.key,
			size: global.executionContext.incomingEvent.Records[0].s3.object.size
		};

		return s3EventDetails;
	},

	snsEventDetails: function() {
		let snsEventDetails = {
			messageId:
				global.executionContext.incomingEvent.Records[0].Sns["MessageId"],
			type: global.executionContext.incomingEvent.Records[0].Sns["Type"],
			subject: global.executionContext.incomingEvent.Records[0].Sns["Subject"],
			message: global.executionContext.incomingEvent.Records[0].Sns["Message"],
			timeOfNotification:
				global.executionContext.incomingEvent.Records[0].Sns["Timestamp"]
		};

		return snsEventDetails;
	},

	sqsEventDetails: function() {
		let sqsEventDetails = {
			messageId: global.executionContext.incomingEvent.Records[0].messageId,
			recieptHandle:
				global.executionContext.incomingEvent.Records[0].recieptHandle,
			body: global.executionContext.incomingEvent.Records[0].body,
			attributes: global.executionContext.incomingEvent.Records[0].attributes,
			messageAttributes:
				global.executionContext.incomingEvent.Records[0].messageAttributes
		};

		return sqsEventDetails;
	},

	// getDetailsFromEvents

	getDetailsFromEvent: function(event, context) {
		let eventDetails;
		if (event.RequestType && event.StackId) {
			eventDetails = {
				correlationId: event.RequestId,
				amzTraceId: event.RequestId,
				eventSource: "STACK",
				proxy: false,
				functionName: context.functionName
			};
			return eventDetails;
		}
		if (event.resource && event.path && event.httpMethod) {
			//If event from API Gateway
			let correlationId;
			if (event.headers) {
				if (event.headers["bmo-request-id"]) {
					correlationId = event.headers["bmo-request-id"];
				} else if (event.headers["x-request-id"]) {
					correlationId = event.headers["x-request-id"];
				} else if (event.headers["APIHeaderRequest"]) {
					correlationId = JSON.parse(event.headers["APIHeaderRequest"])
						.correlation.requestId;
				} else if (event.headers["apiheaderrequest"]) {
					correlationId = JSON.parse(event.headers["apiheaderrequest"])
						.correlation.requestId;
				} else if (event.headers["APIHeader"]) {
					correlationId = JSON.parse(event.headers["APIHeader"]).correlation
						.requestId;
				} else if (event.headers["apiHeaderRequest"]) {
					correlationId = JSON.parse(event.headers["apiHeaderRequest"]).correlation
						.requestId;
				} 
				else {
					console.log("[WARNING] Missing Header...");
				}
			} else {
				console.log("[WARNING] Missing Header...");
				correlationId = null;
			}
			eventDetails = {
				correlationId: correlationId,
				amzTraceId:
					event.headers && event.headers["X-Amzn-Trace-Id"]
						? event.headers["X-Amzn-Trace-Id"]
						: null,
				eventSource: "API",
				proxy: true,
				functionName: context.functionName,
				stage: event.requestContext ? event.requestContext.stage : null
			};
			if (!eventDetails.correlationId) {
				if (eventDetails.amzTraceId) {
					eventDetails.correlationId = eventDetails.amzTraceId;
				} else {
					eventDetails.correlationId = uuid();
				}
			}
			return eventDetails;
		} else if (event.proxyIntegration && event.proxyIntegration == false) {
			let correlationId;
			if (event.headers) {
				if (event.headers["bmo-request-id"]) {
					correlationId = event.headers["bmo-request-id"];
				} else if (event.headers["APIHeaderRequest"]) {
					correlationId = JSON.parse(event.headers["APIHeaderRequest"])
						.correlation.requestId;
				}
			} else correlationId = null;
			eventDetails = {
				correlationId: correlationId,
				amzTraceId:
					event.headers && event.headers["X-Amzn-Trace-Id"]
						? event.headers["X-Amzn-Trace-Id"]
						: null,
				eventSource: "API",
				proxy: false,
				functionName: context.functionName
			};
			if (!eventDetails.correlationId) {
				if (eventDetails.amzTraceId) {
					eventDetails.correlationId = eventDetails.amzTraceId;
				} else {
					eventDetails.correlationId = uuid();
				}
			}
			return eventDetails;
		}
		else if (event["APIHeaderRequest"] || event["APIHeader"] || event["apiheaderrequest"]){
			let correlationId;
			if (event["APIHeaderRequest"]) {
				correlationId = JSON.parse(event["APIHeaderRequest"])
					.correlation.requestId;
			}
			else if (event["APIHeader"]) {
				correlationId = JSON.parse(event["APIHeader"])
					.correlation.requestId;
			}
			else if (event["apiheaderrequest"]) {
				correlationId = JSON.parse(event["apiheaderrequest"])
					.correlation.requestId;
			}
			else {
				correlationId = uuid();
			}
			
			eventDetails = {
				correlationId: correlationId,
				amzTraceId: context.awsRequestId,
				eventSource: "STEPFUNCTION",
				proxy: false,
				functionName: context.functionName
			}
		}
		//event from cloudformation macro
		else if (
			event.templateParameterValues &&
			event.transformId &&
			event.params &&
			event.requestId
		) {
			eventDetails = {
				correlationId: event.requestId,
				amzTraceId: context.invokeid,
				eventSource: "CFN_MACRO",
				proxy: false,
				functionName: context.functionName,
				stage: event.templateParameterValues.Stage
			};
			return eventDetails;
		}
		//CloudWatch event
		else if (event.source && event.id && event.source === "aws.events") {
			return (eventDetails = {
				correlationId: event.id,
				amzTraceId: context.awsRequestId,
				eventSource: "CLOUDWATCH_CRON",
				functionName: context.functionName
			});
		}
		//CodePipeline event
		else if (event.source && event.id && event.source === "aws.codepipeline") {
			return (eventDetails = {
				correlationId: event.id,
				amzTraceId: context.awsRequestId,
				eventSource: "CODEPIPELINE",
				functionName: context.functionName
			});
		}
		//Custom event
		else if (event.message && event.eventSource === "custom") {
			return (eventDetails = {
				correlationId: event.correlationId,
				amzTraceId: context.awsRequestId,
				eventSource: "CUSTOM",
				functionName: context.functionName
			});
		} else if (event.Records) {
			if (event.Records[0].eventSource === "aws:s3") {
				return (eventDetails = {
					correlationId: context.awsRequestId,
					amzTraceId: context.awsRequestId,
					eventSource: "S3",
					functionName: context.functionName
				});
			} else if (event.Records[0].eventSource === "aws:kinesis") {
				return (eventDetails = {
					correlationId: context.awsRequestId,
					amzTraceId: context.awsRequestId,
					eventSource: "KINESIS",
					functionName: context.functionName
				});
			} else if (event.Records[0].EventSource === "aws:sns") {
				eventDetails = {
					correlationId: context.awsRequestId,
					amzTraceId: context.awsRequestId,
					eventSource: "SNS",
					functionName: context.functionName
				};
				if (
					event.Records[0] &&
					event.Records[0].Sns &&
					event.Records[0].Sns.Message
				) {
					let snsMessage = JSON.parse(event.Records[0].Sns.Message);
					if (
						snsMessage.executionContext &&
						snsMessage.executionContext.correlationId
					) {
						eventDetails.correlationId =
							snsMessage.executionContext.correlationId;
					}
				}
				return eventDetails;
			} else if (event.Records[0].eventSource === "aws:sqs") {
				eventDetails = {
					correlationId: context.awsRequestId,
					amzTraceId: context.awsRequestId,
					eventSource: "SQS",
					functionName: context.functionName
				};
				if (event.Records[0] && event.Records[0].body) {
					let sqsMessage = JSON.parse(event.Records[0].body);
					if (
						sqsMessage.executionContext &&
						sqsMessage.executionContext.correlationId
					) {
						eventDetails.correlationId =
							sqsMessage.executionContext.correlationId;
					}
				}
				return eventDetails;
			} else {
				return new Error("Unsupported.Event.Type");
			}
		} else if (event.type && event.authorizationToken && event.methodArn) {
			return (eventDetails = {
				correlationId: context.awsRequestId,
				amzTraceId: context.invokeid,
				eventSource: "AUTHORIZER",
				functionName: context.functionName
			});
		} else {
			return event;
		}
	},

	// RESPONSE OBJECTS //

	success: function(messages, actualResponseObject) {
		let response = {
			result: {
				code: 200,
				status: "Success",
				messages: messages //should be passed as an array of messages
			},
			actualResponseObject
		};
		return response;
	},

	partial: function(message, actualResponseObject) {
		let response = {
			result: {
				code: 200,
				status: "Partial",
				message
			},
			actualResponseObject
		};
		return response;
	},

	serviceException: function(message) {
		let response = {
			result: {
				code: 500,
				status: "Failure",
				message
			}
		};
		return response;
	},

	serviceUnavailable: function(message) {
		let response = {
			result: {
				code: 503,
				status: "Failure",
				message
			}
		};
		return response;
	},

	serviceTimeout: function(message) {
		let response = {
			result: {
				code: 504,
				status: "Failure",
				message
			}
		};
		return response;
	}
};

function uuid() {
	return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(c) {
		var r = (Math.random() * 16) | 0,
			v = c == "x" ? r : (r & 0x3) | 0x8;
		return v.toString(16);
	});
}
