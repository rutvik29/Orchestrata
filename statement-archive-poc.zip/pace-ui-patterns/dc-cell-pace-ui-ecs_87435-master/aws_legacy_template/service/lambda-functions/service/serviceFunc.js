// var framework = require("../common/logger/framework.js");

// module.exports = {
//     myLambdaFunction: async function(event, args) {
// 		return new Promise((resolve, reject) => {
// 			//extract args from object

// 			framework.debug("This is a debug message");
// 			framework.info("This is an info message");

// 			resolve("done");
// 		});
// 	}
// };