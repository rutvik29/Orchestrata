// Import BMO framework--
// var framework = require("./common/logger/framework.js");
// var AWSXRay = require("aws-xray-sdk-core");
// const AWS = AWSXRay.captureAWS(require("aws-sdk"));
// const region = process.env.REGION || "us-east-1";

const { exec } = require('child_process')

exports.myLambdaFunction = (event, context, callback) => {
	var data = {
		test: 'This is a reply from the helloWorld function',
	};

	var response = {
		statusCode: 200,
		headers: {
			"Content-Type": "application/json;charset=utf-8"
		},
		body: JSON.stringify(data)
	};

	console.log("modify 2")
	callback(null, response);
}


//Obtain function--
// const serviceFunc = require("./service/serviceFunc.js"); //Change me!!

// exports.myLambdaFunction = (event, context, callback) => {
// 	var args = {};

// 	var options = {
// 		args: args,
// 		override: true,
// 		overrideError: true,
// 		overrideInfoBackendLogs: true,
// 		sanitizeArray: ["x-api-key"]
// 	};

// 	// options.override = true;
// 	// options.overrideInfoEventLogs = true; // Request and Response payloads will be printed in INFO mode
// 	// options.overrideInfoBackendLogs = true; // Backend Request and Backend Response will be printed in INFO mode
// 	// options.overrideErrorInfoLogs = true; // Error logs in INFO mode will display stacktrace

// 	// console.log("event in index: " + JSON.stringify(event));

// 	//execute function
// 	framework.execute(event, context, callback, serviceFunc, options);
// };
