// var chaiAsPromised = require("chai-as-promised");
// var chai = require("chai");
// chai.use(chaiAsPromised);
// var proxyquire = require("proxyquire");

// var assert = require("chai").assert;
// var should = require("chai").should();
// var expect = require("chai").expect;
// var sinon = require("sinon");

// describe("Testing ServiceFunction", function() {
// 	//set constant & args
// 	var args, payload;
// 	var serviceFunc;

// 	var infoStub = sinon.stub(),
// 		debugStub = sinon.stub(),
// 		errorStub = sinon.stub();

// 	//subservice method stubs -- if required
// 	// var <function>stub;

// 	var serviceFuncStub = sinon.stub();
// 	before(function() {
// 		//use proxyquire instead of require, to allow stubbing nested requires
// 		serviceFunc = proxyquire("../service/serviceFunc.js", {
// 			//stub logging framework
// 			"../common/logger/framework.js": {
// 				info: infoStub,
// 				debug: debugStub,
// 				error: errorStub
// 			} //stub subservice methods -- uncomment if required
// 			//, "../subservice/<functionname>.js" : <function>stub
// 		});

// 		//AWS.mock("Service", "method", function(params, callback){  /*enter replacement function here*/  });
// 	});

// 	beforeEach(function() {
// 		//set default behaviour of framework stubs
// 		infoStub.callsFake(mssg => {
// 			console.log("\t" + mssg);
// 		});
// 		debugStub.callsFake(mssg => {
// 			console.log("\t[DEBUG]" + mssg);
// 		});
// 		errorStub.callsFake(mssg => {
// 			console.log("\t[ERROR]" + mssg);
// 		});

// 		//set default behaviour of subservice stubs

// 		//set default args
// 		payload = {};
// 		args = {
// 			foo: "bar"
// 		};
// 	});

// 	afterEach(function() {
// 		sinon.resetHistory();
// 	});

// 	it("should exist", function() {
// 		serviceFunc.should.be.a("function");
// 	});

// 	it("should return string", function() {
// 		var res = serviceFunc(payload, args);
// 		return res.should.eventually.be.a("string");
// 	});

// 	it("should return correct string", function() {
// 		return expect(serviceFunc(payload, args)).to.eventually.equal(
// 			"Success, completed test function"
// 		);
// 	});

// 	it("should return error", function() {
// 		args = {
// 			foo: "baz"
// 		};
// 		return expect(serviceFunc(payload, args)).to.eventually.be.rejected;
// 	});
// });
