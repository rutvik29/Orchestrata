# Blank template
Reference: https://bmo.atlassian.net/wiki/spaces/AUTOMATE/pages/645864213/Empty+Template

# ECR PBB-US (PACE) Fargate Container
1. Change the customTag to current date (YYYYMMDD format)
2. Deploy ECR Stack; deployment of ECR uses special CDK command: `/cdk:ecr,<stage>,<account_no>,<region>` to initiate deployment

** ensure your new image has the correct custom tag or else ECS cannnot find it.

As of 2025-03-02, container shared resources are only available in DIT1, SIT1, and PRD1 stage.