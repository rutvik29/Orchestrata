import { configurationHelperFactory } from '@bmo-cdk/common'
import { PurposeCode } from '@bmo-cdk/common/lib/configurationHelper/CommonConfigurationHelperTypes'

/* <Note>
    Please validate the following values. 
    Some of the values were set when creating the repository.
    Please change the values if necessary.
*/
export const createBmoCdkHelper = configurationHelperFactory({
    appCatId: '87435', // App Cat ID 
    projectName: 'paceui', // Alphanumeric only, the project name (e.g., CENG)
    serviceName: 'pbbus-ui', // Alphanumeric and hyphens only
    serviceDescription: 'Pace UI Container Stack', // Any text
    purposeCode: PurposeCode.GENERAL_WORKLOAD, // Purpose code of the multi account. Use PurposeCode.NONE for old account.
    costCenter: 'H9405', // Cost Center
    supportTeam: 'RUN_ENG_CLOUD_PLATFORM_SUPPORT', // Support team
})
