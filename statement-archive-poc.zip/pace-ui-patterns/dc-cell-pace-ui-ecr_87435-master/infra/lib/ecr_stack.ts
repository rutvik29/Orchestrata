import * as cdk from "aws-cdk-lib";
import { GetSSMValue } from "@bmo-cdk/common";
import { BMOEcrRepositoryConstruct } from "@bmo-cdk/ecr";
import { BMOSSMConstruct } from "@bmo-cdk/ssm-parameter";
import { Construct } from "constructs";
import { createBmoCdkHelper } from "../config";
import { extendedBaseTags, edc81n1Accounts } from "../config/constants";

export class EcrStack extends cdk.Stack {
  public readonly ecrRepo: BMOEcrRepositoryConstruct;

  constructor(scope: Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);
    const helper = createBmoCdkHelper(this);
    const owner = extendedBaseTags.portfolioShortCode;
    const accountID: string = helper.deployment.accountId;
    const stage: string = helper.deployment.stage;
    const accountShortCode: string = helper.deployment.accountShortCode;
    const environment: string = helper.deployment.environment;
    const stageShortCode: string = helper.deployment.stageShortCode;
    const region: string = helper.deployment.region;
    const regionShortCode: string = helper.deployment.regionShortCode;
    const serviceName: string = helper.application.serviceName;

    let ecrRepoName = `dc-cell-pace-ecr`; // PASS THE REPOSITORY NAME HERE
    //let dockImageUri = `${accountID}.dkr.ecr.${region}.amazonaws.com/${ecrRepoName}`;
    let promoteImageURI, createRepo, buildDockerImage;

    const kmsKeyArn = GetSSMValue(this,`/${owner}/${serviceName}/${stage}/${regionShortCode}/ecr/kms/key/arn`);
    const iamRoleArn = GetSSMValue(this,`/${owner}/${serviceName}/${stage}/${regionShortCode}/ecs/executionrole`);

    // versionTag in format of YYYYMMDD of when image was built.
    const versionTag = "20250303";

    switch (stage) {
      case "dit1": {
        console.log(`DIT1 Deployment Initiated`);
        createRepo = true;          //set to true to create/update of Repository
        buildDockerImage = true;    //set to true to build/deploy docker image
        //dev creates image from scratch - no promoteURI
        break;
      }
      case "sit1": {
        console.log(`SIT1 Deployment Initiated`);
        // promote image from dev; ensure source of image are in the same region
        promoteImageURI = `${edc81n1Accounts.dev}.dkr.ecr.${region}.amazonaws.com/${ecrRepoName}:${versionTag}`;
        createRepo = true;          //set to true to create/update of Repository
        buildDockerImage = true;    //set to true to build/deploy docker image
        break;
      }
      case "prd": {
        console.log(`PRD Deployment Initiated`);
        // promote image from test; ensure source of image are in the same region
        promoteImageURI = `${edc81n1Accounts.test}.dkr.ecr.${region}.amazonaws.com/${ecrRepoName}:${versionTag}`;
        createRepo = true;          //set to true to create/update of Repository
        buildDockerImage = true;    //set to true to build/deploy docker image
        break;
      }
      default: {
        console.log(`it really shouldn't fall in here; stage doesn't match expected logic.`);
        //deploy from scratch with construct default values
        break;
      }
    }

    //debugging
    console.log(`kms arn: ${kmsKeyArn}`);
    console.log(`iam role: ${iamRoleArn}`);
    console.log(`promoteURI: ${promoteImageURI}`);


    // ##For createing ECR repository, please refer: https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ecr-repository.html
    this.ecrRepo = new BMOEcrRepositoryConstruct(this, `ECRConstruct`, {
      createEcrRepository: createRepo,      // always set to true; setting to false will attempt to delete ECR see https://bmo.atlassian.net/wiki/spaces/AUTOMATE/pages/243271679/ECS+and+ECR+CDKv2+Developer+Guide#Using-the-createEcrRepository-Property
      customImageTag: `${versionTag}`,      // one can tag there docker image with there custom tag by using this attribute
      repositoryName: `${ecrRepoName}`,
      imageMutability: "MUTABLE",           // This property will be used which will allow image tags to be overwritten.By default IMMUTABLE will be used
      dockerImageBuild: buildDockerImage,   
      ...(promoteImageURI && { promoteImageURI }),
      // removalPolicy: RemovalPolicy.DESTROY,
      // autoDeleteImages: true,
      encryptionType: "KMS",                // Encryption type will always be KMS
      kmsKey: `${kmsKeyArn}`,               // provide the KMS key via which ECR will be encrypted.
      readWriteRoles: [iamRoleArn],         // Provide the pass role IAM user
      // ONE CAN GIVE LIFECYCLE  POLICY ACCORDING TO THERE NEED
      // To get more insights on lifecycle policy please refer to https://docs.aws.amazon.com/AmazonECR/latest/userguide/LifecyclePolicies.html
      // lifecyclePolicy: {
      //     lifecyclePolicyText: JSON.stringify({
      //         rules: [
      //             {
      //                 rulePriority: 2,
      //                 description: "Rule 1 Keeping latest 2 images",
      //                 selection: {
      //                     tagStatus: "untagged",
      //                     countType: "imageCountMoreThan",
      //                     countNumber: 2
      //                 },
      //                 action: {
      //                     type: "expire"
      //                 }
      //             }
      //         ]
      //     })
      // },
      // CIO'S SPECIFIC TAGS WILL BE MENTIONED HERE
      tags: extendedBaseTags,
      exceptionCode: ["E059"], 
    });

    // export new repoName arn to SSM parameter
    new BMOSSMConstruct(this, `${serviceName}-${stage}-SSM-ECR-RepoName`, {
      ssmName: `/${owner}/${serviceName}/${stage}/${regionShortCode}/ecr/repositoryName`,
      ssmDescription: `ECR Repo Name Parameter for ${serviceName}`,
      ssmType: "String",
      ssmValue: `${ecrRepoName}`,
      tags: extendedBaseTags,
    });

    // export new docker image uri to SSM parameter
    new BMOSSMConstruct(this, `${serviceName}-${stage}-SSM-ECR-DockerImgUri`, {
      ssmName: `/${owner}/${serviceName}/${stage}/${regionShortCode}/ecr/image/uri`,
      ssmDescription: `ECR docker image uri Parameter for ${serviceName}`,
      ssmType: "String",
      ssmValue: `${this.ecrRepo.repository?.attrRepositoryUri}`,
      tags: extendedBaseTags,
    });

    // export new docker image latest tag to SSM parameter
    new BMOSSMConstruct(this, `${serviceName}-${stage}-SSM-ECR-DockerImgTag`, {
      ssmName: `/${owner}/${serviceName}/${stage}/${regionShortCode}/ecr/image/latestTag`,
      ssmDescription: `ECR docker image custom tag Parameter for ${serviceName}`,
      ssmType: "String",
      ssmValue: `${versionTag}`,
      tags: extendedBaseTags,
    });
  }
}
