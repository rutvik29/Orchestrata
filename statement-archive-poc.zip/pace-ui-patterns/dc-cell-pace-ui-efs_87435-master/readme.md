# Blank template
Reference: https://bmo.atlassian.net/wiki/spaces/AUTOMATE/pages/645864213/Empty+Template

# EFS and DataSync Stack for PBB-US  (PACE) Fargate Container
Use the controller.json to toggle deployment of each stack separately or together; becareful of dependencies (see below).
Sequence as follows:

## 1. EFS DEPLOYMENT
1. Ensure KMS, Security Group and IAM role(s) has been successfully deployed
2. Deploy EFS Stack

## 2. DATA SYNC DEPLOYMENT
1. Ensure ECR and EFS has been successfully deployed
2. Deploy Datasync

