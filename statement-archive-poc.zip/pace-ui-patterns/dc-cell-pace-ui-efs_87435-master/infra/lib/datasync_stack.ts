import * as cdk from 'aws-cdk-lib';
import { BMODataSyncLocationEFSConstruct, BMODataSyncLocationS3Construct, BMODataSyncTaskConstruct } from '@bmo-cdk/datasync';
import { BMOSSMConstruct } from '@bmo-cdk/ssm-parameter';
import { GetSSMValue, safeGetSSMValue } from '@bmo-cdk/common';
import { Construct } from 'constructs';
import { createBmoCdkHelper } from '../config/index';
import { extendedBaseTags } from '../config/constants';

interface DatasyncStackProps extends cdk.StackProps {
  readonly efsAttrArn?: any;
}

export class DatasyncStack extends cdk.Stack {
  public readonly datasyncTask: BMODataSyncTaskConstruct;
  public readonly datasyncS3Source: BMODataSyncLocationS3Construct;
  public readonly datasyncEfsDestination: BMODataSyncLocationEFSConstruct;
  

  constructor(scope: Construct, id: string, props?: DatasyncStackProps) {
    super(scope, id, props);

    const helper = createBmoCdkHelper(this);

    const owner = extendedBaseTags.portfolioShortCode;

    const accountId: string = helper.deployment.accountId;
    const stage: string = helper.deployment.stage;
    const accountShortCode: string = helper.deployment.accountShortCode;
    const environment: string = helper.deployment.environment;
    const stageShortCode: string = helper.deployment.stageShortCode;
    const region: string = helper.deployment.region;
    const regionShortCode: string = helper.deployment.regionShortCode;
    const serviceName: string = helper.application.serviceName;

    const secGroup = GetSSMValue(this,`/ceng/${accountShortCode}/local/${environment}/${regionShortCode}/infra/ntwrk/sg/sg-sharednet-serverless-master`);
    const secGroupArn = `arn:aws:ec2:${region}:${accountId}:security-group/${secGroup}`;

    //available serverless ssm private subnets
    const privSubNet1 = safeGetSSMValue(this,`/ceng/${accountShortCode}/shared/${environment}/${regionShortCode}/infra/ntwrk/subn/subnet-sharednet-01-prv1`,"subnet-bypassSynthesis");
    const privSubNet2 = safeGetSSMValue(this,`/ceng/${accountShortCode}/shared/${environment}/${regionShortCode}/infra/ntwrk/subn/subnet-sharednet-01-prv2`,"subnet-bypassSynthesis");
    const privSubNet3 = safeGetSSMValue(this,`/ceng/${accountShortCode}/shared/${environment}/${regionShortCode}/infra/ntwrk/subn/subnet-sharednet-01-prv3`,"subnet-bypassSynthesis");
    const privSubNet1Arn = `arn:aws:ec2:${region}:${accountId}:subnet/${privSubNet1}`;
    const privSubNet2Arn = `arn:aws:ec2:${region}:${accountId}:subnet/${privSubNet2}`;
    const privSubNet3Arn = `arn:aws:ec2:${region}:${accountId}:subnet/${privSubNet3}`;

    //const s3BucketArn = `${accountShortCode}-${regionShortCode}-${stage}-${serviceName}-efs-artifacts`;
    //const s3BucketAccessArn = `arn:aws:iam::${accountId}:role/9999994/DatasyncIAMRole/${accountShortCode}-${regionShortCode}-${stageShortCode}-serverless-DataSyncRole`;
    const s3BucketArn = GetSSMValue(this, `/ceng/serverless/datasync-customresource/${environment}/na/${regionShortCode}/othr/cmpt/bucket/arn`);
    const s3BucketAccessArn = GetSSMValue(this, `/ceng/serverless/datasync-customresource/${environment}/na/${regionShortCode}/othr/cmpt/role/arn`);

    const ecrRepoName = GetSSMValue(this, `/${owner}/${serviceName}/${stage}/${regionShortCode}/ecr/repositoryName`);

    let efsArn: string;
    // if controller.json toggled to deploy EFS then take the value from EFS stack
    if (props?.efsAttrArn) {
      console.log(`efs arn passed in from props`);
      efsArn = props.efsAttrArn;
    } else {
      console.log(`efs arn taken from ssm`);
      efsArn = GetSSMValue(this, `/${owner}/${serviceName}/${stage}/${regionShortCode}/efs/arn`);
    }


    //debugging
    console.log(`ecr repo name: ${ecrRepoName}`);
    console.log(`efs arn: ${efsArn}`);
    console.log(`security group: ${secGroup}`);
    console.log(`security group arn: ${secGroupArn}`);
    console.log(`private subnet: ${privSubNet1}, ${privSubNet2}, ${privSubNet3}`);
    console.log(`private subnet arns: ${privSubNet1Arn}, ${privSubNet2Arn}, ${privSubNet3Arn}`);
    console.log(`s3 bucket arn: ${s3BucketArn}`);
    console.log(`s3 bucket iam role arn: ${s3BucketAccessArn}`);
    console.log(`extended Base Tags: ${JSON.stringify(extendedBaseTags)}`);

    //define S3 source; this should match what was described in your build.sh in your web app deployment
    //s3 iam role name = ${accountShortCode}-${regionShortCode}-${stageShortCode}-serverless-DataSyncRole
    this.datasyncS3Source = new BMODataSyncLocationS3Construct(this, 'dataSyncSource', {
      projectName: `${serviceName}`,
      s3BucketArn: `${s3BucketArn}`,
      bucketAccessRoleArn: `${s3BucketAccessArn}`,
      subdirectory: `/${ecrRepoName}/`,  //match to ECR Repo Name (this should match in your build.sh)
      s3StorageClass: "STANDARD",
      tags: extendedBaseTags
    });

    // define EFS destination; this should match what was described in EFS stacks.
    this.datasyncEfsDestination = new BMODataSyncLocationEFSConstruct(this, 'dataSyncDestination', {
      securityGroupArns: [`${secGroupArn}`],
      subnetArn: `${privSubNet1Arn}`,
      efsFilesystemArn: `${efsArn}`,
      inTransitEncryption: "NONE",
      subdirectory: `/${ecrRepoName}/applications`,
      tags: extendedBaseTags
    });

    //define task to perform the datasync action between S3 and EFS volume
    this.datasyncTask = new BMODataSyncTaskConstruct(this, 'dataSyncTask', {
        name: `${accountShortCode}-${regionShortCode}-${stageShortCode}-datasync-tsk`,
        sourceLocationArn: this.datasyncS3Source.dataSyncLocationS3.attrLocationArn,
        destinationLocationArn: this.datasyncEfsDestination.dataSyncLocationEFS.attrLocationArn,
        cloudWatchLogGroupArn: `arn:aws:logs:${region}:${accountId}:log-group:/aws/datasync`,
        options: {
            verifyMode: "NONE",                 //verfy the transfer
            overwriteMode: "ALWAYS",            //toggle whether to overwrite existing files
            preserveDeletedFiles: "PRESERVE",   //perform any backups
            logLevel: "BASIC"
        },
        tags: extendedBaseTags
    });
    this.datasyncTask.node.addDependency(this.datasyncS3Source);
    this.datasyncTask.node.addDependency(this.datasyncEfsDestination);


    //Export Datasync ARN to SSM
    new BMOSSMConstruct(this, 'dataSyncTaskArn-SSM', {
      ssmName: `/${owner}/${serviceName}/${stage}/${regionShortCode}/efs/datasync/task/arn`,
      ssmDescription: `dataSyncTaskArn for ${serviceName}`,
      ssmType: 'String',
      ssmValue: this.datasyncTask.dataSyncTask.attrTaskArn,
      tags: extendedBaseTags
    });

  }
}
