import * as cdk from 'aws-cdk-lib';
import { BMOEFSConstruct } from '@bmo-cdk/efs';
import { BMOSSMConstruct } from '@bmo-cdk/ssm-parameter';
import { GetSSMValue, safeGetSSMValue } from '@bmo-cdk/common';
import { Construct } from 'constructs';
import { createBmoCdkHelper } from '../config/index';
import { extendedBaseTags } from '../config/constants';

export class EfsStack extends cdk.Stack {
  public readonly efsVolume: BMOEFSConstruct;

  constructor(scope: Construct, id: string, props: cdk.StackProps) {
    super(scope, id, props);

    const helper = createBmoCdkHelper(this);

    const owner = extendedBaseTags.portfolioShortCode;

    const accountId: string = helper.deployment.accountId;
    const stage: string = helper.deployment.stage;
    const accountShortCode: string = helper.deployment.accountShortCode;
    const environment: string = helper.deployment.environment;
    const stageShortCode: string = helper.deployment.stageShortCode;
    const region: string = helper.deployment.region;
    const regionShortCode: string = helper.deployment.regionShortCode;
    const serviceName: string = helper.application.serviceName;

    const ecrRepoName = GetSSMValue(this,`/${owner}/${serviceName}/${stage}/${regionShortCode}/ecr/repositoryName`);
    const kmsId = GetSSMValue(this,`/${owner}/${serviceName}/${stage}/${regionShortCode}/ecr/kms/key/id`);
    const iamRoleArn = GetSSMValue(this,`/${owner}/${serviceName}/${stage}/${regionShortCode}/ecs/executionrole`);
    
    const secGroup = GetSSMValue(this,`/ceng/${accountShortCode}/local/${environment}/${regionShortCode}/infra/ntwrk/sg/sg-sharednet-serverless-master`);

    // Must pick the same subnet as the EFS stack, so that EFS and ECS are in the same AZ
    //available serverless ssm private subnets
    const privSubNet1 = safeGetSSMValue(this,`/ceng/${accountShortCode}/shared/${environment}/${regionShortCode}/infra/ntwrk/subn/subnet-sharednet-01-prv1`,"subnet-bypassSynthesis");
    const privSubNet2 = safeGetSSMValue(this,`/ceng/${accountShortCode}/shared/${environment}/${regionShortCode}/infra/ntwrk/subn/subnet-sharednet-01-prv2`,"subnet-bypassSynthesis");
    const privSubNet3 = safeGetSSMValue(this,`/ceng/${accountShortCode}/shared/${environment}/${regionShortCode}/infra/ntwrk/subn/subnet-sharednet-01-prv3`,"subnet-bypassSynthesis");

    //debugging
    console.log(`kms arn: ${kmsId}`);
    console.log(`iam role arn: ${iamRoleArn}`);
    console.log(`security group: ${secGroup}`);
    console.log(`private subnet: ${privSubNet1}, ${privSubNet2}, ${privSubNet3}`);
    console.log(`extended Base Tags: ${JSON.stringify(extendedBaseTags)}`);

    this.efsVolume = new BMOEFSConstruct(this, `${serviceName}-${stage}-efs`, {
      fileSystemName: `${accountShortCode}-${stageShortCode}-${regionShortCode}-${serviceName}-efs`,
      kmsKeyId: `${kmsId}`,
      backupPolicyStatus: 'ENABLED',
      tags: extendedBaseTags,
      fileSystemPolicy: {
        Version: "2012-10-17",
        Statement: [
          {
            "Sid": "RestrictAccess",
            "Effect": "Allow",
            "Principal": {
              "AWS": [iamRoleArn]
            },
            "Action": [
              "elasticfilesystem:ClientWrite",
              "elasticfilesystem:ClientMount"
            ],
            "Condition": { "StringEquals": { "elasticfilesystem:AccessPointArn": `arn:aws:elasticfilesystem:${region}:${accountId}:access-point/*` } }
          },
          {
            "Sid": "InTransitEncryption",
            "Effect": "Deny",
            "Principal": {
              "AWS": [iamRoleArn]
            },
            "Action": "*",
            "Condition": {
              "Bool": {
                "aws:SecureTransport": false
              }
            }
          },
          {
            "Sid": "DataSyncAccessViaMountTarget",
            "Effect": "Allow",
            "Principal": {
              "AWS": "*"
            },
            "Action": [
              "elasticfilesystem:ClientWrite",
              "elasticfilesystem:ClientMount",
              "elasticfilesystem:ClientRootAccess"
            ],
            "Condition": {
              "Bool": {
                "elasticfilesystem:AccessedViaMountTarget": "true"
              }
            }
          }
        ]
      },
      performanceMode: 'generalPurpose',
      throughputMode: 'bursting',
      accessPointDetails: [{
        rootdirectory: { 
          path: `/${ecrRepoName}/applications`, 
          creationInfo: { 
            ownerGid: "65534", 
            ownerUid: "65534", 
            permissions: "0755" 
          } 
        },
        posixuser: { uid: '65534', gid: '65534' },
        name: `${serviceName}-efs-accesspoint`
      }],
      mountTarget: {
        securityGroups: [secGroup],
        subnetIds: [privSubNet1, privSubNet2, privSubNet3]
      }
    });

    // Export EFS ID to SSM
    const efsIdSsm  = new BMOSSMConstruct(this, `${serviceName}-${stage}-SSM-efsId`, {
      ssmName: `/${owner}/${serviceName}/${stage}/${regionShortCode}/efs/id`,
      ssmDescription: `EFS Volume ID for ${serviceName}`,
      ssmType: 'String',
      ssmValue: this.efsVolume.efs.ref,  //output is nlb arn
      tags: extendedBaseTags
    });

    // Export EFS ARN to SSM
    const efsArnSsm  = new BMOSSMConstruct(this, `${serviceName}-${stage}-SSM-efsArn`, {
      ssmName: `/${owner}/${serviceName}/${stage}/${regionShortCode}/efs/arn`,
      ssmDescription: `EFS Volume ARN for ${serviceName}`,
      ssmType: 'String',
      ssmValue: this.efsVolume.efs.attrArn,  //output is nlb arn
      tags: extendedBaseTags
    });

    // Export EFS DNS to SSM
    const efsDnsSsm  = new BMOSSMConstruct(this, `${serviceName}-${stage}-SSM-efsDns`, {
      ssmName: `/${owner}/${serviceName}/${stage}/${regionShortCode}/efs/dnsName`,
      ssmDescription: `EFS Volume DNS for ${serviceName}`,
      ssmType: 'String',
      ssmValue: `${this.efsVolume.efs.ref}.efs.${region}.amazonaws.com`,  //output is efs dns
      tags: extendedBaseTags
    });

    // Export Access Point Id to SSM
    const accessPointIdSsm  = new BMOSSMConstruct(this, `${serviceName}-${stage}-SSM-accessPointId`, {
      ssmName: `/${owner}/${serviceName}/${stage}/${regionShortCode}/efs/accessPoint/id`,
      ssmDescription: `Access point id to ${serviceName}`,
      ssmType: 'String',
      ssmValue: `${this.efsVolume.accessPoint?.attrAccessPointId}`,  //output is access point id
      //ssmValue: this.efsVolume.accessPoint.ref,  //output is ??
      tags: extendedBaseTags
    });

    // Export Access Point ARN to SSM
    const accessPointArnSsm  = new BMOSSMConstruct(this, `${serviceName}-${stage}-SSM-accessPointArn`, {
      ssmName: `/${owner}/${serviceName}/${stage}/${regionShortCode}/efs/accessPoint/arn`,
      ssmDescription: `Access point arn to ${serviceName}`,
      ssmType: 'String',
      ssmValue: `${this.efsVolume.accessPoint?.attrArn}`,  //output is access point arn
      tags: extendedBaseTags
    });

  }
}
