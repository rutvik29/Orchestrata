import { configurationHelperFactory } from '@bmo-cdk/common'
import { PurposeCode } from '@bmo-cdk/common/lib/configurationHelper/CommonConfigurationHelperTypes'

/* <Note>
    Please validate the following values. 
    Some of the values were set when creating the repository.
    Please change the values if necessary.
*/
export const createBmoCdkHelper = configurationHelperFactory({
    appCatId: '87435', // App Cat ID 
    projectName: '[Please enter your project id]', // Alphanumeric only, the project name (e.g., CENG)
    serviceName: 'dc-cell-pace-ui-webapp', // Alphanumeric and hyphens only
    serviceDescription: '[Please enter your service description]', // Any text
    purposeCode: PurposeCode.GENERAL_WORKLOAD, // Purpose code of the multi account. Use PurposeCode.NONE for old account.
    costCenter: '[Please enter your cost center]', // Cost Center
    supportTeam: 'RUN_ENG_CLOUD_PLATFORM_SUPPORT', // Support team
})
