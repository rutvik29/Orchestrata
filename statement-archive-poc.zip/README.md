# Statement Archive — End-to-End POC

Everything in one folder: the AI-agent SDLC tooling (VS Code extension + project-bound
agents), the production Statement Archive facade over NCP Direct Access, the PACE UI
pattern repos, and a runnable demo UI. Use this to show the full story:
spec → contract → code → tests → gates → UI, all maintained by agents.

## Folder Map

| Folder | What it is |
|---|---|
| `vscode-extension/` | The sdlc-assistant VS Code extension source with the **project-bound agent pack** installed in `agents/` (14 agents: sdlc orchestrator, Swagger, statement-archive, dev, qa, security, etc., each carrying the Project Binding, PACE topology, and UI Change Request Playbook) |
| `statement-archive-delivery/` | The production facade: OpenAPI 3.0.3 (enterprise contract preserved + BIAN paths), AWS Lambda Node.js code, Mocha unit tests, design doc + Mermaid diagrams, contract regression gate, CI workflow, source WSDL/NCP spec/enterprise contract |
| `ui/` | **Runnable demo UI** — statements screen with the account-history side panel, backed by a zero-dependency mock of the facade API |
| `pace-ui-patterns/` | The BMO PACE `dc-cell-pace-ui-*` repos (webapp, ecs patterns, ecr, efs, kms, nlb) — the production UI/infra target the agents route changes to |

## 5-Minute Demo Script

1. **Run the UI** (no installs needed):
   ```bash
   cd ui && node mock-server.js     # then open http://localhost:3000
   ```
   - Enter account `11111111` → List Statements (calls `ListStatement` with the enterprise headers)
   - Click **View** (GetAccountPDFinline → PDF opens) and **Download** (GetAccountPDF)
   - Click the **account number hyperlink** → side panel with the full 36-month history
   - Wait 2 minutes (demo TTL) and click View again → watch the **session-expired auto-refresh** (mirrors the NCP 30-minute statementKey rule, error code 1001)
2. **Show the contract**: open `statement-archive-delivery/swagger/statement-archive.openapi.yaml` in Swagger UI/editor — legacy + BIAN paths, ten enterprise headers, Zalando errors, `application/pdf` binary.
3. **Show the gates**:
   ```bash
   cd statement-archive-delivery
   pip install pyyaml && python3 scripts/validate-openapi.py   # contract regression gate
   cd api && npm install && npm test                           # ~45 Mocha assertions
   ```
4. **Show the agents**: open `vscode-extension/agents/dev.agent.md` — Project Binding, PACE topology table, UI Change Request Playbook. Then run the extension (F5 in VS Code) and ask the sdlc agent: *"add a download-all button to the account history side panel"* — it routes impact → dev → qa with the project gates enforced.
5. **Show the design**: `statement-archive-delivery/design/statement-archive-design.md` — architecture + sequence diagrams, error mapping, security model.

## Wiring the Demo UI to the Real Facade

The demo UI speaks the exact production contract. To point it at a deployed facade,
set `const API = 'https://<api-gateway-host>'` at the top of `ui/index.html` and use a
real `x-api-key`. The mock server (`ui/mock-server.js`) is for demos only — it mirrors
the contract shapes (headers, errorResponse, expiry behavior) but not real NCP data.

## GitHub Copilot Integration — Full SDLC Coverage

The extension drives GitHub Copilot CLI (`@github/copilot-sdk`, one session per
phase). Build the installable package with `vscode-extension/build-vsix.cmd`
(Windows) or `./build-vsix.sh` — see `vscode-extension/BUILD-VSIX.md` for the
Copilot CLI + agent-install checklist. Agents are discovered from
`~/.copilot/agents` or `<workspace>/.copilot/agents` (a workspace copy ships in
`vscode-extension/.copilot/agents/`).

Every SDLC phase is covered by a project-bound agent with deterministic artifacts and gates:

| SDLC Phase | Agent | Key Artifacts | Gate |
|---|---|---|---|
| Knowledge intake | `doc-processor` | `docs/processed/INDEX.md`, role context files | Source traceability, NCP names verbatim |
| Business analysis | `ba-analyst` | `ba_artifacts/BRD.md`, UserStories, ProcessFlows | Security/perf NFRs + testable acceptance criteria |
| Architecture | `architect` | `architecture/*.md` + C4/ERD/sequence Mermaid | Fixed AWS/PACE topology extended, never replaced |
| Impact analysis | `impact` (@fixagent) | `impact_analysis/*.md` | Direct-change mirror paths incl. PACE repos |
| API contract | `Swagger` / `statement-archive` | `swagger/statement-archive.openapi.yaml` | `scripts/validate-openapi.py` contract regression gate |
| Development | `dev` | facade code + webapp UI + Mocha tests | `npm test`, `node --check`, frozen artifacts untouched |
| Code review | `codereview` | `review_artifacts/CodeReview.md` | Blockers incl. project checklist (hash, Warning header, masking) |
| Security review | `security` | `security_artifacts/` (Review, ThreatModel, Checklist) | STRIDE on both trust boundaries, key handling |
| Performance review | `performance` | `performance_artifacts/PerformanceNfrAssessment.md` | Timeout budget, PDF memory, cold start |
| QA | `qa` | `qa_artifacts/` (Strategy, Plan, Cases md+csv, Traceability, Playwright) | 100% requirement coverage, exact NCP fixtures |
| DevOps | `devops` | pipeline extensions, `devops_artifacts/DeploymentRunbook.md` | compliant-* workflows preserved, rollback + secret rotation |
| Documentation | `appoverview` | overview + developer docs | Evidence map from actual code |
| Orchestration | `sdlc` | end-to-end phase routing + feedback loops | Per-phase verification incl. project gates |

Review agents emit `## Affected Phases: [...]` markers so the orchestrator
re-runs exactly the phases that need remediation — the feedback loop is closed
without manual routing.
