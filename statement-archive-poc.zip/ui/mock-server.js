'use strict';
/**
 * POC mock facade + static UI server (Node stdlib only — zero dependencies).
 *
 * Implements the two BIAN consumer operations of the Statement Archive facade
 * with the same contract shapes as the real Lambda (headers, errorResponse,
 * ListStatementResponse, application/pdf retrieve, statementKey expiry), so
 * the demo UI exercises the exact production API contract.
 *
 * Run:  node mock-server.js   →  http://localhost:3000
 * Env:  PORT (default 3000), KEY_TTL_MS (statementKey expiry, default 120000
 *       = 2 minutes so the session-expired flow is easy to demo; production is 30 minutes).
 */
const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 3000;
const KEY_TTL_MS = parseInt(process.env.KEY_TTL_MS || '120000', 10);
const REQUIRED_HEADERS = ['x-request-id', 'x-api-key', 'x-fapi-financial-id', 'x-app-cat-id'];

/* ---------------- sample archive data ---------------- */
function monthEnd(offset) {
  const d = new Date();
  d.setDate(1);
  d.setMonth(d.getMonth() - offset + 1);
  d.setDate(0);
  return d;
}
function iso(d) { return d.toISOString().slice(0, 10); }

function buildStatements(accountNumber, months) {
  const issuedAt = Date.now();
  const out = [];
  for (let i = 1; i <= months; i += 1) {
    const date = monthEnd(i);
    out.push({
      statementKey: Buffer.from(`${accountNumber}|${iso(date)}|${issuedAt}`).toString('base64'),
      statementDate: iso(date),
      description: 'Monthly Statement',
      product: '00001000'
    });
  }
  return out;
}

/* ---------------- minimal valid PDF ---------------- */
function buildPdf(lines) {
  const content = [
    'BT /F1 20 Tf 60 740 Td (BMO Mortgage Statement Archive - POC) Tj ET',
    ...lines.map((l, i) => `BT /F1 12 Tf 60 ${700 - i * 22} Td (${l.replace(/[()\\]/g, '')}) Tj ET`)
  ].join('\n');
  const objs = [
    '<< /Type /Catalog /Pages 2 0 R >>',
    '<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
    '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>',
    '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>',
    `<< /Length ${content.length} >>\nstream\n${content}\nendstream`
  ];
  let pdf = '%PDF-1.4\n';
  const offsets = [0];
  objs.forEach((body, i) => {
    offsets.push(pdf.length);
    pdf += `${i + 1} 0 obj\n${body}\nendobj\n`;
  });
  const xref = pdf.length;
  pdf += `xref\n0 ${objs.length + 1}\n0000000000 65535 f \n`;
  for (let i = 1; i <= objs.length; i += 1) pdf += `${String(offsets[i]).padStart(10, '0')} 00000 n \n`;
  pdf += `trailer\n<< /Size ${objs.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
  return Buffer.from(pdf, 'binary');
}

/* ---------------- contract helpers (mirror the real facade) ---------------- */
function errorResponse(status, title, detail, instance) {
  return { type: 'about:blank', title, status, detail, instance };
}
function correlation(req) {
  const h = {};
  const rid = req.headers['x-request-id'];
  if (rid) { h['x-request-id'] = rid; h['x-fapi-interaction-id'] = req.headers['x-fapi-interaction-id'] || rid; }
  return h;
}
function sendJson(req, res, status, body) {
  res.writeHead(status, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*', ...correlation(req) });
  res.end(JSON.stringify(body));
}
function readBody(req) {
  return new Promise((resolve) => {
    let data = '';
    req.on('data', (c) => { data += c; });
    req.on('end', () => { try { resolve(JSON.parse(data || '{}')); } catch { resolve(null); } });
  });
}

/* ---------------- server ---------------- */
const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
      'Access-Control-Allow-Headers': '*'
    });
    return res.end();
  }

  if (req.method === 'GET' && (req.url === '/' || req.url === '/index.html')) {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    return res.end(fs.readFileSync(path.join(__dirname, 'index.html')));
  }

  if (req.method !== 'POST') {
    return sendJson(req, res, 404, errorResponse(404, 'Not Found', 'Resource not found', req.url));
  }

  const missing = REQUIRED_HEADERS.filter((h) => !req.headers[h]);
  if (missing.length) {
    return sendJson(req, res, 400, errorResponse(400, 'Bad Request', `Missing required headers: ${missing.join(', ')}`, req.url));
  }
  const body = await readBody(req);
  if (body === null) {
    return sendJson(req, res, 400, errorResponse(400, 'Bad Request', 'Request body must be valid JSON', req.url));
  }

  if (req.url === '/statement-archive/v1/statements/list') {
    if (!body.accountNumber) {
      return sendJson(req, res, 400, errorResponse(400, 'Bad Request', 'Missing required field: accountNumber', req.url));
    }
    // Full history when no dates provided (36-month default window), else 6 recent.
    const months = body.startDate || body.endDate ? 6 : 36;
    return sendJson(req, res, 200, {
      result: { code: '200', status: 'SUCCESS', messages: [] },
      statements: buildStatements(String(body.accountNumber).split('|')[0], months)
    });
  }

  if (req.url === '/statement-archive/v1/statements/retrieve') {
    const { statementKey, operationName, accountNumber } = body;
    if (!statementKey || !operationName || !accountNumber) {
      return sendJson(req, res, 400, errorResponse(400, 'Bad Request', 'Missing required fields: statementKey, operationName, accountNumber', req.url));
    }
    if (!['GetAccountPDF', 'GetAccountPDFinline'].includes(operationName)) {
      return sendJson(req, res, 400, errorResponse(400, 'Bad Request', 'operationName must be GetAccountPDF or GetAccountPDFinline', req.url));
    }
    const decoded = Buffer.from(statementKey, 'base64').toString('utf8').split('|');
    const issuedAt = parseInt(decoded[2] || '0', 10);
    if (!issuedAt || Date.now() - issuedAt > KEY_TTL_MS) {
      // Mirrors NCP 1001/1200: statement key expired (30-minute limit in production).
      return sendJson(req, res, 401, {
        ...errorResponse(401, 'Unauthorized', 'Your session or document link has expired. Please request the statement list again.', req.url),
        resultDetails: [{ detailCode: '1001', detailMessage: 'NCP backend error reference code' }]
      });
    }
    const pdf = buildPdf([
      `Account: ${accountNumber}`,
      `Statement date: ${decoded[1]}`,
      'Description: Monthly Statement    Product: 00001000',
      `Retrieved via ${operationName} (mock NCP backend)`
    ]);
    res.writeHead(200, {
      'Content-Type': 'application/pdf',
      'Content-Disposition': operationName === 'GetAccountPDFinline' ? 'inline' : 'attachment; filename="statement.pdf"',
      'Access-Control-Allow-Origin': '*',
      ...correlation(req)
    });
    return res.end(pdf);
  }

  return sendJson(req, res, 404, errorResponse(404, 'Not Found', 'Resource not found', req.url));
});

server.listen(PORT, () => console.log(`Statement Archive POC running at http://localhost:${PORT} (statementKey TTL ${KEY_TTL_MS / 1000}s)`));
