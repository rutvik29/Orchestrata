# Demo Statements UI (POC)

Zero-dependency demo of the Statement Archive consumer UI.

Run: `node mock-server.js` → http://localhost:3000

- `index.html` — statements screen: list, per-row View (inline PDF) / Download,
  account hyperlink → full-history side panel, session-expired auto re-list, toasts.
  Sends the enterprise headers on every call; renders only sanitized errors.
- `mock-server.js` — Node stdlib server implementing the two BIAN facade operations
  with production contract shapes (headers, Zalando errorResponse, statementKey
  expiry → 401 detailCode 1001, application/pdf with Content-Disposition).
  Env: `PORT` (3000), `KEY_TTL_MS` (default 120000 for easy expiry demos; production is 30 min).

This UI is the "seed" for the real webapp in `pace-ui-patterns/dc-cell-pace-ui-webapp`;
UI change requests (add/update/delete) route through the agent pack's UI Change
Request Playbook.
