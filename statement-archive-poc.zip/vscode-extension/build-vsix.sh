#!/usr/bin/env bash
# Build the BMO Digital Core SDLC Assistant .vsix (macOS/Linux)
set -euo pipefail
cd "$(dirname "$0")/sdlc"
npm install --no-audit --no-fund
npm run build
npx --yes @vscode/vsce package --allow-missing-repository -o ../sdlc-assistant-2.0.0.vsix
echo "VSIX created: $(dirname "$0")/sdlc-assistant-2.0.0.vsix"
echo "Install with: code --install-extension sdlc-assistant-2.0.0.vsix"
