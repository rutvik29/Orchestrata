# Building & Installing the .vsix

The extension ships as source (TypeScript, bundled with esbuild). Producing the
installable `.vsix` is one command on any machine with Node 18+ and npm access:

    Windows:      build-vsix.cmd
    macOS/Linux:  ./build-vsix.sh

This runs `npm install` → `npm run build` (esbuild bundles `dist/extension.js`
and `media/webview.js`) → `npx @vscode/vsce package`, producing
`sdlc-assistant-2.0.0.vsix` in this folder.

Install it:

    code --install-extension sdlc-assistant-2.0.0.vsix

## GitHub Copilot integration checklist (required to run the pipeline)

1. **GitHub Copilot CLI** installed and signed in (`copilot` on PATH, or set the
   `sdlc.copilotCliPath` setting / `COPILOT_CLI_PATH` env var). The extension
   drives Copilot through `@github/copilot-sdk`, one fresh session per phase.
2. **Agents installed** where the extension discovers them —
   `~/.copilot/agents` (global) or `<workspace>/.copilot/agents` (override):

       node sdlc/scripts/install-agents.mjs        # installs agents/ -> ~/.copilot/agents

   This repo also ships a workspace-local copy in `.copilot/agents/`, so opening
   this folder as the VS Code workspace works with zero setup.
3. **Model**: pick the Copilot model via the `sdlc.model` setting (webview Run
   configuration also exposes it).
4. Open the panel: Command Palette -> "SDLC" -> `sdlc.openPanel`
   (BMO Digital Core — SDLC Assistant).
