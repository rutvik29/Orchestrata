# API Integration Guide

## Overview

This document describes the integration of the Statements SOAP service with SDLC Assistant via a REST API wrapper and OpenAPI (Swagger) specification.

## Purpose

The SDLC Assistant now provides:
- **REST API wrapper** — Converts SOAP calls to REST endpoints for easier consumption
- **OpenAPI/Swagger documentation** — Machine-readable and human-browsable API spec
- **Webview integration** — Swagger UI panel embedded in the SDLC Assistant UI
- **Automatic link injection** — Phase output automatically links recognized parameters to their API operations

## Architecture

### Components

| Component | Location | Purpose |
|-----------|----------|---------|
| **WSDL / SOAP Backend** | `https://directaccess.ncpsolutions.com:8443/AvailableImages/Statements.svc` | Original SOAP service hosting 4 operations |
| **OpenAPI Spec** | `swagger/statements-api.openapi.json` | REST endpoint definitions and schemas (OpenAPI 3.0) |
| **REST Wrapper** | `api-wrapper/server.js` | Express.js service on localhost:3000 that proxies SOAP → REST |
| **API Registry** | `src/context/apiRegistry.ts` | TypeScript module that manages operation catalog and linkification |
| **Webview Integration** | `src/webview/` | Swagger UI panel + link rendering in phase output |

### Data Flow

```
User Input (e.g., "build auth system")
    ↓
SDLC Pipeline Orchestrator (phase-by-phase execution)
    ↓
Phase Output (markdown text with embedded parameter names like "clientId")
    ↓
API Registry scans output for recognized parameters
    ↓
Linkified Output: "[clientId→API](/swagger/authenticate)"
    ↓
Webview renders links; clicking opens Swagger UI with operation schema
```

## REST API Endpoints

### Authentication

**Endpoint:** `POST /api/authenticate`

**Purpose:** Authenticate a user and obtain a token for subsequent calls.

**Request:**
```json
{
  "clientId": "CLIENT123",
  "userId": "user@example.com",
  "password": "password",
  "account": "ACC001",
  "startDate": "2026-01-01",
  "endDate": "2026-12-31"
}
```

**Response:**
```json
{
  "status": "success",
  "statusCode": 200,
  "data": {
    "token": "eyJ...",
    "expiresIn": 3600,
    "userId": "user@example.com"
  }
}
```

### List Statements

**Endpoint:** `GET /api/list?token=<token>`

**Purpose:** Retrieve a list of available statements for the authenticated user.

**Response:**
```json
{
  "status": "success",
  "data": {
    "statements": [...],
    "count": 5
  }
}
```

### Dynamic List

**Endpoint:** `POST /api/list-dynamic`

**Purpose:** List statements with custom filtering.

**Request:**
```json
{
  "token": "eyJ...",
  "filters": {
    "startDate": "2026-01-01",
    "endDate": "2026-06-30",
    "documentType": "STATEMENT"
  }
}
```

### Create PDF

**Endpoint:** `POST /api/create-pdf`

**Purpose:** Generate a multi-document PDF from selected statements.

**Request:**
```json
{
  "token": "eyJ...",
  "documentIds": ["DOC001", "DOC002"],
  "filename": "statements.pdf"
}
```

**Response:**
```json
{
  "status": "success",
  "data": {
    "pdfUrl": "http://localhost:3000/pdf/PDF_...",
    "pdfId": "PDF_20260706_124718",
    "size": 2048576,
    "createdAt": "2026-07-06T12:47:18Z"
  }
}
```

### Get Operation Schema

**Endpoint:** `GET /api/schema/{operation}`

**Purpose:** Retrieve request/response schemas for an operation (used by Swagger UI).

**Parameters:** 
- `operation`: One of `authenticate`, `list`, `listDynamic`, `createMultidocPDF`

**Response:**
```json
{
  "status": "success",
  "data": {
    "operation": "authenticate",
    "requestSchema": {...},
    "responseSchema": {...}
  }
}
```

### Swagger Specification

**Endpoint:** `GET /swagger.json`

**Purpose:** Serve the full OpenAPI specification.

## How the Pipeline Uses APIs

### Document Processing Phase
- **Agents:** `doc-processor`
- **API Operations Used:** None directly (processes raw documents)
- **Output:** References to document types that may later use `/api/list`

### Business Analysis Phase
- **Agents:** `ba-analyst`
- **API Operations Used:** May reference authentication and listing patterns
- **Output:** If mentioning "clientId" or "token", links are injected

### Development Phase
- **Agents:** `dev`
- **API Operations Used:** Writes code that calls `/api/authenticate` or `/api/list`
- **Output:** Code snippets with hyperlinked parameters

### Example: Phase Output with Links

Before linkification:
```
The system authenticates via the Statements service by passing clientId, userId, and password.
After authentication, the token is used in subsequent List and ListDynamic calls.
```

After linkification:
```
The system authenticates via the Statements service by passing [clientId→API](/swagger/authenticate), [userId→API](/swagger/authenticate), and [password→API](/swagger/authenticate).
After authentication, the [token→API](/swagger/list) is used in subsequent List and ListDynamic calls.
```

## Running the API Wrapper

### Start the Service

```bash
npm run api:serve
```

This command:
1. Installs dependencies in `api-wrapper/`
2. Starts the Express server on `http://localhost:3000`
3. Loads the WSDL from the backend on first request
4. Serves Swagger spec at `/swagger.json`

### Health Check

```bash
curl http://localhost:3000/health
```

### Access Swagger UI

In SDLC Assistant:
1. Click the **"Swagger UI"** toolbar button
2. Or click any parameter hyperlink in phase output (e.g., `[clientId→API](/swagger/authenticate)`)
3. The embedded Swagger UI panel opens, showing operation details and schemas

## Integration with insertQueryAndRule.js

The `insertQueryAndRule.js` script demonstrates how queries and rules are configured. The API integration adds documentation linking those queries to the Statements API operations:

```javascript
// Custom queries for PACE workflow
customQueryItems.push({
  queryId: constants.VIEW_DOCUMENT_QUERY_ID,
  query: constants.VIEW_DOCUMENT_QUERY,
  // API Reference: Uses Statements.List API via /api/list
  // See: /api/schema/list for request/response format
});
```

When running the SDLC pipeline on this script, hyperlinks will be automatically injected into phase output for any recognized parameters.

## Configuration

### API Base URL

By default, the API registry looks for the wrapper at `http://localhost:3000`. To change this:

Edit `src/context/apiRegistry.ts`:
```typescript
const apiBaseUrl = "http://localhost:3000"; // Change this
const apiRegistry = new ApiRegistry(apiBaseUrl);
```

### Enabling Offline Mode

If the API service is unavailable, the API registry falls back to built-in operation definitions. This allows the SDLC pipeline to run without the wrapper, though Swagger UI features will be limited.

## Troubleshooting

### Wrapper won't start
- Ensure Node.js 14+ is installed
- Check if port 3000 is in use: `lsof -i :3000` (macOS/Linux) or `netstat -ano | findstr :3000` (Windows)
- Install dependencies: `cd api-wrapper && npm install`

### SOAP backend unreachable
- Verify the backend URL: `https://directaccess.ncpsolutions.com:8443/AvailableImages/Statements.svc`
- Check network connectivity and firewall rules
- The wrapper will log errors on first request if backend is unavailable

### Links not appearing in webview
- Confirm API registry is initialized: check browser console for `[ApiRegistry] Initialized...`
- Verify phase output contains recognized parameter names (clientId, userId, token, etc.)
- Check that `apiRegistry.scanAndLinkify()` is called in orchestrator (see `src/pipeline/orchestrator.ts`)

### Swagger UI not loading
- Ensure wrapper is running: `curl http://localhost:3000/swagger.json`
- Verify `/swagger.json` returns valid JSON
- Check browser console for CORS or fetch errors

## Next Steps

1. **Build the extension:** `npm run build`
2. **Start the wrapper:** `npm run api:serve` (in another terminal)
3. **Open SDLC Assistant:** Run `sdlc.openPanel` in VS Code
4. **Run a pipeline:** Create a run request; observe links in output
5. **Inspect Swagger:** Click links or use the Swagger UI toolbar button
