// Loads and parses installed agent persona definitions from .copilot/agents.
// Purpose: read every agent markdown file, split YAML frontmatter from markdown body,
//   and expose a typed record the orchestrator uses to build phase prompts.
// Inputs: workspaceRoot (string) — used as a fallback location after the user home dir.
// Outputs: Promise<Record<agentName, AgentDefinition>>.
// Typical response: { 'dev': { name: 'dev', description: '...', tools: [...], body: '...' }, ... }

import * as fs from "fs/promises";
import * as os from "os";
import * as path from "path";

export interface AgentDefinition {
  name: string;
  description: string;
  argumentHint?: string;
  tools: string[];
  model?: string;
  body: string;
  filePath: string;
}

export async function loadAgents(workspaceRoot: string): Promise<Record<string, AgentDefinition>> {
  // Agents are assumed pre-installed in .copilot/agents. Home is the default install
  // location; a workspace-local .copilot/agents may override individual agents.
  const dirs = [
    path.join(os.homedir(), ".copilot", "agents"),
    path.join(workspaceRoot, ".copilot", "agents")
  ];
  const out: Record<string, AgentDefinition> = {};
  for (const dir of dirs) {
    let entries: string[] = [];
    try {
      entries = await fs.readdir(dir);
    } catch {
      continue;
    }
    for (const entry of entries) {
      if (!entry.endsWith(".md")) continue;
      const full = path.join(dir, entry);
      let raw: string;
      try {
        raw = await fs.readFile(full, "utf8");
      } catch {
        continue;
      }
      const def = parseAgentFile(raw, full);
      if (def) out[def.name] = def; // workspace dir is read last, so it overrides home
    }
  }
  return out;
}

function parseAgentFile(raw: string, filePath: string): AgentDefinition | null {
  const m = raw.match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n([\s\S]*)$/);
  if (!m) return null;
  const fm = parseFrontmatter(m[1]);
  const fallbackName = path.basename(filePath).replace(/\.agent\.md$/i, "").replace(/\.md$/i, "");
  const name = String(fm.name ?? fallbackName);
  const description = String(fm.description ?? "");
  const argumentHint = fm["argument-hint"] ? String(fm["argument-hint"]) : undefined;
  const toolsField = fm.tools;
  let tools: string[] = [];
  if (Array.isArray(toolsField)) tools = toolsField.map(String);
  else if (typeof toolsField === "string") tools = parseInlineArray(toolsField);
  const model = fm.model ? String(fm.model) : undefined;
  return { name, description, argumentHint, tools, model, body: m[2].trim(), filePath };
}

// Minimal YAML frontmatter parser — supports `key: value`, quoted strings, and inline JSON-ish arrays.
function parseFrontmatter(text: string): Record<string, unknown> {
  const result: Record<string, unknown> = {};
  for (const lineRaw of text.split(/\r?\n/)) {
    const line = lineRaw.trimEnd();
    if (!line || line.startsWith("#")) continue;
    const idx = line.indexOf(":");
    if (idx < 0) continue;
    const key = line.slice(0, idx).trim();
    let value: string = line.slice(idx + 1).trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1);
      result[key] = value;
    } else if (value.startsWith("[") && value.endsWith("]")) {
      result[key] = parseInlineArray(value);
    } else {
      result[key] = value;
    }
  }
  return result;
}

function parseInlineArray(value: string): string[] {
  const inner = value.replace(/^\[/, "").replace(/\]$/, "");
  if (!inner.trim()) return [];
  return inner
    .split(",")
    .map((s) => s.trim().replace(/^['"]|['"]$/g, ""))
    .filter(Boolean);
}
