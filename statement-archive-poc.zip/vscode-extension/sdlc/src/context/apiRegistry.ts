// API Registry for Statements Service integration.
// Purpose: Manages API catalog, tracks WSDL operation schemas, and provides linkification utilities
//   to inject hyperlinks into phase output for recognized parameters.
// Inputs: Swagger spec loaded from disk or fetched from http://localhost:3000/swagger.json.
// Outputs: API endpoints, schemas, parameter mappings, and hyperlink markdown.
// Typical response: links like "[clientId→API](/swagger/authenticate)" or null if parameter not recognized.

export interface ApiOperation {
  name: string;
  method: "get" | "post" | "put" | "delete";
  path: string;
  description: string;
  parameters: string[];
}

export interface ApiSchema {
  operation: string;
  requestSchema?: Record<string, unknown>;
  responseSchema?: Record<string, unknown>;
}

export class ApiRegistry {
  private apiBaseUrl: string;
  private operations: Map<string, ApiOperation> = new Map();
  private schemas: Map<string, ApiSchema> = new Map();
  private parameterToOperation: Map<string, string> = new Map();
  private swaggerSpec: Record<string, unknown> | null = null;
  private initialized: boolean = false;

  constructor(apiBaseUrl: string = "http://localhost:3000") {
    this.apiBaseUrl = apiBaseUrl;
  }

  /**
   * Initialize API registry by fetching Swagger spec from the wrapper service.
   * Purpose: Load all operation definitions and parameter mappings.
   * Inputs: none.
   * Outputs: Promise resolves when spec is loaded and indexed.
   * Typical response: console logs registration of 4 operations.
   */
  async initialize(): Promise<void> {
    try {
      const response = await fetch(`${this.apiBaseUrl}/swagger.json`);
      if (!response.ok) {
        throw new Error(`Failed to fetch Swagger spec: ${response.statusText}`);
      }
      this.swaggerSpec = (await response.json()) as Record<string, unknown>;
      this.indexOperations();
      this.indexSchemas();
      this.buildParameterMapping();
      this.initialized = true;
      console.log("[ApiRegistry] Initialized with", this.operations.size, "operations");
    } catch (err) {
      console.warn("[ApiRegistry] Failed to initialize from API service:", (err as Error).message);
      this.initializeFromDefaults();
      this.initialized = true;
    }
  }

  /**
   * Index operations from Swagger spec.
   * Purpose: Extract all API operations and their metadata.
   * Inputs: this.swaggerSpec (must be loaded first).
   * Outputs: Populates this.operations Map.
   * Typical response: none (side effect).
   */
  private indexOperations(): void {
    if (!this.swaggerSpec || typeof this.swaggerSpec !== "object") return;

    const paths = (this.swaggerSpec as Record<string, unknown>)["paths"] as Record<string, Record<string, unknown>> | undefined;
    if (!paths) return;

    Object.entries(paths).forEach(([path, pathItem]) => {
      if (typeof pathItem !== "object" || pathItem === null) return;

      const pathItemObj = pathItem as Record<string, Record<string, unknown>>;
      Object.entries(pathItemObj).forEach(([method, operation]) => {
        if (typeof operation !== "object" || operation === null || method === "parameters") return;

        const operationObj = operation as Record<string, unknown>;
        const operationId = (operationObj["operationId"] as string) || path;
        const description = (operationObj["summary"] as string) || "";
        const parameters = this.extractParameters(operationObj);

        this.operations.set(operationId, {
          name: operationId,
          method: method as "get" | "post" | "put" | "delete",
          path,
          description,
          parameters
        });
      });
    });
  }

  /**
   * Extract parameter names from operation definition.
   * Purpose: Identify which parameters this operation accepts.
   * Inputs: operation object (OpenAPI operation).
   * Outputs: Array of parameter names.
   * Typical response: ["token", "documentIds"] or similar.
   */
  private extractParameters(operation: Record<string, unknown>): string[] {
    const parameters: string[] = [];

    // Extract from requestBody
    const requestBody = operation["requestBody"] as Record<string, unknown> | undefined;
    if (requestBody && requestBody["content"]) {
      const content = requestBody["content"] as Record<string, unknown>;
      const jsonContent = content["application/json"] as Record<string, unknown> | undefined;
      if (jsonContent && jsonContent["schema"]) {
        const schemaRef = (jsonContent["schema"] as Record<string, unknown>)["$ref"] as string | undefined;
        if (schemaRef) {
          const refName = schemaRef.split("/").pop();
          if (refName) {
            parameters.push(refName);
          }
        }
      }
    }

    // Extract from query/path parameters
    const pathParams = operation["parameters"] as Array<Record<string, unknown>> | undefined;
    if (Array.isArray(pathParams)) {
      pathParams.forEach((param) => {
        const paramName = param["name"] as string | undefined;
        if (paramName) {
          parameters.push(paramName);
        }
      });
    }

    return parameters;
  }

  /**
   * Index schemas from Swagger spec.
   * Purpose: Cache all request/response schemas for operations.
   * Inputs: this.swaggerSpec (must be loaded first).
   * Outputs: Populates this.schemas Map.
   * Typical response: none (side effect).
   */
  private indexSchemas(): void {
    if (!this.swaggerSpec) return;

    const components = (this.swaggerSpec as Record<string, unknown>)["components"] as Record<string, unknown> | undefined;
    const schemas = components?.["schemas"] as Record<string, unknown> | undefined;

    if (!schemas) return;

    const operations = ["authenticate", "list", "listDynamic", "createMultidocPDF"];
    operations.forEach((op) => {
      const reqKey = op.charAt(0).toUpperCase() + op.slice(1) + "Request";
      const resKey = op.charAt(0).toUpperCase() + op.slice(1) + "Response";

      this.schemas.set(op, {
        operation: op,
        requestSchema: (schemas[reqKey] as Record<string, unknown>) || undefined,
        responseSchema: (schemas[resKey] as Record<string, unknown>) || undefined
      });
    });
  }

  /**
   * Build parameter-to-operation mapping.
   * Purpose: Enable lookup of which operation uses a given parameter.
   * Inputs: this.operations (must be indexed first).
   * Outputs: Populates this.parameterToOperation Map.
   * Typical response: none (side effect).
   */
  private buildParameterMapping(): void {
    // Manual mapping based on WSDL: map known parameters to their operations
    const mapping: Record<string, string> = {
      clientId: "authenticate",
      userId: "authenticate",
      password: "authenticate",
      account: "authenticate",
      startDate: "authenticate",
      endDate: "authenticate",
      product: "authenticate",
      hash: "authenticate",
      token: "list",
      documentIds: "createMultidocPDF",
      filters: "listDynamic"
    };

    Object.entries(mapping).forEach(([param, op]) => {
      this.parameterToOperation.set(param, op);
      this.parameterToOperation.set(param.toLowerCase(), op);
    });

    console.log("[ApiRegistry] Parameter mapping built:", this.parameterToOperation.size, "mappings");
  }

  /**
   * Initialize from defaults (offline mode).
   * Purpose: Provide built-in operation definitions when API service is unavailable.
   * Inputs: none.
   * Outputs: Populates this.operations and this.schemas.
   * Typical response: none (side effect).
   */
  private initializeFromDefaults(): void {
    const defaultOps: ApiOperation[] = [
      {
        name: "authenticate",
        method: "post",
        path: "/api/authenticate",
        description: "Authenticate user and get token",
        parameters: ["clientId", "userId", "password", "account", "startDate", "endDate", "product"]
      },
      {
        name: "list",
        method: "get",
        path: "/api/list",
        description: "List available statements",
        parameters: ["token"]
      },
      {
        name: "listDynamic",
        method: "post",
        path: "/api/list-dynamic",
        description: "List statements with dynamic filters",
        parameters: ["token", "filters"]
      },
      {
        name: "createMultidocPDF",
        method: "post",
        path: "/api/create-pdf",
        description: "Create multi-document PDF",
        parameters: ["token", "documentIds"]
      }
    ];

    defaultOps.forEach((op) => {
      this.operations.set(op.name, op);
    });

    this.buildParameterMapping();
    console.log("[ApiRegistry] Initialized with default operations (offline mode)");
  }

  /**
   * Get all registered API operations.
   * Purpose: Retrieve the full list of available operations.
   * Inputs: none.
   * Outputs: Array of ApiOperation objects.
   * Typical response: [{name: "authenticate", ...}, {name: "list", ...}, ...].
   */
  getOperations(): ApiOperation[] {
    return Array.from(this.operations.values());
  }

  /**
   * Get schema for a specific operation.
   * Purpose: Retrieve request/response schemas for schema inspection.
   * Inputs: operationName (e.g., "authenticate").
   * Outputs: ApiSchema object or null if not found.
   * Typical response: { operation: "authenticate", requestSchema: {...}, responseSchema: {...} }.
   */
  getSchema(operationName: string): ApiSchema | null {
    return this.schemas.get(operationName) || null;
  }

  /**
   * Find operation by parameter name.
   * Purpose: Identify which API operation uses a given parameter.
   * Inputs: parameterName (e.g., "clientId").
   * Outputs: Operation name or null if not found.
   * Typical response: "authenticate" or null.
   */
  findOperationByParameter(parameterName: string): string | null {
    return this.parameterToOperation.get(parameterName) || this.parameterToOperation.get(parameterName.toLowerCase()) || null;
  }

  /**
   * Create a hyperlink for a recognized parameter.
   * Purpose: Generate markdown link to Swagger UI for a parameter.
   * Inputs: text (display text), parameterName (e.g., "clientId").
   * Outputs: Markdown link or plain text if parameter not recognized.
   * Typical response: "[clientId→API](/swagger/authenticate)" or "clientId" (no link).
   */
  linkifyParameter(text: string, parameterName: string): string {
    const operation = this.findOperationByParameter(parameterName);
    if (!operation) {
      return text; // No hyperlink if parameter not recognized
    }
    return `[${text}→API](/swagger/${operation})`;
  }

  /**
   * Scan text for recognized parameters and inject hyperlinks.
   * Purpose: Automatically linkify data field references in output text.
   * Inputs: text (output content).
   * Outputs: Text with embedded hyperlinks for recognized parameters.
   * Typical response: "User authenticated with [clientId→API](/swagger/authenticate)" or unchanged if no matches.
   */
  scanAndLinkify(text: string): string {
    let result = text;
    const paramRegex = /\b(clientId|userId|password|account|startDate|endDate|product|token|documentIds|filters)\b/gi;

    result = result.replace(paramRegex, (match) => {
      const operation = this.findOperationByParameter(match);
      if (operation) {
        return `[${match}→API](/swagger/${operation})`;
      }
      return match;
    });

    return result;
  }

  /**
   * Check if registry is initialized and ready.
   * Purpose: Verify initialization status for healthcheck.
   * Inputs: none.
   * Outputs: boolean.
   * Typical response: true or false.
   */
  isInitialized(): boolean {
    return this.initialized;
  }

  /**
   * Get registry status for debugging.
   * Purpose: Return diagnostics on registry state.
   * Inputs: none.
   * Outputs: Object with counts and status.
   * Typical response: { initialized: true, operationCount: 4, schemaCount: 4, parameterMappings: 13 }.
   */
  getStatus(): Record<string, unknown> {
    return {
      initialized: this.initialized,
      operationCount: this.operations.size,
      schemaCount: this.schemas.size,
      parameterMappings: this.parameterToOperation.size,
      apiBaseUrl: this.apiBaseUrl,
      operations: Array.from(this.operations.keys())
    };
  }
}

// Singleton instance
export const apiRegistry = new ApiRegistry();
