// Drives the SDLC pipeline against a single Copilot session.
// Purpose: walk PHASES in order, build per-phase prompts from agent persona bodies,
//   persist transcripts, parse code-review verdicts, and loop dev<->codereview as needed.
// Inputs: SessionManager, agent definitions, workspaceRoot, run request from the panel.
// Outputs: emits phase updates via callbacks; returns when the run completes or aborts.
// Typical response: callbacks receive PhaseSummary objects and event envelopes; on completion
//   a manifest.json plus per-phase markdown/json are written under sdlc/.sdlc-runs/<runId>/.

import * as fs from "fs/promises";
import * as path from "path";
import type { AgentDefinition } from "../agents/agentLoader";
import { PHASES, type PhaseDefinition, shouldGate, type ConfirmMode } from "./phases";
import type { SessionManager, SessionEventEnvelope } from "../copilot/sessionManager";
import type { PhaseStatus, PhaseSummary } from "../webview/protocol";
import { apiRegistry } from "../context/apiRegistry";

export interface RunRequest {
  prompt: string;
  model: string;
  maxIterations: number;
  confirmMode: ConfirmMode;
  startFromPhase?: string;
  /** Optional markdown context loaded from user-specified GitHub repositories. */
  repositoryContext?: string;
}

export interface OrchestratorCallbacks {
  onPhaseUpdate: (phase: PhaseSummary) => void;
  onEvent: (env: SessionEventEnvelope) => void;
  awaitConfirmation: (phaseId: string, summary: string) => Promise<{ confirmed: boolean; extraInstructions?: string }>;
  onRunState: (state: "running" | "paused" | "aborted" | "finished" | "failed") => void;
}

interface PhaseRecord {
  def: PhaseDefinition;
  status: PhaseStatus;
  iteration: number;
  startedAt?: number;
  endedAt?: number;
  summaryText?: string;
  transcriptPath?: string;
  filesWritten: Set<string>;
  approxStartTokens: number;
  approxEndTokens: number;
}

export class Orchestrator {
  private records = new Map<string, PhaseRecord>();
  private abortRequested = false;
  private runId: string = "";
  private runDir: string = "";

  constructor(
    private readonly session: SessionManager,
    private readonly agents: Record<string, AgentDefinition>,
    private readonly workspaceRoot: string,
    private readonly cb: OrchestratorCallbacks
  ) {}

  /** Build initial phase summaries (all pending) for the UI to render. */
  buildInitialSummaries(): PhaseSummary[] {
    return PHASES.map((p) => ({
      id: p.id,
      agentName: p.agentName,
      title: p.title,
      status: "pending" as PhaseStatus,
      dependsOn: p.dependsOn
    }));
  }

  requestAbort() { this.abortRequested = true; }

  async run(req: RunRequest): Promise<void> {
    this.abortRequested = false;
    this.runId = `run-${new Date().toISOString().replace(/[:.]/g, "-")}`;
    this.runDir = path.join(this.workspaceRoot, "sdlc", ".sdlc-runs", this.runId);
    await fs.mkdir(this.runDir, { recursive: true });

    // Initialize API registry for link injection
    if (!apiRegistry.isInitialized()) {
      await apiRegistry.initialize().catch((err) => {
        console.warn("[Orchestrator] Failed to initialize API registry:", err.message);
      });
    }

    await this.session.prepare(req.model);
    this.cb.onRunState("running");

    const startedAt = Date.now();
    let extraForNext: string | undefined;
    let encounteredError = false;
    for (const def of PHASES) {
      if (this.abortRequested) break;
      if (req.startFromPhase && this.indexOf(def.id) < this.indexOf(req.startFromPhase)) {
        this.upsertRecord(def, { status: "skipped" });
        this.emitPhase(def.id);
        continue;
      }
      if (def.conditionKey === "docs-raw-exists") {
        const exists = await this.dirHasFiles(path.join(this.workspaceRoot, "docs", "raw"));
        if (!exists) {
          this.upsertRecord(def, { status: "skipped" });
          this.emitPhase(def.id);
          continue;
        }
      }
      const agent = this.agents[def.agentName];
      if (!agent) {
        this.upsertRecord(def, { status: "failed", summaryText: `Agent '${def.agentName}' not found in .copilot/agents` });
        this.emitPhase(def.id);
        encounteredError = true;
        continue;
      }

      // Run the phase, possibly iterating with the partner phase.
      const ok = await this.runPhaseWithIteration(def, agent, req, extraForNext);
      extraForNext = undefined;
      if (!ok) { encounteredError = true; break; }

      if (shouldGate(def, req.confirmMode) && this.indexOf(def.id) < PHASES.length - 1) {
        const rec = this.records.get(def.id)!;
        this.cb.onRunState("paused");
        this.markStatus(def.id, "awaiting-confirmation");
        const decision = await this.cb.awaitConfirmation(def.id, rec.summaryText ?? "");
        if (!decision.confirmed) {
          this.markStatus(def.id, "failed");
          this.cb.onRunState("aborted");
          await this.writeManifest(req, startedAt);
          return;
        }
        this.markStatus(def.id, "passed");
        extraForNext = decision.extraInstructions;
        this.cb.onRunState("running");
      }
    }

    await this.writeManifest(req, startedAt);
    this.cb.onRunState(this.abortRequested ? "aborted" : encounteredError ? "failed" : "finished");
  }

  private indexOf(id: string): number {
    return PHASES.findIndex((p) => p.id === id);
  }

  private async runPhaseWithIteration(def: PhaseDefinition, agent: AgentDefinition, req: RunRequest, extraInstructions: string | undefined): Promise<boolean> {
    const maxIter = def.parseVerdict ? req.maxIterations : 1;
    let iteration = 1;
    while (iteration <= maxIter) {
      if (this.abortRequested) return false;
      const rec = this.upsertRecord(def, { status: "running", iteration, startedAt: Date.now() });
      rec.approxStartTokens = this.session.getTokenTotals().total;
      this.emitPhase(def.id);

      const prompt = this.buildPrompt(def, agent, req, iteration, extraInstructions);
      let assistantText = "";
      try {
        assistantText = await this.session.sendAndWait(def.id, prompt);
      } catch (err: any) {
        this.markStatus(def.id, "failed");
        rec.summaryText = `Error: ${err?.message ?? String(err)}`;
        this.emitPhase(def.id);
        return false;
      }

      rec.endedAt = Date.now();
      rec.approxEndTokens = this.session.getTokenTotals().total;
      rec.summaryText = this.summarize(assistantText);
      // Inject API hyperlinks into summary if registry is ready
      if (apiRegistry.isInitialized()) {
        rec.summaryText = apiRegistry.scanAndLinkify(rec.summaryText);
      }
      rec.transcriptPath = await this.persistTranscript(def, iteration, prompt, assistantText);

      if (def.parseVerdict) {
        const verdict = this.parseVerdict(assistantText);
        if (verdict === "PASS") {
          this.markStatus(def.id, "passed");
          this.emitPhase(def.id);
          return true;
        }
        if (iteration >= maxIter) {
          // Reached cap; mark passed-with-cap and continue (user can re-run).
          this.markStatus(def.id, "passed");
          this.emitPhase(def.id);
          return true;
        }
        // Re-run partner phase (dev) with findings, then loop back to this review phase.
        if (def.iterationPartner) {
          const partnerDef = PHASES.find((p) => p.id === def.iterationPartner);
          const partnerAgent = partnerDef ? this.agents[partnerDef.agentName] : undefined;
          if (partnerDef && partnerAgent) {
            const partnerRec = this.upsertRecord(partnerDef, { status: "running", iteration: iteration + 1, startedAt: Date.now() });
            partnerRec.approxStartTokens = this.session.getTokenTotals().total;
            this.emitPhase(partnerDef.id);
            const fixPrompt = this.buildFixPrompt(partnerDef, partnerAgent, assistantText, iteration);
            try {
              const fixText = await this.session.sendAndWait(partnerDef.id, fixPrompt);
              partnerRec.endedAt = Date.now();
              partnerRec.approxEndTokens = this.session.getTokenTotals().total;
              partnerRec.summaryText = this.summarize(fixText);
              partnerRec.transcriptPath = await this.persistTranscript(partnerDef, iteration + 1, fixPrompt, fixText);
              this.markStatus(partnerDef.id, "passed");
              this.emitPhase(partnerDef.id);
            } catch (err: any) {
              this.markStatus(partnerDef.id, "failed");
              partnerRec.summaryText = `Error: ${err?.message ?? String(err)}`;
              this.emitPhase(partnerDef.id);
              return false;
            }
          }
        }
        iteration += 1;
        continue;
      }

      this.markStatus(def.id, "passed");
      this.emitPhase(def.id);
      return true;
    }
    return true;
  }

  private buildPrompt(def: PhaseDefinition, agent: AgentDefinition, req: RunRequest, iteration: number, extraInstructions?: string): string {
    const priorSummaries = PHASES
      .filter((p) => p.id !== def.id && this.indexOf(p.id) < this.indexOf(def.id))
      .map((p) => {
        const r = this.records.get(p.id);
        if (!r || r.status === "skipped" || r.status === "pending") return null;
        return `### ${p.title} (${p.agentName}) — ${r.status}\n${r.summaryText ?? ""}`;
      })
      .filter(Boolean)
      .join("\n\n");

    const header = [
      `# SDLC Pipeline — ${def.title}`,
      `Phase id: ${def.id}`,
      `Iteration: ${iteration}`,
      `You are now acting as the **${agent.name}** agent. Follow the instructions in the AGENT PERSONA section verbatim. Use your normal tool-using agentic loop to read context, write files into the workspace, and produce the artifacts the persona requires.`,
      ``,
      `## User request`,
      req.prompt,
      ``,
      extraInstructions ? `## Additional instructions from user gate\n${extraInstructions}\n` : "",
      req.repositoryContext ? `${req.repositoryContext}\n` : "",
      priorSummaries ? `## Prior phase summaries\n${priorSummaries}\n` : "",
      `## AGENT PERSONA`,
      agent.body
    ].filter(Boolean).join("\n");
    return header;
  }

  private buildFixPrompt(devDef: PhaseDefinition, devAgent: AgentDefinition, reviewText: string, iteration: number): string {
    return [
      `# SDLC Pipeline — ${devDef.title} (remediation iteration ${iteration})`,
      `You are again acting as the **${devAgent.name}** agent. The code review below flagged issues with your prior output. Address every Blocker and Major, update the affected files in the workspace, and produce a brief summary of what changed.`,
      ``,
      `## Code review findings`,
      reviewText,
      ``,
      `## AGENT PERSONA`,
      devAgent.body
    ].join("\n");
  }

  private parseVerdict(text: string): "PASS" | "FAIL" {
    const m = text.match(/PR\s+Readiness[^\n]*?(PASS|FAIL)/i);
    if (m) return m[1].toUpperCase() === "PASS" ? "PASS" : "FAIL";
    // Fallback: if the body contains a standalone 'FAIL' verdict near 'Blockers', treat as FAIL.
    if (/\bFAIL\b/.test(text) && /Blockers/i.test(text)) return "FAIL";
    return "PASS";
  }

  private summarize(text: string): string {
    const trimmed = text.trim();
    if (trimmed.length <= 1200) return trimmed;
    return trimmed.slice(0, 1200) + "\n\n…(truncated; see transcript)";
  }

  private async persistTranscript(def: PhaseDefinition, iteration: number, prompt: string, assistant: string): Promise<string> {
    const base = `${def.id}.iter${iteration}`;
    const mdPath = path.join(this.runDir, `${base}.md`);
    const jsonPath = path.join(this.runDir, `${base}.json`);
    const md = [
      `# ${def.title} — iteration ${iteration}`,
      ``,
      `## Prompt`,
      "",
      "```",
      prompt,
      "```",
      "",
      `## Assistant`,
      "",
      assistant
    ].join("\n");
    await fs.writeFile(mdPath, md, "utf8");
    await fs.writeFile(jsonPath, JSON.stringify({ phaseId: def.id, iteration, prompt, assistant }, null, 2), "utf8");
    return mdPath;
  }

  private async writeManifest(req: RunRequest, startedAt: number) {
    const manifest = {
      runId: this.runId,
      model: req.model,
      prompt: req.prompt,
      startedAt: new Date(startedAt).toISOString(),
      endedAt: new Date().toISOString(),
      tokens: this.session.getTokenTotals(),
      phases: Array.from(this.records.values()).map((r) => ({
        id: r.def.id,
        agentName: r.def.agentName,
        title: r.def.title,
        status: r.status,
        iteration: r.iteration,
        startedAt: r.startedAt,
        endedAt: r.endedAt,
        elapsedMs: r.startedAt && r.endedAt ? r.endedAt - r.startedAt : undefined,
        approxPhaseTokens: Math.max(0, r.approxEndTokens - r.approxStartTokens),
        transcriptPath: r.transcriptPath
      }))
    };
    await fs.writeFile(path.join(this.runDir, "manifest.json"), JSON.stringify(manifest, null, 2), "utf8");
  }

  private upsertRecord(def: PhaseDefinition, patch: Partial<PhaseRecord>): PhaseRecord {
    const existing = this.records.get(def.id);
    const rec: PhaseRecord = existing ?? {
      def,
      status: "pending",
      iteration: 1,
      filesWritten: new Set<string>(),
      approxStartTokens: 0,
      approxEndTokens: 0
    };
    Object.assign(rec, patch);
    rec.def = def;
    this.records.set(def.id, rec);
    return rec;
  }

  private markStatus(id: string, status: PhaseStatus) {
    const rec = this.records.get(id);
    if (rec) rec.status = status;
  }

  private emitPhase(id: string) {
    const rec = this.records.get(id);
    if (!rec) return;
    const tokens = Math.max(0, rec.approxEndTokens - rec.approxStartTokens);
    this.cb.onPhaseUpdate({
      id: rec.def.id,
      agentName: rec.def.agentName,
      title: rec.def.title,
      status: rec.status,
      iteration: rec.iteration,
      elapsedMs: rec.startedAt && rec.endedAt ? rec.endedAt - rec.startedAt : undefined,
      approxTokens: tokens,
      summary: rec.summaryText,
      transcriptPath: rec.transcriptPath,
      filesWritten: Array.from(rec.filesWritten),
      dependsOn: rec.def.dependsOn
    });
  }

  private async dirHasFiles(dir: string): Promise<boolean> {
    try {
      const entries = await fs.readdir(dir);
      return entries.length > 0;
    } catch {
      return false;
    }
  }
}
