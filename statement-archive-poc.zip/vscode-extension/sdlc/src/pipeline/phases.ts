// Declares the SDLC pipeline phase graph.
// Purpose: enumerate phases in execution order with dependencies, gates,
//   and the codereview <-> dev iteration partner relationship.
// Inputs: none.
// Outputs: PHASES (array) and helper accessors.
// Typical response: orchestrator iterates PHASES and resolves each agent body
//   from the agentLoader to build the prompt for that phase.

export type ConfirmMode = "never" | "high-impact-only" | "always";

export interface PhaseDefinition {
  id: string;
  title: string;
  agentName: string;
  dependsOn: string[];
  /** Skip this phase if `condition(ctx)` returns false. */
  conditionKey?: "docs-raw-exists";
  /** When true, gate after this phase under 'high-impact-only' confirmation mode. */
  highImpact?: boolean;
  /** If set, after this phase completes the orchestrator may loop back to `iterationPartner`
   *  while a verdict is FAIL, capped by maxIterations. */
  iterationPartner?: string;
  /** Marker used by orchestrator to look for PASS/FAIL in assistant message. */
  parseVerdict?: boolean;
}

export const PHASES: PhaseDefinition[] = [
  {
    id: "phase-0-doc-processor",
    title: "Document Processing",
    agentName: "doc-processor",
    dependsOn: [],
    conditionKey: "docs-raw-exists"
  },
  {
    id: "phase-1-ba",
    title: "Business Analysis",
    agentName: "ba-analyst",
    dependsOn: ["phase-0-doc-processor"]
  },
  {
    id: "phase-2-architecture",
    title: "Architecture Design",
    agentName: "architect",
    dependsOn: ["phase-1-ba"],
    highImpact: true
  },
  {
    id: "phase-3-dev",
    title: "Development",
    agentName: "dev",
    dependsOn: ["phase-2-architecture"]
  },
  {
    id: "phase-3-5-codereview",
    title: "Code Review",
    agentName: "codereview",
    dependsOn: ["phase-3-dev"],
    iterationPartner: "phase-3-dev",
    parseVerdict: true,
    highImpact: true
  },
  {
    id: "phase-4-security",
    title: "Security Review",
    agentName: "security",
    dependsOn: ["phase-3-5-codereview"]
  },
  {
    id: "phase-4-performance",
    title: "Performance Review",
    agentName: "performance",
    dependsOn: ["phase-4-security"]
  },
  {
    id: "phase-5-qa",
    title: "Quality Assurance",
    agentName: "qa",
    dependsOn: ["phase-4-performance"]
  },
  {
    id: "phase-6-devops",
    title: "DevOps & Deployment",
    agentName: "devops",
    dependsOn: ["phase-5-qa"]
  }
];

export function shouldGate(phase: PhaseDefinition, mode: ConfirmMode): boolean {
  if (mode === "never") return false;
  if (mode === "always") return true;
  return !!phase.highImpact;
}
