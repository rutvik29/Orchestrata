// Wraps @github/copilot-sdk into a Copilot CLI client with one fresh session per phase.
// Purpose: resolve the platform-appropriate Copilot CLI binary, manage a CopilotClient,
//   create a fresh CopilotSession per phase, stream events to a sink, and track token usage.
// Inputs: workspaceRoot (string), optional cliPath, event sink, bridge callbacks for permission/userInput.
// Outputs: SessionManager instance exposing start/prepare/sendAndWait/dispose/listModels.
// Typical response: events flow to the sink as { kind, phaseId, ... }; sendAndWait resolves
//   with the final assistant message text after the session becomes idle.

import {
  CopilotClient,
  approveAll,
  RuntimeConnection,
  type PermissionRequest,
  type PermissionRequestResult,
  type CopilotSession,
  type ModelInfo as SdkModelInfo
} from "@github/copilot-sdk";
import * as path from "path";
import * as fs from "fs";
import * as os from "os";

// True when running on Windows; selects the native binary name and well-known locations.
const IS_WINDOWS = process.platform === "win32";
// Native Copilot CLI executable name for the current platform.
const COPILOT_CLI_BINARY = IS_WINDOWS ? "copilot.exe" : "copilot";

// Checks whether a path exists and points to a regular file (follows symlinks).
// Inputs: candidate path string. Output: boolean.
// Typical response: true for an existing copilot.exe, false for a missing path or a directory.
function isExistingFile(candidate: string): boolean {
  try {
    return fs.statSync(candidate).isFile();
  } catch {
    return false;
  }
}

// Lists platform-specific well-known install locations for the standalone Copilot CLI.
// Inputs: none (reads environment variables and the home directory). Output: array of absolute candidate paths.
// Typical response (Windows): ["C:\\Users\\me\\AppData\\Local\\GitHubCopilotCLI\\copilot.exe", ...].
function wellKnownCliBinaries(): string[] {
  const home = os.homedir();
  if (IS_WINDOWS) {
    const localAppData = process.env.LOCALAPPDATA || path.join(home, "AppData", "Local");
    const programFiles = process.env.ProgramFiles || "C:\\Program Files";
    const programFilesX86 = process.env["ProgramFiles(x86)"] || "C:\\Program Files (x86)";
    return [
      path.join(localAppData, "GitHubCopilotCLI", "copilot.exe"),
      path.join(programFiles, "GitHubCopilotCLI", "copilot.exe"),
      path.join(programFilesX86, "GitHubCopilotCLI", "copilot.exe")
    ];
  }
  return [
    "/usr/local/bin/copilot",
    "/opt/homebrew/bin/copilot",
    "/usr/bin/copilot",
    path.join(home, ".local", "bin", "copilot"),
    path.join(home, ".copilot", "bin", "copilot")
  ];
}

// Searches the PATH for the native Copilot CLI binary, preferring a real executable over shell shims.
// Inputs: none (reads process.env.PATH). Output: absolute path string or undefined.
// Typical response: "/usr/local/bin/copilot" or "C:\\Users\\me\\AppData\\Local\\GitHubCopilotCLI\\copilot.exe".
function findCopilotOnPath(): string | undefined {
  const rawPath = process.env.PATH || process.env.Path || "";
  const dirs = rawPath.split(path.delimiter).map((d) => d.trim()).filter(Boolean);
  for (const dir of dirs) {
    const candidate = path.join(dir, COPILOT_CLI_BINARY);
    if (isExistingFile(candidate)) return candidate;
  }
  return undefined;
}

// Resolves the Copilot CLI executable in a platform-agnostic way (no bundled binary).
// Inputs: optional configuredPath (from the sdlc.copilot.cliPath setting).
// Output: absolute path to a spawnable native CLI binary; throws a descriptive error when none is found.
// Resolution order: configured setting -> COPILOT_CLI_PATH env -> well-known install dirs -> PATH.
// Typical response: "C:\\Users\\me\\AppData\\Local\\GitHubCopilotCLI\\copilot.exe".
function resolveCopilotCliPath(configuredPath?: string): string {
  const configured = (configuredPath ?? "").trim();
  if (configured) {
    if (isExistingFile(configured)) return configured;
    throw new Error(
      `The configured Copilot CLI path does not exist: ${configured}. ` +
      `Update the 'sdlc.copilot.cliPath' setting to the full path of the Copilot CLI executable.`
    );
  }

  const fromEnv = (process.env.COPILOT_CLI_PATH ?? "").trim();
  if (fromEnv) {
    if (isExistingFile(fromEnv)) return fromEnv;
    throw new Error(`COPILOT_CLI_PATH points to a non-existent file: ${fromEnv}.`);
  }

  for (const candidate of wellKnownCliBinaries()) {
    if (isExistingFile(candidate)) return candidate;
  }

  const onPath = findCopilotOnPath();
  if (onPath) return onPath;

  throw new Error(
    `GitHub Copilot CLI ('${COPILOT_CLI_BINARY}') was not found. Install the Copilot CLI ` +
    `(for example 'npm install -g @github/copilot' or the standalone installer), make sure it is on your PATH, ` +
    `or set the 'sdlc.copilot.cliPath' setting to the full path of the Copilot CLI executable.`
  );
}

export type SessionEventKind =
  | "message.delta"
  | "reasoning.delta"
  | "message.final"
  | "reasoning.final"
  | "tool.start"
  | "tool.complete"
  | "compaction.start"
  | "compaction.complete"
  | "idle"
  | "error";

export interface SessionEventEnvelope {
  kind: SessionEventKind;
  phaseId: string;
  payload?: any;
}

export interface TokenTotals {
  prompt: number;
  completion: number;
  cached: number;
  total: number;
}

export interface SessionManagerOptions {
  workspaceRoot: string;
  /** Optional explicit path to the Copilot CLI executable (sdlc.copilot.cliPath). Auto-detected when empty. */
  cliPath?: string;
  sink: (env: SessionEventEnvelope) => void;
  onTokens: (totals: TokenTotals) => void;
  onPermissionRequest: (req: PermissionRequest) => Promise<PermissionRequestResult>;
  onUserInputRequest: (req: { question: string; choices?: string[]; allowFreeform: boolean }) => Promise<{ answer: string; wasFreeform: boolean }>;
}

export class SessionManager {
  private client: CopilotClient | null = null;
  private currentSession: CopilotSession | null = null;
  private model: string = "";
  private currentPhaseId: string = "(unassigned)";
  private tokens: TokenTotals = { prompt: 0, completion: 0, cached: 0, total: 0 };
  private completionCharBuffer = 0;
  private promptCharBuffer = 0;
  private currentMessageBuffer = "";

  constructor(private readonly opts: SessionManagerOptions) {}

  // Start the underlying Copilot CLI runtime using a platform-resolved native binary.
  // Inputs: none (uses opts.cliPath / env / well-known dirs / PATH). Output: Promise<void>.
  // Typical response: resolves once the CLI process is connected; throws if no CLI is found. Safe to call repeatedly.
  async start(): Promise<void> {
    if (this.client) return;
    const cliPath = resolveCopilotCliPath(this.opts.cliPath);
    this.client = new CopilotClient({
      connection: RuntimeConnection.forStdio({ path: cliPath }),
      workingDirectory: this.opts.workspaceRoot
    });
    await this.client.start();
  }

  async listModels(): Promise<SdkModelInfo[]> {
    if (!this.client) await this.start();
    // The SDK's createSession accepts a model string; listModels is provided via session
    // capabilities or runtime introspection. We fall back to a minimal set if unavailable.
    try {
      // @ts-ignore - listModels surfaced at runtime per SDK README ('client.listModels()').
      const models = await (this.client as any).listModels?.();
      if (Array.isArray(models) && models.length) return models;
    } catch {
      // ignore and fall through to default
    }
    return [
      { id: "gpt-5", name: "gpt-5" } as any,
      { id: "claude-sonnet-4.5", name: "claude-sonnet-4.5" } as any
    ];
  }

  // Prepare for a run: ensure the CLI runtime is started and remember the model to use.
  // Inputs: model id string. Output: Promise<void>.
  // Typical response: resolves once the client is connected; each phase later gets its own fresh session.
  async prepare(model: string): Promise<void> {
    this.model = model;
    if (!this.client) await this.start();
  }

  // Create a fresh CopilotSession for a single phase using the prepared model.
  // Inputs: none (uses this.model). Output: a wired CopilotSession.
  // Typical response: a session whose events stream to the sink until it is disconnected.
  private async createPhaseSession(): Promise<CopilotSession> {
    if (!this.client) await this.start();
    const session = await this.client!.createSession({
      model: this.model,
      onPermissionRequest: async (req: PermissionRequest, invocation: { sessionId: string }): Promise<PermissionRequestResult> => {
        // Auto-approve tool permissions so the pipeline runs autonomously and does not stall
        // waiting on a modal for every shell/glob/file call. Genuine questions still prompt
        // through onUserInputRequest below.
        return approveAll(req, invocation);
      },
      onUserInputRequest: async (req: { question: string; choices?: string[]; allowFreeform?: boolean }, _invocation: { sessionId: string }) => {
        const r = await this.opts.onUserInputRequest({
          question: req.question,
          choices: req.choices,
          allowFreeform: req.allowFreeform ?? true
        });
        return r;
      },
      infiniteSessions: { enabled: true }
    } as any);

    this.wireEvents(session);
    return session;
  }

  private wireEvents(session: CopilotSession) {
    session.on("assistant.message_delta", (event: any) => {
      const delta: string = event?.data?.deltaContent ?? "";
      this.completionCharBuffer += delta.length;
      this.currentMessageBuffer += delta;
      this.recomputeApproxTokens();
      this.opts.sink({ kind: "message.delta", phaseId: this.currentPhaseId, payload: { delta } });
    });
    session.on("assistant.reasoning_delta", (event: any) => {
      const delta: string = event?.data?.deltaContent ?? "";
      this.completionCharBuffer += delta.length;
      this.recomputeApproxTokens();
      this.opts.sink({ kind: "reasoning.delta", phaseId: this.currentPhaseId, payload: { delta } });
    });
    session.on("assistant.message", (event: any) => {
      const content: string = event?.data?.content ?? "";
      if (content) this.currentMessageBuffer = content;
      this.opts.sink({ kind: "message.final", phaseId: this.currentPhaseId, payload: { content } });
    });
    session.on("assistant.reasoning", (event: any) => {
      this.opts.sink({ kind: "reasoning.final", phaseId: this.currentPhaseId, payload: { content: event?.data?.content ?? "" } });
    });
    session.on("tool.execution_start", (event: any) => {
      this.opts.sink({ kind: "tool.start", phaseId: this.currentPhaseId, payload: { toolName: event?.data?.toolName, args: event?.data?.toolArgs } });
    });
    session.on("tool.execution_complete", (event: any) => {
      this.opts.sink({ kind: "tool.complete", phaseId: this.currentPhaseId, payload: { toolName: event?.data?.toolName, result: event?.data?.result } });
    });
    session.on("session.compaction_start" as any, () => {
      this.opts.sink({ kind: "compaction.start", phaseId: this.currentPhaseId });
    });
    session.on("session.compaction_complete" as any, (event: any) => {
      const data = event?.data ?? {};
      // Best-effort: prefer authoritative token counts from compaction events.
      if (typeof data.promptTokens === "number") this.tokens.prompt = data.promptTokens;
      if (typeof data.completionTokens === "number") this.tokens.completion = data.completionTokens;
      if (typeof data.cachedTokens === "number") this.tokens.cached = data.cachedTokens;
      if (typeof data.totalTokens === "number") this.tokens.total = data.totalTokens;
      this.opts.onTokens({ ...this.tokens });
      this.opts.sink({ kind: "compaction.complete", phaseId: this.currentPhaseId, payload: data });
    });
    session.on("session.idle", () => {
      this.opts.sink({ kind: "idle", phaseId: this.currentPhaseId });
    });
  }

  // Run one phase in its own fresh session and wait for session.idle. Returns final assistant text.
  // Inputs: phaseId, prompt, optional file attachments. Output: assistant message string.
  // Typical response: the phase's final markdown; the per-phase session is always disconnected afterward.
  async sendAndWait(phaseId: string, prompt: string, attachments?: Array<{ type: "file"; path: string; displayName?: string }>): Promise<string> {
    if (!this.client) await this.start();
    this.currentPhaseId = phaseId;
    this.promptCharBuffer += prompt.length;
    this.currentMessageBuffer = "";
    this.recomputeApproxTokens();
    const session = await this.createPhaseSession();
    this.currentSession = session;
    // 10-minute idle timeout: SDLC phases run long agentic loops; the SDK default of 60s is too short.
    try {
      const result = await session.sendAndWait({ prompt, attachments }, 600000);
      const content: string = (result as any)?.data?.content ?? "";
      // Fall back to the streamed assistant text when the final event carries no content.
      return content || this.currentMessageBuffer;
    } catch (err) {
      // Soft-recover: if the phase already produced assistant output but the idle/timeout
      // event was missed or slow, return that output instead of failing the phase.
      if (this.currentMessageBuffer.trim()) {
        this.opts.sink({ kind: "message.final", phaseId: this.currentPhaseId, payload: { content: this.currentMessageBuffer } });
        return this.currentMessageBuffer;
      }
      throw err;
    } finally {
      // Always tear down the per-phase session so context does not bleed across phases.
      try { await session.disconnect(); } catch { /* ignore */ }
      if (this.currentSession === session) this.currentSession = null;
    }
  }

  getTokenTotals(): TokenTotals {
    return { ...this.tokens };
  }

  private recomputeApproxTokens() {
    // Approximate 4 characters per token; replaced by authoritative counts on compaction.
    const approxPrompt = Math.ceil(this.promptCharBuffer / 4);
    const approxCompletion = Math.ceil(this.completionCharBuffer / 4);
    if (this.tokens.prompt < approxPrompt) this.tokens.prompt = approxPrompt;
    if (this.tokens.completion < approxCompletion) this.tokens.completion = approxCompletion;
    this.tokens.total = this.tokens.prompt + this.tokens.completion;
    this.opts.onTokens({ ...this.tokens });
  }

  async dispose(): Promise<void> {
    try { await this.currentSession?.disconnect(); } catch { /* ignore */ }
    try { await this.client?.stop(); } catch { /* ignore */ }
    this.currentSession = null;
    this.client = null;
  }
}
