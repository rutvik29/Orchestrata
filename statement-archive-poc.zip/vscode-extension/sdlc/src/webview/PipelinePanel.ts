// Hosts the SDLC Pipeline WebviewPanel and bridges messages to the orchestrator/session.
// Purpose: own the WebviewPanel lifecycle, wire postMessage in both directions,
//   and route confirmation/permission/userInput prompts to/from the UI.
// Inputs: vscode.ExtensionContext, workspaceRoot path.
// Outputs: PipelinePanel instance with show() and dispose() methods.
// Typical response: opens a webview titled "SDLC Pipeline" with the bundled UI.

import * as vscode from "vscode";
import * as path from "path";
import { loadAgents, type AgentDefinition } from "../agents/agentLoader";
import { Orchestrator } from "../pipeline/orchestrator";
import { SessionManager } from "../copilot/sessionManager";
import { loadRepositoryContext } from "../context/repoContext";
import { apiRegistry } from "../context/apiRegistry";
import type { HostToWebview, WebviewToHost, PermissionPromptPayload, UserInputPromptPayload } from "./protocol";
import type { ConfirmMode } from "../pipeline/phases";

interface PendingPermission {
  resolve: (r: { kind: "approve-once" | "approve-for-session" | "reject"; feedback?: string }) => void;
}
interface PendingUserInput {
  resolve: (r: { answer: string; wasFreeform: boolean }) => void;
}
interface PendingConfirmation {
  resolve: (r: { confirmed: boolean; extraInstructions?: string }) => void;
}

export class PipelinePanel {
  private static instance: PipelinePanel | undefined;
  private panel: vscode.WebviewPanel;
  private session: SessionManager;
  private orchestrator: Orchestrator | null = null;
  private agents: Record<string, AgentDefinition> = {};
  private pendingPermissions = new Map<string, PendingPermission>();
  private pendingUserInputs = new Map<string, PendingUserInput>();
  private pendingConfirmations = new Map<string, PendingConfirmation>();
  private nextPromptId = 1;
  private currentRun: Promise<void> | null = null;

  static async createOrShow(context: vscode.ExtensionContext, workspaceRoot: string) {
    if (PipelinePanel.instance) {
      PipelinePanel.instance.panel.reveal(vscode.ViewColumn.Active);
      return;
    }
    const panel = vscode.window.createWebviewPanel(
      "sdlcPipeline",
      "BMO Digital Core — SDLC Assistant",
      vscode.ViewColumn.Active,
      {
        enableScripts: true,
        retainContextWhenHidden: true,
        localResourceRoots: [vscode.Uri.file(path.join(context.extensionPath, "media"))]
      }
    );
    PipelinePanel.instance = new PipelinePanel(panel, context, workspaceRoot);
    await PipelinePanel.instance.initialize();
  }

  private constructor(panel: vscode.WebviewPanel, private readonly context: vscode.ExtensionContext, private readonly workspaceRoot: string) {
    this.panel = panel;
    this.panel.webview.html = this.renderHtml();
    this.panel.onDidDispose(() => this.dispose());
    this.panel.webview.onDidReceiveMessage((msg) => this.handleMessage(msg as WebviewToHost));

    const cliPathSetting = (vscode.workspace.getConfiguration("sdlc").get<string>("copilot.cliPath", "") ?? "").trim();
    this.session = new SessionManager({
      workspaceRoot,
      cliPath: cliPathSetting || undefined,
      sink: (env) => {
        if (env.kind === "message.delta" || env.kind === "reasoning.delta") {
          this.post({ type: "phase.delta", phaseId: env.phaseId, deltaContent: env.payload?.delta ?? "", channel: env.kind === "reasoning.delta" ? "reasoning" : "message" });
        } else if (env.kind === "tool.start" || env.kind === "tool.complete") {
          this.post({
            type: "phase.tool",
            phaseId: env.phaseId,
            toolName: env.payload?.toolName ?? "?",
            status: env.kind === "tool.start" ? "start" : "complete",
            filePath: this.extractToolFilePath(env.payload)
          });
        }
      },
      onTokens: (totals) => {
        this.post({ type: "tokens", totalApprox: totals.total, promptApprox: totals.prompt, completionApprox: totals.completion });
      },
      onPermissionRequest: (req) => this.askPermission(req),
      onUserInputRequest: (req) => this.askUserInput(req)
    });
  }

  private async initialize() {
    if (!apiRegistry.isInitialized()) {
      await apiRegistry.initialize().catch((err: any) => {
        this.post({ type: "log", level: "warn", message: `API registry initialization failed: ${err?.message ?? err}` });
      });
    }

    this.agents = await loadAgents(this.workspaceRoot);
    this.orchestrator = new Orchestrator(this.session, this.agents, this.workspaceRoot, {
      onPhaseUpdate: (phase) => this.post({ type: "phase.update", phase }),
      onEvent: () => { /* sink already forwards UI-relevant events */ },
      awaitConfirmation: (phaseId, summary) => this.askConfirmation(phaseId, summary),
      onRunState: (state) => this.post({ type: "run.state", state })
    });

    try { await this.session.start(); } catch (err: any) {
      this.post({ type: "log", level: "error", message: `Failed to start Copilot CLI: ${err?.message ?? err}` });
    }
    const sdkModels = await this.session.listModels().catch(() => []);
    const models = sdkModels.map((m: any) => ({ id: m.id ?? m.name, label: m.name ?? m.id, supportsReasoning: !!m.supportsReasoning }));
    const settings = vscode.workspace.getConfiguration("sdlc");
    const defaultModel = settings.get<string>("copilot.defaultModel", "gpt-5");
    const maxIterations = settings.get<number>("pipeline.maxReviewIterations", 3);
    const confirmMode = settings.get<string>("pipeline.confirmBetweenPhases", "high-impact-only");

    this.post({
      type: "init",
      workspaceName: path.basename(this.workspaceRoot),
      models: models.length ? models : [{ id: defaultModel, label: defaultModel }],
      defaultModel,
      phases: this.orchestrator.buildInitialSummaries(),
      settings: { maxIterations, confirmMode }
    });

    this.post({ type: "api.operations", operations: apiRegistry.getOperations() });

    if (Object.keys(this.agents).length === 0) {
      this.post({ type: "log", level: "warn", message: "No agents found in .copilot/agents (checked ~/.copilot/agents and <workspace>/.copilot/agents). Install the SDLC agents there before running the pipeline." });
    }
  }

  private async handleMessage(msg: WebviewToHost) {
    switch (msg.type) {
      case "ready":
        // No-op; init is pushed proactively.
        break;
      case "run.start": {
        if (this.currentRun) {
          this.post({ type: "log", level: "warn", message: "A run is already in progress." });
          return;
        }
        if (!this.orchestrator) return;
        const orchestrator = this.orchestrator;
        const repos = (msg.repositories ?? []).map((r) => r.trim()).filter((r) => r.length > 0);
        this.currentRun = (async () => {
          let repositoryContext: string | undefined;
          if (repos.length) {
            this.post({ type: "repoContext", items: [], loading: true });
            const apiBaseUrl = vscode.workspace.getConfiguration("sdlc").get<string>("github.apiBaseUrl", "https://api.github.com");
            try {
              const { contextMarkdown, items } = await loadRepositoryContext(repos, apiBaseUrl, (level, message) => this.post({ type: "log", level, message }));
              repositoryContext = contextMarkdown || undefined;
              this.post({ type: "repoContext", items, loading: false });
            } catch (err: any) {
              this.post({ type: "log", level: "error", message: `Repository context loading failed: ${err?.message ?? err}` });
              this.post({ type: "repoContext", items: [], loading: false });
            }
          }
          await orchestrator.run({
            prompt: msg.prompt,
            model: msg.model,
            maxIterations: msg.maxIterations,
            confirmMode: msg.confirmMode as ConfirmMode,
            startFromPhase: msg.startFromPhase,
            repositoryContext
          });
        })().catch((err: any) => {
          this.post({ type: "log", level: "error", message: `Run failed: ${err?.message ?? err}` });
          this.post({ type: "run.state", state: "failed" });
        }).finally(() => { this.currentRun = null; });
        break;
      }
      case "run.abort":
        this.orchestrator?.requestAbort();
        break;
      case "run.reset":
        if (this.orchestrator) {
          this.post({ type: "init",
            workspaceName: path.basename(this.workspaceRoot),
            models: [],
            defaultModel: vscode.workspace.getConfiguration("sdlc").get<string>("copilot.defaultModel", "gpt-5"),
            phases: this.orchestrator.buildInitialSummaries(),
            settings: { maxIterations: 3, confirmMode: "high-impact-only" }
          });
        }
        break;
      case "phase.confirm": {
        const pending = this.pendingConfirmations.get(msg.phaseId);
        if (pending) {
          pending.resolve({ confirmed: true, extraInstructions: msg.extraInstructions });
          this.pendingConfirmations.delete(msg.phaseId);
        }
        break;
      }
      case "phase.reject": {
        const pending = this.pendingConfirmations.get(msg.phaseId);
        if (pending) {
          pending.resolve({ confirmed: false });
          this.pendingConfirmations.delete(msg.phaseId);
        }
        break;
      }
      case "permission.response": {
        const pending = this.pendingPermissions.get(msg.id);
        if (pending) {
          pending.resolve({ kind: msg.decision, feedback: msg.feedback });
          this.pendingPermissions.delete(msg.id);
        }
        break;
      }
      case "userInput.response": {
        const pending = this.pendingUserInputs.get(msg.id);
        if (pending) {
          pending.resolve({ answer: msg.answer, wasFreeform: msg.wasFreeform });
          this.pendingUserInputs.delete(msg.id);
        }
        break;
      }
      case "openTranscript": {
        try {
          const doc = await vscode.workspace.openTextDocument(msg.path);
          await vscode.window.showTextDocument(doc, vscode.ViewColumn.Beside);
        } catch (err: any) {
          this.post({ type: "log", level: "error", message: `Cannot open transcript: ${err?.message ?? err}` });
        }
        break;
      }
      case "api.openSwaggerUI": {
        const swaggerUrl = vscode.Uri.parse("http://localhost:3000/swagger.json");
        await vscode.env.openExternal(swaggerUrl);
        break;
      }
      case "api.getSchema": {
        const schema = apiRegistry.getSchema(msg.operation);
        if (!schema) {
          this.post({ type: "log", level: "warn", message: `No API schema found for operation '${msg.operation}'.` });
          break;
        }
        this.post({ type: "api.schema", operation: msg.operation, schema });
        break;
      }
      case "ondemand.run": {
        // Run an on-demand agent (impact / appoverview) in its own isolated session as a one-shot.
        const agent = this.agents[msg.agentName];
        if (!agent) {
          this.post({ type: "log", level: "error", message: `Agent '${msg.agentName}' not found.` });
          return;
        }
        const cfg = vscode.workspace.getConfiguration("sdlc");
        const model = cfg.get<string>("copilot.defaultModel", "gpt-5");
        try {
          await this.session.prepare(model);
          const prompt = `# On-demand invocation — ${agent.name}\n\n## User request\n${msg.prompt}\n\n## AGENT PERSONA\n${agent.body}`;
          await this.session.sendAndWait(`ondemand-${agent.name}`, prompt);
          this.post({ type: "log", level: "info", message: `On-demand ${agent.name} run complete.` });
        } catch (err: any) {
          this.post({ type: "log", level: "error", message: `On-demand failed: ${err?.message ?? err}` });
        }
        break;
      }
    }
  }

  private askConfirmation(phaseId: string, summary: string): Promise<{ confirmed: boolean; extraInstructions?: string }> {
    return new Promise((resolve) => {
      this.pendingConfirmations.set(phaseId, { resolve });
      this.post({ type: "phase.awaitingConfirmation", phaseId, summary });
    });
  }

  private askPermission(req: any): Promise<any> {
    return new Promise((resolve) => {
      const id = `perm-${this.nextPromptId++}`;
      this.pendingPermissions.set(id, {
        resolve: (r) => resolve(r.kind === "reject" ? { kind: "reject", feedback: r.feedback } : { kind: r.kind })
      });
      const payload: PermissionPromptPayload = {
        id,
        kind: req.kind,
        toolName: req.toolName,
        fileName: req.fileName,
        fullCommandText: req.fullCommandText,
        description: this.describePermission(req)
      };
      this.post({ type: "permission.request", payload });
    });
  }

  private askUserInput(req: { question: string; choices?: string[]; allowFreeform: boolean }): Promise<{ answer: string; wasFreeform: boolean }> {
    return new Promise((resolve) => {
      const id = `uin-${this.nextPromptId++}`;
      this.pendingUserInputs.set(id, { resolve });
      const payload: UserInputPromptPayload = { id, question: req.question, choices: req.choices, allowFreeform: req.allowFreeform };
      this.post({ type: "userInput.request", payload });
    });
  }

  private describePermission(req: any): string {
    switch (req.kind) {
      case "shell": return `Run shell command: ${req.fullCommandText ?? "(unknown)"}`;
      case "write": return `Write file: ${req.fileName ?? "(unknown)"}`;
      case "read": return `Read file: ${req.fileName ?? "(unknown)"}`;
      case "mcp": return `Call MCP tool: ${req.toolName ?? "(unknown)"}`;
      case "custom-tool": return `Call custom tool: ${req.toolName ?? "(unknown)"}`;
      case "url": return `Fetch URL`;
      default: return `Permission request: ${req.kind}`;
    }
  }

  // Best-effort extraction of a workspace file path from a tool event payload.
  // Purpose: surface file artifacts created by write/edit tools to the Generated Files table.
  // Inputs: payload (the tool event payload: { toolName, args?, result? }).
  // Outputs: a relative/absolute file path string, or undefined when none is detected.
  // Typical response: "src/auth/AuthService.ts" for a write tool, undefined for a shell command.
  private extractToolFilePath(payload: any): string | undefined {
    if (!payload) return undefined;
    const tool = String(payload.toolName ?? "").toLowerCase();
    const isFileTool = /(write|edit|create|str_replace|insert|patch|apply)/.test(tool);
    if (!isFileTool) return undefined;
    const candidates = [payload.args, payload.result, payload].filter(Boolean);
    const keys = ["path", "filePath", "file", "fileName", "filename", "target", "uri"];
    for (const source of candidates) {
      if (typeof source === "string") continue;
      for (const key of keys) {
        const value = source?.[key];
        if (typeof value === "string" && value.trim() && !value.includes("\n")) {
          return value.replace(/^file:\/\//, "");
        }
      }
    }
    return undefined;
  }

  private post(msg: HostToWebview) {
    this.panel.webview.postMessage(msg);
  }

  private renderHtml(): string {
    const webview = this.panel.webview;
    const scriptUri = webview.asWebviewUri(vscode.Uri.file(path.join(this.context.extensionPath, "media", "webview.js")));
    const styleUri = webview.asWebviewUri(vscode.Uri.file(path.join(this.context.extensionPath, "media", "webview.css")));
    const nonce = Math.random().toString(36).slice(2);
    const csp = `default-src 'none'; img-src ${webview.cspSource} https: data:; script-src 'nonce-${nonce}'; style-src ${webview.cspSource} 'unsafe-inline'; font-src ${webview.cspSource};`;
    return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta http-equiv="Content-Security-Policy" content="${csp}" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="${styleUri}" />
  <title>BMO Digital Core — SDLC Assistant</title>
</head>
<body>
  <div id="app"></div>
  <script nonce="${nonce}" src="${scriptUri}"></script>
</body>
</html>`;
  }

  async dispose() {
    PipelinePanel.instance = undefined;
    try { await this.session.dispose(); } catch { /* ignore */ }
  }
}
