// Webview UI for the SDLC Pipeline panel.
// Purpose: render the model picker, phase cards, focused detail pane, token meter,
//   and modal prompts for confirmations / permissions / user-input. Bridges to the
//   extension host via vscode.postMessage.
// Inputs: HostToWebview messages on `window.addEventListener('message', ...)`.
// Outputs: WebviewToHost messages via vscode.postMessage(...).
// Typical response: DOM updates as messages arrive; user clicks emit WebviewToHost messages.

import type { HostToWebview, WebviewToHost, PhaseSummary, ModelInfo, PermissionPromptPayload, UserInputPromptPayload, RepoContextItem, ApiOperation, ApiSchema } from "./protocol";

// VS Code webview API global.
declare function acquireVsCodeApi(): { postMessage: (msg: any) => void; getState: () => any; setState: (s: any) => void };

const vscode = acquireVsCodeApi();

interface FileRow {
  path: string;
  phaseId: string;
  tool: string;
}

interface UiState {
  workspaceName: string;
  models: ModelInfo[];
  defaultModel: string;
  phases: PhaseSummary[];
  selectedPhaseId: string | null;
  tokens: { total: number; prompt: number; completion: number };
  tokenCap: number;
  streamBuffers: Record<string, { message: string; reasoning: string; tools: string[] }>;
  runState: "idle" | "running" | "paused" | "aborted" | "finished" | "failed";
  awaitingPhaseId: string | null;
  awaitingSummary: string;
  maxIterations: number;
  confirmMode: string;
  logs: { level: string; message: string }[];
  prompt: string;
  startFrom: string;
  filesByPhase: Record<string, string[]>;
  fileRows: FileRow[];
  repositoryInput: string;
  repoContext: { items: RepoContextItem[]; loading: boolean };
  api: { operations: ApiOperation[]; drawerOpen: boolean; selectedOperation: string | null; selectedSchema: ApiSchema | null };
}

const state: UiState = {
  workspaceName: "",
  models: [],
  defaultModel: "gpt-5",
  phases: [],
  selectedPhaseId: null,
  tokens: { total: 0, prompt: 0, completion: 0 },
  tokenCap: 200000,
  streamBuffers: {},
  runState: "idle",
  awaitingPhaseId: null,
  awaitingSummary: "",
  maxIterations: 3,
  confirmMode: "high-impact-only",
  logs: [],
  prompt: "",
  startFrom: "",
  filesByPhase: {},
  fileRows: [],
  repositoryInput: "",
  repoContext: { items: [], loading: false },
  api: { operations: [], drawerOpen: false, selectedOperation: null, selectedSchema: null }
};

// Render summary text with safe support for API markdown links.
// Purpose: preserve escaped text while converting [label](/swagger/operation) to clickable anchors.
// Inputs: summary text produced by the orchestrator.
// Outputs: HTML-safe string with API links rendered as anchor tags.
// Typical response: "Use <a ... data-operation=\"authenticate\">clientId→API</a>".
function renderSummaryHtml(text: string): string {
  const escaped = escapeHtml(text);
  const withLinks = escaped.replace(/\[([^\]]+)\]\(\/swagger\/([A-Za-z0-9_-]+)\)/g, (_m, label, operation) => {
    return `<a href="#" class="api-link" data-act="api-open" data-operation="${operation}" title="Open API schema">${label}</a>`;
  });
  return withLinks.replace(/\n/g, "<br>");
}

function post(msg: WebviewToHost) { vscode.postMessage(msg); }

// ── Phase visuals (teardrop colors + line-art icons) ─────────
// Purpose: map each phase to a vivid timeline color and an SVG icon, like the SDLC graphic.
// Inputs: a PhaseSummary and its index in the pipeline.
// Outputs: { color, icon } used to style the teardrop pin.
// Typical response: { color: "#2563eb", icon: "<svg…>" } for the Development phase.
const PHASE_PALETTE = ["#14b8a6", "#22c55e", "#f59e0b", "#2563eb", "#6366f1", "#ef4444", "#f97316", "#06b6d4", "#a855f7"];

const ICONS: Record<string, string> = {
  "doc-processor": `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/><path d="M8 13h4"/><path d="M8 17h3"/></svg>`,
  "ba-analyst": `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></svg>`,
  architect: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="m12 3 9 5-9 5-9-5 9-5Z"/><path d="m3 13 9 5 9-5"/></svg>`,
  dev: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="m8 7-5 5 5 5"/><path d="m16 7 5 5-5 5"/></svg>`,
  codereview: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9 4h6v2H9z"/><path d="M8 6H6a2 2 0 0 0-2 2v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-2"/><path d="m9 14 2 2 4-4"/></svg>`,
  security: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3 5 6v5c0 4 3 7 7 9 4-2 7-5 7-9V6l-7-3Z"/><path d="m9 12 2 2 4-4"/></svg>`,
  performance: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3.5 18a9 9 0 1 1 17 0"/><path d="M12 14 8.5 9.5"/><circle cx="12" cy="14" r="1.6"/></svg>`,
  qa: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9 8a3 3 0 0 1 6 0"/><rect x="8" y="8" width="8" height="10" rx="4"/><path d="M4 13h4M16 13h4M5 8l2.2 2M19 8l-2.2 2M5 18l2.2-2M19 18l-2.2-2"/></svg>`,
  devops: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 15c-1 1-1.2 4-1.2 4s3-0.2 4-1.2l1-2-2.8-2.8-1 2Z"/><path d="M9 11c3-6 8-7 11-7 0 3-1 8-7 11"/><circle cx="14.5" cy="9.5" r="1.5"/><path d="m9 11 4 4"/></svg>`
};
const ICON_FALLBACK = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="8"/><path d="M12 8v8M8 12h8"/></svg>`;

const BRAND_LOGO = `<svg viewBox="0 0 210 55" fill="none" preserveAspectRatio="xMidYMid meet"><path d="M23,28 C23,31.76 21.28,33.84 16.75,33.84 L12.88,33.84 L12.88,22.35 C13.37,22.3 15.01,22.27 15.5,22.27 L16.82,22.27 C21.44,22.27 23,24.23 23,28 Z M32.2,43 C32.2,37.07 27.36,34.92 21.49,34.79 L21.49,34.57 C26.49,34.16 30.58,32.07 30.58,27.03 C30.58,21.42 25.94,20.37 20.75,20.37 C14.51,20.37 7.19,20.54 0.97,20.37 L0.97,22.3 C2.28,22.21 5.48,22.39 5.48,24.04 L5.48,47.92 C5.48,49.52 2.2,49.74 0.97,49.74 L0.97,51.62 C6.97,51.46 14.12,51.62 20.17,51.62 C26.53,51.62 32.2,49.47 32.2,43 Z M24.2,42.39 C24.2,47.3 22.49,49.63 16.55,49.63 L12.85,49.63 L12.85,35.87 L16.79,35.87 C22.22,35.87 24.23,37.7 24.23,42.35 L24.2,42.39 Z" fill="#FFFFFF" fill-rule="nonzero"/><path d="M72.45,51.57 C69.65,51.57 66.86,51.57 64.07,51.62 L64.07,49.7 C65.34,49.7 68.86,49.63 68.86,47.92 L68.86,25.74 L68.76,25.74 L56.14,52 L54.62,52 L42.31,25.69 L42.22,25.69 L42.22,47.92 C42.22,49.67 45.71,49.7 47.03,49.7 L47.09,51.62 C43.6,51.51 38.84,51.43 35.41,51.62 L35.41,49.7 C36.74,49.7 39.74,49.59 39.74,47.92 L39.74,24 C39.74,22.37 36.64,22.23 35.41,22.23 L35.41,20.3 C39.41,20.47 43.65,20.47 47.62,20.3 L58.14,42.49 L68.91,20.38 C72.73,20.55 77.05,20.5 80.91,20.33 L80.91,22.26 C79.64,22.26 76.31,22.35 76.31,24.03 L76.31,47.92 C76.31,49.63 79.6,49.7 80.91,49.7 L80.91,51.62 C78.08,51.54 75.24,51.57 72.45,51.57 Z" fill="#FFFFFF" fill-rule="nonzero"/><path d="M110.29,35.94 C110.29,41.94 109.7,50.23 100.84,50.23 C91.98,50.23 91.34,41.9 91.34,35.94 C91.34,29.98 91.98,21.71 100.84,21.71 C109.7,21.71 110.29,30 110.29,35.94 Z M118.57,35.94 C118.57,25.59 112.25,19.78 100.84,19.78 C89.43,19.78 83.05,25.54 83.05,35.94 C83.05,46.34 89.38,52.14 100.84,52.14 C112.3,52.14 118.57,46.35 118.57,35.94 Z" fill="#FFFFFF" fill-rule="nonzero"/><circle cx="171.56" cy="36" r="27" fill="#ED1C24"/><path d="M170.46,25 L164.21,16.85 C163.946665,16.5028122 163.535757,16.2992088 163.1,16.3 C162.67683,16.2976313 162.277034,16.4938271 162.02,16.83 L154.58,26.2 L154.58,40.9 L162,31.41 C162.272572,31.0633019 162.688985,30.8606231 163.13,30.86 C163.576598,30.8584097 163.998295,31.065559 164.27,31.42 L170.55,39.63 C170.790682,39.9419108 171.156432,40.1321005 171.55,40.15 C171.944673,40.1362572 172.312086,39.9452027 172.55,39.63 L178.83,31.42 C179.104645,31.0691639 179.524458,30.8629399 179.97,30.86 C180.41206,30.8560515 180.830382,31.0596594 181.1,31.41 L188.5,40.89 L188.5,26.19 L181.06,16.82 C180.798823,16.4834822 180.395972,16.2876005 179.97,16.2899782 C179.53532,16.2937702 179.126312,16.4964317 178.86,16.84 L172.66,25 C172.398755,25.34309 171.991219,25.5431533 171.56,25.54 C171.129846,25.5385487 170.724237,25.3394316 170.46,25 Z M188.55,51.67 L154.55,51.67 L154.55,40.89 L188.55,40.89 L188.55,51.67 Z" fill="#FFFFFF" fill-rule="nonzero"/></svg>`;

const BADGES: Record<string, string> = {
  running: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"><path d="M21 12a9 9 0 1 1-6.2-8.5"/></svg>`,
  passed: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"><path d="m5 13 4 4L19 7"/></svg>`,
  failed: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.4" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg>`,
  "awaiting-confirmation": `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.4" stroke-linecap="round"><path d="M9 5v14M15 5v14"/></svg>`
};

// Map a phase status to its timeline-node CSS state class.
// Inputs: a PhaseStatus string. Outputs: an "is-*" class name.
// Typical response: "is-running" for status "running".
function tlStateClass(status: string): string {
  return (
    { pending: "is-pending", running: "is-running", "awaiting-confirmation": "is-awaiting", passed: "is-passed", failed: "is-failed", skipped: "is-skipped" } as Record<string, string>
  )[status] ?? "is-pending";
}

// Human label for the global run state shown in the status pill.
// Inputs: none (reads state.runState). Outputs: a short label string.
// Typical response: "Running" while a pipeline executes.
function runLabel(): string {
  switch (state.runState) {
    case "running": return "Running";
    case "paused": return "Awaiting confirmation";
    case "aborted": return "Aborted";
    case "failed": return "Failed";
    case "finished": return "Complete";
    default: return "Ready";
  }
}

// Record a generated file against a phase (deduplicated) for the Files table and traceability.
// Inputs: phaseId, filePath, and the originating tool name.
// Outputs: mutates state.filesByPhase and state.fileRows; returns void.
// Typical response: adds { path: "src/auth/AuthService.ts", phaseId, tool: "write" }.
function addFile(phaseId: string, filePath: string | undefined, tool: string): void {
  if (!filePath) return;
  const list = state.filesByPhase[phaseId] ?? (state.filesByPhase[phaseId] = []);
  if (!list.includes(filePath)) list.push(filePath);
  if (!state.fileRows.some((r) => r.path === filePath && r.phaseId === phaseId)) {
    state.fileRows.push({ path: filePath, phaseId, tool: tool || "write" });
  }
}

// Find a phase's pipeline index (used for stable color assignment).
// Inputs: a phase id. Outputs: index number, or 0 when not found.
// Typical response: 3 for "phase-3-dev".
function phaseIndex(id: string): number {
  const i = state.phases.findIndex((p) => p.id === id);
  return i < 0 ? 0 : i;
}

function colorFor(id: string): string {
  return PHASE_PALETTE[phaseIndex(id) % PHASE_PALETTE.length];
}

// Render the entire webview from current state.
// Inputs: none (reads module-level `state`). Outputs: replaces #app innerHTML; returns void.
// Typical response: a teardrop-pin SDLC timeline with config, tabs, files, and traceability.
function render() {
  const app = document.getElementById("app")!;
  const total = state.phases.length;
  const done = state.phases.filter((p) => p.status === "passed" || p.status === "skipped").length;
  const elapsedMs = state.phases.reduce((acc, p) => acc + (p.elapsedMs ?? 0), 0);
  const tokenPct = Math.min(100, (state.tokens.total / state.tokenCap) * 100);

  const selected = state.phases.find((p) => p.id === state.selectedPhaseId) ?? state.phases[0];
  if (selected) state.selectedPhaseId = selected.id;

  // Output tabs
  const tabs = state.phases
    .map((p, i) => {
      const color = PHASE_PALETTE[i % PHASE_PALETTE.length];
      const activeClass = p.id === state.selectedPhaseId ? " is-active" : "";
      return `<button class="tab ${tlStateClass(p.status)}${activeClass}" data-act="select-phase" data-phase="${escapeHtml(p.id)}" style="--pin:${color}"><span class="tab__dot"></span>${escapeHtml(p.title)}</button>`;
    })
    .join("");

  // Selected phase panel
  let panelHtml = `<div class="empty">No phases loaded.</div>`;
  if (selected) {
    const buf = state.streamBuffers[selected.id] ?? { message: "", reasoning: "", tools: [] };
    const color = colorFor(selected.id);
    const metaParts = [`@${escapeHtml(selected.agentName)}`];
    if (selected.iteration && selected.iteration > 1) metaParts.push(`iteration ${selected.iteration}`);
    if (typeof selected.approxTokens === "number" && selected.approxTokens > 0) metaParts.push(`~${selected.approxTokens.toLocaleString()} tokens`);
    if (selected.elapsedMs) metaParts.push(`${(selected.elapsedMs / 1000).toFixed(1)}s`);

    let gateHtml = "";
    if (state.awaitingPhaseId === selected.id) {
      gateHtml = `
        <div class="gate">
          <div class="gate__title">${BADGES["awaiting-confirmation"]} Awaiting your confirmation</div>
          <div class="gate__summary">${escapeHtml(state.awaitingSummary).slice(0, 1200)}</div>
          <textarea id="gateExtra" placeholder="Optional extra instructions for the next phase…"></textarea>
          <div class="gate__actions">
            <button class="btn btn--primary btn--xs" data-act="gate-confirm" data-phase="${escapeHtml(selected.id)}">Confirm &amp; continue</button>
            <button class="btn btn--danger btn--xs" data-act="gate-reject" data-phase="${escapeHtml(selected.id)}">Reject &amp; stop</button>
          </div>
        </div>`;
    }

    const reasoningBlock = buf.reasoning
      ? `<div class="output-block"><div class="output-block__label">Reasoning</div><pre class="output" data-pane="reasoning">${escapeHtml(buf.reasoning)}</pre></div>`
      : "";
    const toolsBlock = buf.tools.length
      ? `<div class="output-block"><div class="output-block__label">Tool calls</div><pre class="output" data-pane="tools">${escapeHtml(buf.tools.join("\n"))}</pre></div>`
      : "";
    const transcript = selected.transcriptPath
      ? `<a href="#" data-act="open-transcript" data-phase="${escapeHtml(selected.id)}">Open transcript</a>`
      : "(no transcript yet)";

    const summaryText = selected.summary || buf.message || "(no output yet)";

    panelHtml = `
      <div class="panel is-active" style="--pin:${color}">
        <div class="panel__head">
          <span class="panel__title">${escapeHtml(selected.title)}</span>
          <span class="badge s-${selected.status}">${escapeHtml(selected.status)}</span>
        </div>
        <div class="panel__meta">${metaParts.join(" · ")} · ${transcript}</div>
        ${gateHtml}
        <div class="output-block"><div class="output-block__label">Summary</div><div class="output output--rich" data-pane="message">${renderSummaryHtml(summaryText)}</div></div>
        ${reasoningBlock}
        ${toolsBlock}
        <div class="config__actions">
          <button class="btn btn--ghost btn--xs" data-act="run-from" data-phase="${escapeHtml(selected.id)}">Run from this phase</button>
          <button class="btn btn--ghost btn--xs" data-act="copy-output" data-phase="${escapeHtml(selected.id)}">Copy output</button>
          <button class="btn btn--ghost btn--xs" data-act="api-toggle">API Schemas</button>
        </div>
      </div>`;
  }

  // Phase title lookup (used by the generated-files table).
  const titleById: Record<string, string> = {};
  for (const p of state.phases) titleById[p.id] = p.title;

  // Files table
  const filesTable = state.fileRows.length
    ? `<div class="tablewrap"><table class="files"><thead><tr><th>File</th><th>Phase</th><th>Action</th></tr></thead><tbody>${state.fileRows
        .map((r) => {
          const color = colorFor(r.phaseId);
          const phaseTitle = titleById[r.phaseId] ?? r.phaseId;
          return `<tr><td class="path">${escapeHtml(r.path)}</td><td><span class="chip" style="--pin:${color}">${escapeHtml(phaseTitle)}</span></td><td>${escapeHtml(r.tool)}</td></tr>`;
        })
        .join("")}</tbody></table></div>`
    : `<div class="empty">No files generated yet. Run the pipeline to create artifacts.</div>`;

  // Model / gate / start-from options
  const modelOpts = state.models.map((m) => `<option value="${escapeHtml(m.id)}" ${m.id === state.defaultModel ? "selected" : ""}>${escapeHtml(m.label)}</option>`).join("");
  const gateOpts = `
    <option value="never" ${state.confirmMode === "never" ? "selected" : ""}>Never pause</option>
    <option value="high-impact-only" ${state.confirmMode === "high-impact-only" ? "selected" : ""}>High-impact only</option>
    <option value="always" ${state.confirmMode === "always" ? "selected" : ""}>Every phase</option>`;
  const startOpts = `<option value="">(beginning)</option>` + state.phases.map((p) => `<option value="${escapeHtml(p.id)}" ${p.id === state.startFrom ? "selected" : ""}>${escapeHtml(p.title)}</option>`).join("");

  const repoItems = state.repoContext.items;
  const repoStatus = state.repoContext.loading
    ? `<div class="repostatus repostatus--loading">Loading repository context…</div>`
    : repoItems.length
      ? `<div class="repostatus">${repoItems.map((it) => `<span class="repochip ${it.ok ? "ok" : "fail"}" title="${escapeHtml(it.detail)}">${it.ok ? "✓" : "✕"} ${escapeHtml(it.id)}</span>`).join("")}</div>`
      : "";

  const runDisabled = state.runState === "running" || state.runState === "paused" ? "disabled" : "";
  const abortDisabled = state.runState !== "running" && state.runState !== "paused" ? "disabled" : "";

  // Modal
  let modalHtml = "";
  if (pendingPermission) {
    modalHtml = `
      <div class="modal is-open">
        <div class="modal__card">
          <div class="modal__title">Copilot permission request</div>
          <div class="modal__body">${escapeHtml(pendingPermission.description)}</div>
          <div class="modal__actions">
            <button class="btn btn--primary btn--xs" data-act="perm-approve-once">Approve once</button>
            <button class="btn btn--ghost btn--xs" data-act="perm-approve-session">Approve for session</button>
            <button class="btn btn--danger btn--xs" data-act="perm-reject">Reject</button>
          </div>
        </div>
      </div>`;
  } else if (pendingUserInput) {
    const choices = pendingUserInput.choices ? `<select id="uinChoice">${pendingUserInput.choices.map((c) => `<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`).join("")}</select>` : "";
    const freeform = pendingUserInput.allowFreeform ? `<textarea id="uinFreeform" placeholder="Your answer…"></textarea>` : "";
    modalHtml = `
      <div class="modal is-open">
        <div class="modal__card">
          <div class="modal__title">Copilot needs your input</div>
          <div class="modal__body">${escapeHtml(pendingUserInput.question)}</div>
          ${choices}
          ${freeform}
          <div class="modal__actions"><button class="btn btn--primary btn--xs" data-act="uin-submit">Send</button></div>
        </div>
      </div>`;
  }

  const logsHtml = state.logs.slice(-40).map((l) => `<div class="logs__line ${l.level}">[${l.level}] ${escapeHtml(l.message)}</div>`).join("") || `<div class="logs__line">No activity yet.</div>`;

  const apiOps = state.api.operations
    .map((op) => `<option value="${escapeHtml(op.name)}" ${state.api.selectedOperation === op.name ? "selected" : ""}>${escapeHtml(op.name)} (${escapeHtml(op.method.toUpperCase())} ${escapeHtml(op.path)})</option>`)
    .join("");
  const apiSchemaHtml = state.api.selectedSchema
    ? `<pre class="output output--schema">${escapeHtml(JSON.stringify(state.api.selectedSchema, null, 2))}</pre>`
    : `<div class="empty">Select an operation to view schema details.</div>`;
  const apiDrawerHtml = state.api.drawerOpen
    ? `<section class="card api-drawer">
        <div class="section-title">Statements API Schemas</div>
        <div class="api-controls">
          <select id="apiOperation">${apiOps || `<option value="">No operations loaded</option>`}</select>
          <button class="btn btn--ghost btn--xs" data-act="api-load">Load schema</button>
          <button class="btn btn--ghost btn--xs" data-act="api-open-docs">Open Swagger JSON</button>
        </div>
        ${apiSchemaHtml}
      </section>`
    : "";

  app.innerHTML = `
    <div class="app">
      <header class="appbar">
        <div class="appbar__brand">
          <div class="appbar__logo">${BRAND_LOGO}</div>
          <div class="appbar__titles">
            <div class="appbar__title">BMO Digital Core — SDLC Assistant</div>
            <div class="appbar__subtitle">Digital Core · Full SDLC orchestration via GitHub Copilot${state.workspaceName ? " · " + escapeHtml(state.workspaceName) : ""}</div>
          </div>
        </div>
        <div class="appbar__spacer"></div>
        <div class="statuspill is-${state.runState}"><span class="statuspill__dot"></span><span>${escapeHtml(runLabel())}</span></div>
        <div class="tokenmeter">
          <div class="tokenmeter__label"><span>Tokens</span><span data-token-count>${state.tokens.total.toLocaleString()}</span></div>
          <div class="tokenmeter__bar"><div class="tokenmeter__fill" data-token-fill style="width:${tokenPct}%"></div></div>
        </div>
      </header>

      <div class="page">
        <aside class="col-left">
        <section class="card">
          <div class="section-title">Run configuration</div>
          <div class="config__grid">
            <div>
              <div class="field">
                <label class="field__label" for="prompt">Requirement</label>
                <textarea id="prompt" data-field="prompt" placeholder="Describe what to build, change, or analyze…">${escapeHtml(state.prompt)}</textarea>
              </div>
              <div class="field">
                <label class="field__label" for="repositories">GitHub repositories (optional)</label>
                <textarea id="repositories" data-field="repositories" class="repos-input" placeholder="owner/repo or URLs · comma or newline separated">${escapeHtml(state.repositoryInput)}</textarea>
                <p class="field__hint">Loaded as read-only context before the run. Sign in to GitHub for private repos or higher rate limits.</p>
                ${repoStatus}
              </div>
            </div>
            <div>
              <div class="field"><label class="field__label" for="model">Model</label><select id="model" data-field="model">${modelOpts}</select></div>
              <div class="field"><label class="field__label" for="confirmMode">Approval gates</label><select id="confirmMode" data-field="confirmMode">${gateOpts}</select></div>
              <div class="field"><label class="field__label" for="maxIter">Max review iterations</label><input id="maxIter" data-field="maxIter" type="number" min="1" max="10" value="${state.maxIterations}" /></div>
              <div class="field"><label class="field__label" for="startFrom">Start from phase</label><select id="startFrom" data-field="startFrom">${startOpts}</select></div>
            </div>
          </div>
          <div class="config__actions">
            <button class="btn btn--primary" data-act="run" ${runDisabled}>Run pipeline</button>
            <button class="btn btn--danger" data-act="abort" ${abortDisabled}>Abort</button>
            <button class="btn btn--ghost" data-act="reset">Reset</button>
            <span style="flex:1"></span>
            <button class="btn btn--ghost btn--xs" data-act="ondemand-impact">Run Impact Analysis</button>
            <button class="btn btn--ghost btn--xs" data-act="ondemand-overview">Run App Overview</button>
          </div>
        </section>

        <section class="stats">
          <div class="stat"><span class="stat__value">${done}/${total}</span><span class="stat__label">Phases complete</span></div>
          <div class="stat"><span class="stat__value">${state.fileRows.length}</span><span class="stat__label">Files generated</span></div>
          <div class="stat"><span class="stat__value" data-stat-tokens>${state.tokens.total.toLocaleString()}</span><span class="stat__label">Approx tokens</span></div>
          <div class="stat"><span class="stat__value">${(elapsedMs / 1000).toFixed(1)}s</span><span class="stat__label">Phase time</span></div>
        </section>
        </aside>

        <main class="col-right">
        <section class="card">
          <div class="section-title">Phase output</div>
          <div class="tabs__bar">${tabs}</div>
          ${panelHtml}
        </section>

        <section class="card">
          <div class="section-title">Generated files</div>
          ${filesTable}
        </section>

        <section class="card">
          <div class="section-title">Activity log</div>
          <div class="logs">${logsHtml}</div>
        </section>
        ${apiDrawerHtml}
        </main>
      </div>
    </div>
    ${modalHtml}
  `;

  ensureWired();
  if (state.runState === "running") stickStreamingPanes();
}

let pendingPermission: PermissionPromptPayload | null = null;
let pendingUserInput: UserInputPromptPayload | null = null;

let wired = false;

// Attach delegated event listeners to #app exactly once (they survive re-renders).
// Inputs: none. Outputs: registers click/input/change handlers on the app container.
// Typical response: clicking a pin or button is routed through onAppClick.
function ensureWired() {
  if (wired) return;
  wired = true;
  const app = document.getElementById("app")!;
  app.addEventListener("click", onAppClick);
  app.addEventListener("input", onFieldChange);
  app.addEventListener("change", onFieldChange);
}

// Persist edits to configuration fields into state without forcing a re-render.
// Inputs: a DOM input/change Event carrying a [data-field] element.
// Outputs: mutates `state`; returns void.
// Typical response: typing in the requirement box updates state.prompt.
function onFieldChange(e: Event) {
  const el = e.target as HTMLInputElement & { dataset: DOMStringMap };
  const field = el?.dataset?.field;
  if (!field) return;
  const value = el.value;
  switch (field) {
    case "prompt": state.prompt = value; break;
    case "model": state.defaultModel = value; break;
    case "confirmMode": state.confirmMode = value; break;
    case "maxIter": state.maxIterations = parseInt(value, 10) || 3; break;
    case "startFrom": state.startFrom = value; break;
    case "repositories": state.repositoryInput = value; break;
  }
}

// Route delegated clicks from the app container to the correct action.
// Inputs: a DOM click Event (uses the closest [data-act] ancestor).
// Outputs: posts messages to the host and/or updates state; returns void.
// Typical response: clicking "Run pipeline" emits a run.start message.
function onAppClick(e: Event) {
  const target = (e.target as HTMLElement)?.closest("[data-act]") as HTMLElement | null;
  if (!target) return;
  const act = target.dataset.act;
  const phaseId = target.dataset.phase;
  switch (act) {
    case "select-phase":
      if (phaseId) { state.selectedPhaseId = phaseId; render(); }
      break;
    case "run":
      startRun(state.startFrom || undefined);
      break;
    case "run-from":
      startRun(phaseId || undefined);
      break;
    case "abort":
      post({ type: "run.abort" });
      break;
    case "reset":
      post({ type: "run.reset" });
      break;
    case "open-transcript": {
      e.preventDefault();
      const sel = state.phases.find((p) => p.id === (phaseId ?? state.selectedPhaseId));
      if (sel?.transcriptPath) post({ type: "openTranscript", path: sel.transcriptPath });
      break;
    }
    case "gate-confirm": {
      const extra = (document.getElementById("gateExtra") as HTMLTextAreaElement | null)?.value ?? "";
      if (state.awaitingPhaseId) {
        post({ type: "phase.confirm", phaseId: state.awaitingPhaseId, extraInstructions: extra || undefined });
        state.awaitingPhaseId = null; state.awaitingSummary = ""; render();
      }
      break;
    }
    case "gate-reject":
      if (state.awaitingPhaseId) {
        post({ type: "phase.reject", phaseId: state.awaitingPhaseId });
        state.awaitingPhaseId = null; state.awaitingSummary = ""; render();
      }
      break;
    case "copy-output": {
      const sel = state.phases.find((p) => p.id === (phaseId ?? state.selectedPhaseId));
      const buf = sel ? state.streamBuffers[sel.id] : undefined;
      const text = sel?.summary ?? buf?.message ?? "";
      if (text) navigator.clipboard?.writeText(text).then(() => addLog("info", "Copied phase output to clipboard."), () => undefined);
      break;
    }
    case "api-toggle":
      state.api.drawerOpen = !state.api.drawerOpen;
      render();
      break;
    case "api-open": {
      e.preventDefault();
      const operation = target.dataset.operation;
      if (!operation) break;
      state.api.drawerOpen = true;
      state.api.selectedOperation = operation;
      post({ type: "api.getSchema", operation });
      render();
      break;
    }
    case "api-load": {
      const op = (document.getElementById("apiOperation") as HTMLSelectElement | null)?.value;
      if (!op) break;
      state.api.selectedOperation = op;
      post({ type: "api.getSchema", operation: op });
      break;
    }
    case "api-open-docs":
      post({ type: "api.openSwaggerUI", operation: state.api.selectedOperation ?? undefined });
      break;
    case "perm-approve-once": respondPermission("approve-once"); break;
    case "perm-approve-session": respondPermission("approve-for-session"); break;
    case "perm-reject": respondPermission("reject"); break;
    case "uin-submit": {
      if (!pendingUserInput) break;
      const choice = (document.getElementById("uinChoice") as HTMLSelectElement | null)?.value;
      const freeform = (document.getElementById("uinFreeform") as HTMLTextAreaElement | null)?.value;
      const answer = freeform || choice || "";
      post({ type: "userInput.response", id: pendingUserInput.id, answer, wasFreeform: !!freeform });
      pendingUserInput = null;
      render();
      break;
    }
    case "ondemand-impact": {
      if (!state.prompt.trim()) { addLog("warn", "Provide a requirement for impact analysis."); return; }
      post({ type: "ondemand.run", agentName: "impact", prompt: state.prompt.trim() });
      break;
    }
    case "ondemand-overview":
      post({ type: "ondemand.run", agentName: "appoverview", prompt: state.prompt.trim() || "Summarize this application." });
      break;
  }
}

// Begin a pipeline run from the given phase (or the beginning), resetting per-run state.
// Inputs: optional startFromPhase id. Outputs: clears buffers/files and posts run.start.
// Typical response: all phases reset to "pending" and a run.start message is sent.
function startRun(startFromPhase?: string) {
  const prompt = state.prompt.trim();
  if (!prompt) { addLog("warn", "Provide a requirement before running."); return; }
  const repositories = state.repositoryInput.split(/[\n,]+/).map((s) => s.trim()).filter(Boolean);
  state.streamBuffers = {};
  state.filesByPhase = {};
  state.fileRows = [];
  state.repoContext = { items: [], loading: repositories.length > 0 };
  for (const p of state.phases) { p.status = "pending"; p.summary = undefined; p.iteration = undefined; p.elapsedMs = undefined; p.approxTokens = undefined; p.transcriptPath = undefined; }
  state.runState = "running"; // immediate feedback before the host confirms
  post({ type: "run.start", prompt, model: state.defaultModel, maxIterations: state.maxIterations, confirmMode: state.confirmMode, startFromPhase, repositories });
  render();
}

function respondPermission(decision: "approve-once" | "approve-for-session" | "reject") {
  if (!pendingPermission) return;
  post({ type: "permission.response", id: pendingPermission.id, decision });
  pendingPermission = null;
  render();
}

function addLog(level: string, message: string) {
  state.logs.push({ level, message });
  render();
}

function escapeHtml(s: string): string {
  return s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!));
}

// Scroll an output pane to its newest content.
// Inputs: a DOM element. Outputs: sets scrollTop to the bottom; returns void.
// Typical response: the tool-calls <pre> shows its most recent lines.
function stickToBottom(el: Element) {
  el.scrollTop = el.scrollHeight;
}

// Scroll every streaming output pane (summary/reasoning/tools) to the bottom.
// Inputs: none. Outputs: scrolls panes in the active panel; returns void.
// Typical response: after a re-render during a run, the latest output stays visible.
function stickStreamingPanes() {
  const app = document.getElementById("app");
  if (!app) return;
  app.querySelectorAll("[data-pane]").forEach((el) => stickToBottom(el));
}

// Patch the visible streaming panes in place instead of re-rendering the whole DOM.
// Inputs: the phaseId whose buffer changed.
// Outputs: returns true when handled in place (no full render needed), false to request a render.
// Typical response: appends a tool-call line and keeps the pane scrolled to the newest entry.
function applyStreaming(phaseId: string): boolean {
  if (phaseId !== state.selectedPhaseId) return true; // off-screen phase: state already updated, no DOM work
  const buf = state.streamBuffers[phaseId];
  if (!buf) return false;
  const app = document.getElementById("app");
  if (!app) return false;
  const msgPre = app.querySelector('[data-pane="message"]');
  const reasonPre = app.querySelector('[data-pane="reasoning"]');
  const toolsPre = app.querySelector('[data-pane="tools"]');
  if (!msgPre) return false; // panel not built yet
  if ((buf.reasoning && !reasonPre) || (buf.tools.length > 0 && !toolsPre)) return false; // a new pane must be added
  const sel = state.phases.find((p) => p.id === phaseId);
  msgPre.innerHTML = renderSummaryHtml((sel && sel.summary) || buf.message || "(no output yet)");
  stickToBottom(msgPre);
  if (reasonPre) { reasonPre.textContent = buf.reasoning; stickToBottom(reasonPre); }
  if (toolsPre) { toolsPre.textContent = buf.tools.join("\n"); stickToBottom(toolsPre); }
  return true;
}

// Update the token meter and token stat in place (token events fire on every delta).
// Inputs: none (reads state.tokens). Outputs: patches token DOM nodes; returns void.
// Typical response: the header count and meter width advance without a full re-render.
function applyTokens() {
  const app = document.getElementById("app");
  if (!app) return;
  const total = state.tokens.total.toLocaleString();
  const count = app.querySelector("[data-token-count]");
  if (count) count.textContent = total;
  const fill = app.querySelector("[data-token-fill]") as HTMLElement | null;
  if (fill) fill.style.width = Math.min(100, (state.tokens.total / state.tokenCap) * 100) + "%";
  const statTok = app.querySelector("[data-stat-tokens]");
  if (statTok) statTok.textContent = total;
}

window.addEventListener("message", (e) => {
  const msg = e.data as HostToWebview;
  let needsRender = true;
  switch (msg.type) {
    case "init":
      state.workspaceName = msg.workspaceName;
      state.models = msg.models;
      state.defaultModel = msg.defaultModel;
      state.phases = msg.phases;
      state.maxIterations = msg.settings.maxIterations;
      state.confirmMode = msg.settings.confirmMode;
      state.selectedPhaseId = msg.phases[0]?.id ?? null;
      state.filesByPhase = {};
      state.fileRows = [];
      state.streamBuffers = {};
      break;
    case "models":
      state.models = msg.models;
      break;
    case "repoContext":
      state.repoContext = { items: msg.items, loading: msg.loading };
      break;
    case "api.operations":
      state.api.operations = msg.operations;
      if (!state.api.selectedOperation && msg.operations.length) {
        state.api.selectedOperation = msg.operations[0].name;
      }
      break;
    case "api.schema":
      state.api.selectedOperation = msg.operation;
      state.api.selectedSchema = msg.schema;
      break;
    case "phase.update": {
      const idx = state.phases.findIndex((p) => p.id === msg.phase.id);
      if (idx >= 0) state.phases[idx] = { ...state.phases[idx], ...msg.phase };
      else state.phases.push(msg.phase);
      for (const f of msg.phase.filesWritten ?? []) addFile(msg.phase.id, f, "write");
      break;
    }
    case "phase.delta": {
      const buf = state.streamBuffers[msg.phaseId] ?? { message: "", reasoning: "", tools: [] };
      if (msg.channel === "reasoning") buf.reasoning += msg.deltaContent;
      else buf.message += msg.deltaContent;
      state.streamBuffers[msg.phaseId] = buf;
      needsRender = !applyStreaming(msg.phaseId);
      break;
    }
    case "phase.tool": {
      const buf = state.streamBuffers[msg.phaseId] ?? { message: "", reasoning: "", tools: [] };
      buf.tools.push(`${msg.status}: ${msg.toolName}${msg.filePath ? " → " + msg.filePath : ""}`);
      state.streamBuffers[msg.phaseId] = buf;
      if (msg.status === "complete") addFile(msg.phaseId, msg.filePath, msg.toolName);
      needsRender = !applyStreaming(msg.phaseId);
      break;
    }
    case "phase.awaitingConfirmation":
      state.awaitingPhaseId = msg.phaseId;
      state.awaitingSummary = msg.summary;
      state.selectedPhaseId = msg.phaseId;
      break;
    case "tokens":
      state.tokens.total = msg.totalApprox;
      state.tokens.prompt = msg.promptApprox;
      state.tokens.completion = msg.completionApprox;
      applyTokens();
      needsRender = false;
      break;
    case "run.state":
      state.runState = msg.state;
      break;
    case "permission.request":
      pendingPermission = msg.payload;
      break;
    case "userInput.request":
      pendingUserInput = msg.payload;
      break;
    case "log":
      state.logs.push({ level: msg.level, message: msg.message });
      break;
  }
  if (needsRender) render();
});

post({ type: "ready" });
render();
