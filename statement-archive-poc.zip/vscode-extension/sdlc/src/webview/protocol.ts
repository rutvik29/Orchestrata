// Shared message protocol between the extension host and the webview.
// Purpose: provide discriminated unions for messages flowing in both directions.
// Inputs/outputs: type-only; no runtime code.
// Typical response: TypeScript narrows the `type` field for safe handling on both sides.

export type PhaseStatus =
  | "pending"
  | "running"
  | "awaiting-confirmation"
  | "passed"
  | "failed"
  | "skipped";

export interface PhaseSummary {
  id: string;
  agentName: string;
  title: string;
  status: PhaseStatus;
  iteration?: number;
  elapsedMs?: number;
  approxTokens?: number;
  summary?: string;
  transcriptPath?: string;
  filesWritten?: string[];
  /** Ids of phases this phase depends on (golden-thread / traceability edges). */
  dependsOn?: string[];
}

export interface ModelInfo {
  id: string;
  label: string;
  supportsReasoning?: boolean;
}

export interface PermissionPromptPayload {
  id: string;
  kind: string;
  toolName?: string;
  fileName?: string;
  fullCommandText?: string;
  description: string;
}

export interface UserInputPromptPayload {
  id: string;
  question: string;
  choices?: string[];
  allowFreeform: boolean;
}

// Result of loading context for one requested GitHub repository.
// Surfaced to the webview so the user can see what was (or was not) pulled in.
export interface RepoContextItem {
  id: string;
  ok: boolean;
  detail: string;
}

// API integration types
export interface ApiOperation {
  name: string;
  method: "get" | "post" | "put" | "delete";
  path: string;
  description: string;
  parameters: string[];
}

export interface ApiSchema {
  operation: string;
  requestSchema?: Record<string, unknown>;
  responseSchema?: Record<string, unknown>;
}

// extension -> webview
export type HostToWebview =
  | { type: "init"; workspaceName: string; models: ModelInfo[]; defaultModel: string; phases: PhaseSummary[]; settings: { maxIterations: number; confirmMode: string } }
  | { type: "models"; models: ModelInfo[] }
  | { type: "phase.update"; phase: PhaseSummary }
  | { type: "phase.delta"; phaseId: string; deltaContent: string; channel: "message" | "reasoning" }
  | { type: "phase.tool"; phaseId: string; toolName: string; status: "start" | "complete"; detail?: string; filePath?: string }
  | { type: "phase.awaitingConfirmation"; phaseId: string; summary: string }
  | { type: "tokens"; totalApprox: number; promptApprox: number; completionApprox: number }
  | { type: "run.state"; state: "idle" | "running" | "paused" | "aborted" | "finished" | "failed"; runId?: string }
  | { type: "permission.request"; payload: PermissionPromptPayload }
  | { type: "userInput.request"; payload: UserInputPromptPayload }
  | { type: "repoContext"; items: RepoContextItem[]; loading: boolean }
  | { type: "api.operations"; operations: ApiOperation[] }
  | { type: "api.schema"; operation: string; schema: ApiSchema }
  | { type: "log"; level: "info" | "warn" | "error"; message: string };

// webview -> extension
export type WebviewToHost =
  | { type: "ready" }
  | { type: "run.start"; prompt: string; model: string; maxIterations: number; confirmMode: string; startFromPhase?: string; repositories?: string[] }
  | { type: "run.abort" }
  | { type: "run.reset" }
  | { type: "phase.confirm"; phaseId: string; extraInstructions?: string }
  | { type: "phase.reject"; phaseId: string }
  | { type: "permission.response"; id: string; decision: "approve-once" | "approve-for-session" | "reject"; feedback?: string }
  | { type: "userInput.response"; id: string; answer: string; wasFreeform: boolean }
  | { type: "openTranscript"; path: string }
  | { type: "api.openSwaggerUI"; operation?: string }
  | { type: "api.getSchema"; operation: string }
  | { type: "ondemand.run"; agentName: "impact" | "appoverview"; prompt: string };
