// Extension entry point.
// Purpose: register the SDLC: Open Pipeline command and dispose resources on shutdown.
// Inputs: vscode.ExtensionContext from VS Code.
// Outputs: registers commands; returns void from activate/deactivate.
// Typical response: invoking the command opens the SDLC Pipeline webview panel.

import * as vscode from "vscode";
import { PipelinePanel } from "./webview/PipelinePanel";

export function activate(context: vscode.ExtensionContext) {
  context.subscriptions.push(
    vscode.commands.registerCommand("sdlc.openPanel", async () => {
      const folders = vscode.workspace.workspaceFolders;
      if (!folders || folders.length === 0) {
        vscode.window.showErrorMessage("SDLC Pipeline requires an open workspace folder.");
        return;
      }
      const root = folders[0].uri.fsPath;
      await PipelinePanel.createOrShow(context, root);
    })
  );
}

export function deactivate() { /* PipelinePanel disposes its own session on panel close */ }
