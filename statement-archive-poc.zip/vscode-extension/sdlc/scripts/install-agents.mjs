#!/usr/bin/env node

import fs from "fs/promises";
import os from "os";
import path from "path";
import { fileURLToPath } from "url";

const scriptDir = path.dirname(fileURLToPath(import.meta.url));
const repoRoot = path.resolve(scriptDir, "..", "..");
const defaultSourceDir = path.join(repoRoot, "agents");
const defaultTargetDir = path.join(os.homedir(), ".copilot", "agents");

/**
 * Parse installer CLI flags.
 * Purpose: convert `node install-agents.mjs` arguments into source/target options.
 * Inputs: argv entries after the Node executable and script path.
 * Outputs: an options object with optional `sourceDir`, optional `targetDir`, `dryRun`, and `help`.
 * Typical response example: `{ dryRun: true, help: false, targetDir: "C:\\Users\\me\\.copilot\\agents" }` for `--dry-run --target C:\\Users\\me\\.copilot\\agents`.
 */
function parseArgs(argv) {
  const options = {
    sourceDir: undefined,
    targetDir: undefined,
    dryRun: false,
    help: false
  };

  for (let index = 0; index < argv.length; index += 1) {
    const arg = argv[index];
    if (arg === "-h" || arg === "--help") {
      options.help = true;
      continue;
    }
    if (arg === "--dry-run") {
      options.dryRun = true;
      continue;
    }
    if (arg === "--source") {
      const value = argv[index + 1];
      if (!value) throw new Error("Missing value after --source.");
      options.sourceDir = value;
      index += 1;
      continue;
    }
    if (arg.startsWith("--source=")) {
      options.sourceDir = arg.slice("--source=".length);
      continue;
    }
    if (arg === "--target") {
      const value = argv[index + 1];
      if (!value) throw new Error("Missing value after --target.");
      options.targetDir = value;
      index += 1;
      continue;
    }
    if (arg.startsWith("--target=")) {
      options.targetDir = arg.slice("--target=".length);
      continue;
    }
    throw new Error(`Unknown argument: ${arg}`);
  }

  return options;
}

/**
 * Install all chat-agent definition files into a `.copilot/agents` directory.
 * Purpose: copy every `*.agent.md` file from the repository's `agents/` folder into the target Copilot agent folder.
 * Inputs: reads `process.argv`, the local filesystem, and optional `--source`, `--target`, and `--dry-run` flags.
 * Outputs: a copied agent set on disk, or a dry-run log when `--dry-run` is used.
 * Typical response example: `Installed 12 agent file(s) to C:\\Users\\me\\.copilot\\agents.`
 */
async function main() {
  const options = parseArgs(process.argv.slice(2));
  if (options.help) {
    console.log([
      "Usage: node scripts/install-agents.mjs [--source <dir>] [--target <dir>] [--dry-run]",
      "",
      "Defaults:",
      `  source: ${defaultSourceDir}`,
      `  target: ${defaultTargetDir}`,
      "",
      "Examples:",
      "  node scripts/install-agents.mjs",
      "  node scripts/install-agents.mjs --dry-run",
      "  node scripts/install-agents.mjs --target C:\\Users\\me\\.copilot\\agents",
      ""
    ].join("\n"));
    return;
  }

  const sourceDir = path.resolve(options.sourceDir ?? defaultSourceDir);
  const targetDir = path.resolve(options.targetDir ?? defaultTargetDir);

  const sourceStat = await fs.stat(sourceDir).catch(() => null);
  if (!sourceStat || !sourceStat.isDirectory()) {
    throw new Error(`Source directory not found: ${sourceDir}`);
  }

  if (sourceDir === targetDir) {
    throw new Error("Source and target directories must be different.");
  }

  const entries = await fs.readdir(sourceDir, { withFileTypes: true });
  const agentFiles = entries
    .filter((entry) => entry.isFile() && entry.name.endsWith(".agent.md"))
    .map((entry) => entry.name)
    .sort((left, right) => left.localeCompare(right));

  if (agentFiles.length === 0) {
    throw new Error(`No .agent.md files found in ${sourceDir}`);
  }

  if (options.dryRun) {
    for (const fileName of agentFiles) {
      console.log(`[dry-run] ${path.join(sourceDir, fileName)} -> ${path.join(targetDir, fileName)}`);
    }
    console.log(`Dry run complete: ${agentFiles.length} agent file(s) would be installed to ${targetDir}.`);
    return;
  }

  await fs.mkdir(targetDir, { recursive: true });

  for (const fileName of agentFiles) {
    await fs.copyFile(path.join(sourceDir, fileName), path.join(targetDir, fileName));
  }

  console.log(`Installed ${agentFiles.length} agent file(s) to ${targetDir}.`);
}

main().catch((error) => {
  const message = error instanceof Error ? error.message : String(error);
  console.error(`[install-agents] ${message}`);
  process.exitCode = 1;
});