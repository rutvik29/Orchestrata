// Build script for the SDLC Assistant extension.
// Purpose: bundle the extension (CJS, Node target) and the webview UI (IIFE, browser target).
// Inputs: none (reads src/ tree). Outputs: dist/extension.js and media/webview.js.
// Typical response: prints "build complete" or rebuild events when run with --watch.

import esbuild from "esbuild";

const watch = process.argv.includes("--watch");

const extensionConfig = {
  entryPoints: ["src/extension.ts"],
  bundle: true,
  outfile: "dist/extension.js",
  platform: "node",
  target: "node18",
  format: "cjs",
  sourcemap: true,
  external: ["vscode"],
  logLevel: "info"
};

const webviewConfig = {
  entryPoints: ["src/webview/main.ts"],
  bundle: true,
  outfile: "media/webview.js",
  platform: "browser",
  target: "es2022",
  format: "iife",
  sourcemap: true,
  logLevel: "info"
};

async function run() {
  if (watch) {
    const extCtx = await esbuild.context(extensionConfig);
    const webCtx = await esbuild.context(webviewConfig);
    await Promise.all([extCtx.watch(), webCtx.watch()]);
    console.log("watching...");
  } else {
    await Promise.all([esbuild.build(extensionConfig), esbuild.build(webviewConfig)]);
    console.log("build complete");
  }
}

run().catch((err) => {
  console.error(err);
  process.exit(1);
});
