# SDLC Assistant User Guide

SDLC Assistant is a VS Code extension that runs a phased software-delivery workflow inside your workspace. It uses GitHub Copilot for the model session, shows progress in a webview, and records run transcripts for later review.

## What You Need

### Required
- VS Code 1.90 or later.
- An open workspace folder. The extension does not start without one.
- GitHub Copilot CLI installed and authenticated with a Copilot-enabled GitHub account. The CLI is an external prerequisite (not bundled with the extension). The extension auto-detects the platform-appropriate executable (`copilot.exe` on Windows, `copilot` on macOS/Linux) from the `COPILOT_CLI_PATH` environment variable, well-known install locations (such as `%LOCALAPPDATA%\GitHubCopilotCLI` on Windows), or your `PATH`. If it is installed elsewhere, set the `sdlc.copilot.cliPath` setting.
- SDLC agent persona files installed in `.copilot/agents` either in your home directory or in the current workspace.

### Required agent personas
The main pipeline expects these personas to be available:
- `doc-processor`
- `ba-analyst`
- `architect`
- `dev`
- `codereview`
- `security`
- `performance`
- `qa`
- `devops`

### Optional agent personas
Install these if you want the on-demand actions in the panel:
- `impact`
- `appoverview`

### Optional dependencies
- Node.js 18 or later, only if you want to run the included installation script or build the extension from source.
- GitHub repository access, only if you want the extension to pull optional repository context from GitHub.

The extension does not require a separate server, database, or MCP service.

## Install the Agent Personas

The repository includes a helper script that copies the provided personas into your Copilot agent folder:

```powershell
node .\scripts\install-agents.mjs
```

This installs the files from `agents/*.agent.md` into `~/.copilot/agents` so the extension can load them.

If you prefer, you can copy the persona files into `~/.copilot/agents` yourself.

## Open and Run the Extension

1. Open the workspace you want the pipeline to work on.
2. Run the command `SDLC Assistant: Open Pipeline`.
3. Enter the request or prompt that should drive the run.
4. Choose a model and review the confirmation settings if you want to change them.
5. Optionally add GitHub repository URLs if you want the extension to load extra repository context.
6. Start the run and respond to any confirmation, permission, or input prompts that appear.

If the extension cannot find a workspace folder, it will show an error instead of starting.

## What the Extension Does

The pipeline usually runs through these phases:

1. Document processing
2. Business analysis
3. Architecture design
4. Development
5. Code review
6. Security review
7. Performance review
8. Quality assurance
9. DevOps and deployment

You can also run the `impact` and `appoverview` personas on demand from the panel.

The panel shows the run timeline, phase output, traceability, generated files, transcript links, and an approximate token meter. It also lets you open a transcript from the run history.

## Confirmation and Permissions

The extension may pause between phases depending on your settings:

- `never` — never ask for phase confirmation.
- `high-impact-only` — pause after Architecture and Code Review.
- `always` — pause after every phase.

During a run, the extension may also ask for permission before it reads files, writes files, runs shell commands, or calls tools. This is expected and is part of the safety model.

## Settings

- `sdlc.copilot.defaultModel` — default model id used for runs, for example `gpt-5`.
- `sdlc.copilot.cliPath` — optional absolute path to the Copilot CLI executable. Leave empty to auto-detect across platforms; set it if the CLI is installed in a non-standard location.
- `sdlc.pipeline.maxReviewIterations` — maximum number of dev and code-review loops before the pipeline moves on.
- `sdlc.pipeline.confirmBetweenPhases` — when the extension pauses for confirmation.
- `sdlc.github.apiBaseUrl` — GitHub API URL used for optional repository context loading. Set this to your GitHub Enterprise API URL if needed.

## Output and Artifacts

Run transcripts are saved under:

```text
sdlc/.sdlc-runs/<runId>/
  manifest.json
  phase-*.md
  phase-*.json
```

Files created by the pipeline are written into their normal workspace locations, for example documentation folders or source folders, depending on the task.

## Troubleshooting

- No agents found: install the persona files into `.copilot/agents` and try again.
- Copilot CLI missing or not signed in: install the CLI and authenticate before starting the pipeline. If it is installed but not detected, set `sdlc.copilot.cliPath` to the full path of the executable (or set the `COPILOT_CLI_PATH` environment variable).
- GitHub repository context fails to load: check your GitHub sign-in and, for enterprise repos, the `sdlc.github.apiBaseUrl` setting.
- The command does nothing: make sure a workspace folder is open before launching the pipeline.
