# API Integration Quickstart

## 5-Minute Setup

### Step 1: Start the API Wrapper

In the `sdlc` folder, run:

```bash
npm run api:serve
```

This:
- Installs `api-wrapper/` dependencies
- Starts Express on `http://localhost:3000`
- Serves Swagger spec at `/swagger.json`

**Expected output:**
```
[API Wrapper] Statements API Wrapper running on http://localhost:3000
[API Wrapper] Swagger spec available at http://localhost:3000/swagger.json
```

### Step 2: Verify the Wrapper

In another terminal, check the API is running:

```bash
curl http://localhost:3000/health
```

**Expected response:**
```json
{
  "status": "success",
  "statusCode": 200,
  "message": "Service is healthy",
  "data": {
    "status": "healthy",
    "soapClientReady": false,
    "uptime": 12.345
  }
}
```

View the Swagger spec:

```bash
curl http://localhost:3000/swagger.json | head -20
```

You should see the OpenAPI 3.0.0 document structure.

### Step 3: Build the SDLC Extension

In the `sdlc` folder:

```bash
npm install
npm run build
```

### Step 4: Open SDLC Assistant in VS Code

1. Open VS Code and open the workspace folder (`sdlc-assistant-2.0-src/sdlc`)
2. Run the command: **SDLC Assistant: Open Pipeline**
3. The panel should load without errors

### Step 5: Run a Sample Pipeline

1. In the SDLC panel, enter a prompt:
   ```
   Build a REST API wrapper for authentication flow using clientId, userId, and token.
   ```

2. Select a model and click **Start Run**

3. As phases execute, watch the output for parameter references (clientId, token, etc.)

4. **Look for hyperlinks:** Phase output should contain text like:
   ```
   [clientId→API](/swagger/authenticate)
   ```

### Step 6: Inspect Swagger UI (when webview integration is complete)

Click any hyperlink in phase output to open the Swagger UI panel showing:
- Operation details (path, method, description)
- Request schema (parameters and types)
- Response schema (expected output format)

## Testing API Endpoints

### Test Authentication

```bash
curl -X POST http://localhost:3000/api/authenticate \
  -H "Content-Type: application/json" \
  -d '{
    "clientId": "TEST123",
    "userId": "test@example.com",
    "password": "testpass",
    "account": "ACC001"
  }'
```

**Expected response:**
```json
{
  "status": "success",
  "statusCode": 200,
  "data": {
    "token": "mock-token-1625000000000",
    "expiresIn": 3600,
    "userId": "test@example.com"
  }
}
```

### Test List Statements

First, get a token from the authenticate endpoint above. Then:

```bash
curl "http://localhost:3000/api/list?token=mock-token-1625000000000"
```

### Get Operation Schema

```bash
curl http://localhost:3000/api/schema/authenticate
```

## Checking API Registry Status

The API registry is initialized when the SDLC pipeline runs. To verify it loaded correctly:

1. Check the browser console (F12) in VS Code's webview
2. Look for logs like:
   ```
   [ApiRegistry] Initialized with 4 operations
   ```

3. Or check the extension console:
   ```
   [Orchestrator] API registry initialized
   ```

## Troubleshooting

### Issue: `Error: Failed to fetch Swagger spec`

**Cause:** API wrapper not running or wrong URL

**Fix:**
```bash
# Terminal 1: Start the wrapper
npm run api:serve

# Terminal 2: Verify it's running
curl http://localhost:3000/swagger.json
```

### Issue: Links not appearing in phase output

**Cause:** API registry not initialized or scan didn't find parameters

**Check:**
1. Verify wrapper is running
2. Confirm phase output contains parameter names (e.g., "clientId", "token")
3. Check browser console for errors

### Issue: Swagger UI panel not opening

**Cause:** Webview integration not yet complete or link malformed

**Workaround:**
- Manually visit: `http://localhost:3000/swagger.json` in your browser
- Use Swagger Editor: https://editor.swagger.io (paste the spec)

## Next: Full Integration

These steps verify the backend pieces are working. Next phases will add:

1. **Webview UI Enhancements** — Swagger UI panel, styled links
2. **Context Menu** — Quick-launch Swagger UI from toolbar
3. **Phase Injection** — Automatic link insertion during pipeline runs
4. **Error Handling** — Graceful fallback if wrapper unavailable

See [API_INTEGRATION.md](API_INTEGRATION.md) for architecture details.

---

## Cleanup

To stop the API wrapper:

```bash
Ctrl+C  # In the terminal where `npm run api:serve` is running
```

To remove API wrapper files (if needed):

```bash
rm -rf api-wrapper/node_modules
```
