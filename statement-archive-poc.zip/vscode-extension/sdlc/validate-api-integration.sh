#!/bin/bash
# Validation script for Statements API integration
# Purpose: Verify all components are installed and working
# Inputs: none (runs locally)
# Outputs: Test results summary
# Typical response: "✅ All checks passed!" or lists failed checks

set -e

echo "════════════════════════════════════════════════════════════════"
echo "SDLC Assistant - Statements API Integration Validation"
echo "════════════════════════════════════════════════════════════════"
echo ""

# Track results
CHECKS_PASSED=0
CHECKS_FAILED=0
WARNINGS=0

check_file() {
  local file=$1
  local desc=$2
  if [ -f "$file" ]; then
    echo "✅ $desc"
    ((CHECKS_PASSED++))
  else
    echo "❌ $desc (missing: $file)"
    ((CHECKS_FAILED++))
  fi
}

check_dir() {
  local dir=$1
  local desc=$2
  if [ -d "$dir" ]; then
    echo "✅ $desc"
    ((CHECKS_PASSED++))
  else
    echo "❌ $desc (missing: $dir)"
    ((CHECKS_FAILED++))
  fi
}

echo "1. Checking file structure..."
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

check_file "swagger/statements-api.openapi.json" "OpenAPI Specification"
check_file "api-wrapper/server.js" "REST Wrapper Service"
check_file "api-wrapper/package.json" "API Wrapper Dependencies"
check_file "api-wrapper/.env.example" "API Configuration Template"
check_file "src/context/apiRegistry.ts" "API Registry Module"
check_file "API_INTEGRATION.md" "Integration Documentation"
check_file "API_QUICKSTART.md" "Quick Start Guide"
check_file "IMPLEMENTATION_SUMMARY.md" "Implementation Summary"

echo ""
echo "2. Checking code modifications..."
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Check if orchestrator imports apiRegistry
if grep -q "apiRegistry" src/pipeline/orchestrator.ts; then
  echo "✅ Orchestrator imports apiRegistry"
  ((CHECKS_PASSED++))
else
  echo "❌ Orchestrator missing apiRegistry import"
  ((CHECKS_FAILED++))
fi

# Check if protocol has API types
if grep -q "ApiOperation\|ApiSchema" src/webview/protocol.ts; then
  echo "✅ Protocol has API types"
  ((CHECKS_PASSED++))
else
  echo "❌ Protocol missing API types"
  ((CHECKS_FAILED++))
fi

# Check if insertQueryAndRule has API comments
if grep -q "API Reference" insertQueryAndRule.js; then
  echo "✅ insertQueryAndRule has API reference comments"
  ((CHECKS_PASSED++))
else
  echo "❌ insertQueryAndRule missing API comments"
  ((CHECKS_FAILED++))
fi

# Check if package.json has api scripts
if grep -q "api:serve\|api:gen-swagger" package.json; then
  echo "✅ package.json has API scripts"
  ((CHECKS_PASSED++))
else
  echo "❌ package.json missing API scripts"
  ((CHECKS_FAILED++))
fi

echo ""
echo "3. Checking OpenAPI Specification..."
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Check if swagger spec is valid JSON
if jq . swagger/statements-api.openapi.json > /dev/null 2>&1; then
  echo "✅ OpenAPI spec is valid JSON"
  ((CHECKS_PASSED++))
else
  echo "❌ OpenAPI spec is invalid JSON"
  ((CHECKS_FAILED++))
fi

# Check required endpoints
if grep -q '"/api/authenticate"' swagger/statements-api.openapi.json; then
  echo "✅ /api/authenticate endpoint defined"
  ((CHECKS_PASSED++))
else
  echo "❌ /api/authenticate endpoint missing"
  ((CHECKS_FAILED++))
fi

if grep -q '"/api/list"' swagger/statements-api.openapi.json; then
  echo "✅ /api/list endpoint defined"
  ((CHECKS_PASSED++))
else
  echo "❌ /api/list endpoint missing"
  ((CHECKS_FAILED++))
fi

if grep -q '"/api/list-dynamic"' swagger/statements-api.openapi.json; then
  echo "✅ /api/list-dynamic endpoint defined"
  ((CHECKS_PASSED++))
else
  echo "❌ /api/list-dynamic endpoint missing"
  ((CHECKS_FAILED++))
fi

if grep -q '"/api/create-pdf"' swagger/statements-api.openapi.json; then
  echo "✅ /api/create-pdf endpoint defined"
  ((CHECKS_PASSED++))
else
  echo "❌ /api/create-pdf endpoint missing"
  ((CHECKS_FAILED++))
fi

echo ""
echo "4. Checking API Wrapper..."
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Check if server.js has required methods
if grep -q "app.post.*authenticate" api-wrapper/server.js; then
  echo "✅ Authenticate endpoint implemented"
  ((CHECKS_PASSED++))
else
  echo "❌ Authenticate endpoint missing"
  ((CHECKS_FAILED++))
fi

if grep -q "app.get.*\/list" api-wrapper/server.js; then
  echo "✅ List endpoint implemented"
  ((CHECKS_PASSED++))
else
  echo "❌ List endpoint missing"
  ((CHECKS_FAILED++))
fi

if grep -q "loadSwaggerSpec" api-wrapper/server.js; then
  echo "✅ Swagger spec loading implemented"
  ((CHECKS_PASSED++))
else
  echo "❌ Swagger spec loading missing"
  ((CHECKS_FAILED++))
fi

if grep -q "successResponse\|errorResponse" api-wrapper/server.js; then
  echo "✅ Response wrappers implemented"
  ((CHECKS_PASSED++))
else
  echo "❌ Response wrappers missing"
  ((CHECKS_FAILED++))
fi

echo ""
echo "5. Checking API Registry..."
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Check if apiRegistry has required methods
if grep -q "initialize()" src/context/apiRegistry.ts; then
  echo "✅ initialize() method present"
  ((CHECKS_PASSED++))
else
  echo "❌ initialize() method missing"
  ((CHECKS_FAILED++))
fi

if grep -q "scanAndLinkify" src/context/apiRegistry.ts; then
  echo "✅ scanAndLinkify() method present"
  ((CHECKS_PASSED++))
else
  echo "❌ scanAndLinkify() method missing"
  ((CHECKS_FAILED++))
fi

if grep -q "findOperationByParameter" src/context/apiRegistry.ts; then
  echo "✅ findOperationByParameter() method present"
  ((CHECKS_PASSED++))
else
  echo "❌ findOperationByParameter() method missing"
  ((CHECKS_FAILED++))
fi

if grep -q "buildParameterMapping" src/context/apiRegistry.ts; then
  echo "✅ buildParameterMapping() method present"
  ((CHECKS_PASSED++))
else
  echo "❌ buildParameterMapping() method missing"
  ((CHECKS_FAILED++))
fi

echo ""
echo "6. Checking Documentation..."
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Check documentation sections
if grep -q "Architecture\|REST API Endpoints" API_INTEGRATION.md; then
  echo "✅ API_INTEGRATION.md has required sections"
  ((CHECKS_PASSED++))
else
  echo "❌ API_INTEGRATION.md missing sections"
  ((CHECKS_FAILED++))
fi

if grep -q "5-Minute Setup\|Quickstart" API_QUICKSTART.md; then
  echo "✅ API_QUICKSTART.md has setup guide"
  ((CHECKS_PASSED++))
else
  echo "❌ API_QUICKSTART.md missing setup"
  ((CHECKS_FAILED++))
fi

if grep -q "IMPLEMENTATION\|COMPLETE" IMPLEMENTATION_SUMMARY.md; then
  echo "✅ IMPLEMENTATION_SUMMARY.md present"
  ((CHECKS_PASSED++))
else
  echo "❌ IMPLEMENTATION_SUMMARY.md missing"
  ((CHECKS_FAILED++))
fi

echo ""
echo "════════════════════════════════════════════════════════════════"
echo "VALIDATION RESULTS"
echo "════════════════════════════════════════════════════════════════"
echo ""
echo "✅ Checks Passed: $CHECKS_PASSED"
echo "❌ Checks Failed: $CHECKS_FAILED"
echo ""

if [ $CHECKS_FAILED -eq 0 ]; then
  echo "🎉 All validation checks passed!"
  echo ""
  echo "Next steps:"
  echo "  1. npm install (if not done)"
  echo "  2. npm run api:serve  (start API wrapper in one terminal)"
  echo "  3. npm run build      (build extension)"
  echo "  4. Open VS Code and run 'SDLC Assistant: Open Pipeline'"
  echo "  5. Run a pipeline and watch for hyperlinked parameters"
  echo ""
  exit 0
else
  echo "⚠️  $CHECKS_FAILED validation checks failed."
  echo "Please review the failed items above and fix them."
  exit 1
fi
