module.exports = {
	PACE_APP_ROLE: "app/PACE_BPM_User",
	VIEW_DOCUMENT_QUERY_ID: "pace-viewdocument",
	WORKSPACE_QUERY_ID: "pace-workspace",
	WORKSPACE_COUNT_QUERY_ID: "pace-workspace-count",
	REPORT_WORKFLOW_QUERY_ID: "pace-report-workflow",
	PACE_REPORT_WORKFLOWHISTORY_ID: "pace-report-workflowHistory",

	EXCLUDED_DOCUMENTS_CREATION: [
		{
			documentType: "NPAA Requests",
			documentName: "Entity Documents"
		},
		{
			documentType: "NPAA Requests",
			documentName: "E-mail Correction"
		}
	],
	ERROR_CODE: {
		301: {
			title: "Internal Error",
			statusCode: "500",
			detail: "",
		},
		400: {
			title: "Bad Request",
			statusCode: "400",
			detail: "",
		},
		401: {
			title: "Unauthorized",
			statusCode: "401",
			detail: "",
		},
		500: {
			title: "Internal Error",
			statusCode: "500",
			detail: "",
		},
	},
	LOB: "PBB",
	SYSTEM: "SYSTEM",
	DOCUMENT_STATUS: {
		Y: "Verified",
		N: "Not Verified",
	},
	WORKFLOW_STATUS: {
		NEW: "STATUS_NEW",
		PENDING: "STATUS_PENDING",
		IN_PROGRESS: "STATUS_INPROGRESS",
		COMPLETED: "STATUS_COMPLETED",
	},
	WORKFLOW_HISTORY_ACTION: {
		PENDING: "Pending",
		ESCALATED: "Escalated",
		COMPLETED: "Completed",
		CANCELLED: "Cancelled",
		CLOSED: "Closed",
		IN_PROGRESS: "In Progress",
		SECONDARY_REVIEW: "Secondary Review",
		SECONDARY_REVIEW_IN_PROCESS: "Secondary Review In Process",
		COMMENT: "Added comment",
		REASSIGN: "Re-assign",
	},
	LIFECYCLE_STATUS: {
		NEW: "New",
		PENDING: "Pending",
		ESCALATED: "Escalated",
		ESCALATION_IN_PROCESS: "Escalation in Process",
		IN_PROCESS: "In Process",
		SECONDARY_REVIEW: "Secondary Review",
		SECONDARY_REVIEW_IN_PROCESS: "Secondary Review in Process",
		COMPLETED: "Completed",
		CLOSED: "Closed",
	},
	PROCESS_NAME: "PACE",
	WORKFLOW_TYPE: "PACE",
	HISTORY_EVENT_TYPE: {
		INIT: "INIT",
		COMMENT: "COMMENT",
		NEW: "NEW",
		UPDATE: "UPDATE",
		ASSIGN: "ASSIGN",
	},
	UI_USER_ACTIONS: {
		INIT: "init",
		PEND: "pend",
		ESCALATE: "escalate",
		SECONDARY_REVIEW: "secondaryReview",
		REASSIGN: "reassign",
		CLOSE: "close",
		COMPLETE: "complete",
		COMMENT: "comment",
	},

	REASSIGN_USER: "reassignUser",
	REASSIGN: "reassign",

	REPORT_ACTION: "report",
	USER_REPORT_USER_ROLE: "Report Viewer (Spotfire)",
	GROUP: "Group",
	REPORT_VIEWER_KEY: "ReportViewer(Spotfire)",
	REPORT_VIEWER: "Report Viewer (Spotfire)",
	USER_AUDIT_VIEWER_KEY: "UserAuditReportViewer",
	USER_AUDIT_VIEWER: "User Audit Report Viewer",

	ACCESS_NOT_ALLOWE: "NA",
	ACCESS_READ_WRITE: "RW",

	DOC_TYPE_PROCESSING_AREA_MAP: [
		{
			documentType: "W-9 Documents",
			documentName: "W-9",
			processingArea: "Product Accounting",
		},
		{
			documentType: "HSA",
			documentName: "HSA change / Designation of Beneficiary",
			processingArea: "IRA/HSA",
		},
		{
			documentType: "HSA",
			documentName: "HSA Applications",
			processingArea: "IRA/HSA",
		},
		{
			documentType: "HSA",
			documentName: "HSA Calculation Worksheet",
			processingArea: "IRA/HSA",
		},

		{
			documentType: "HSA Miscellaneous",
			documentName: "HSA Contribution Instructions",
			processingArea: "IRA/HSA",
		},
		{
			documentType: "HSA Miscellaneous",
			documentName: "HSA Request for Transfer/Rollover Review",
			processingArea: "IRA/HSA",
		},
		{
			documentType: "HSA Miscellaneous",
			documentName: "HSA Distribution Instructions",
			processingArea: "IRA/HSA",
		},
		{
			documentType: "Retirement Documents",
			documentName: "70 1/2 Election",
			processingArea: "IRA/HSA",
		},
		{
			documentType: "Retirement Documents",
			documentName: "Application",
			processingArea: "IRA/HSA",
		},
		{
			documentType: "Retirement Documents",
			documentName: "Auto Distribution for Set Dollar Amount",
			processingArea: "IRA/HSA",
		},
		{
			documentType: "Retirement Documents",
			documentName: "Beneficiary Organizer",
			processingArea: "IRA/HSA",
		},
		{
			documentType: "Retirement Documents",
			documentName: "Contribution",
			processingArea: "IRA/HSA",
		},
		{
			documentType: "Retirement Documents",
			documentName: "Designation or Change of Beneficiary",
			processingArea: "IRA/HSA",
		},
		{
			documentType: "Retirement Documents",
			documentName: "Distribution",
			processingArea: "IRA/HSA",
		},
		{
			documentType: "Retirement Documents",
			documentName: "Election of Payment by Beneficiary",
			processingArea: "IRA/HSA",
		},
		{
			documentType: "Retirement Documents",
			documentName: "Internal Transfer",
			processingArea: "IRA/HSA",
		},
		{
			documentType: "Retirement Documents",
			documentName: "IRA Excess Contributions Worksheet",
			processingArea: "IRA/HSA",
		},
		{
			documentType: "Retirement Documents",
			documentName: "IRA External Transfer",
			processingArea: "IRA/HSA",
		},
		{
			documentType: "Retirement Documents",
			documentName: "IRA Fee Maintenance",
			processingArea: "IRA/HSA",
		},
		{
			documentType: "Retirement Documents",
			documentName: "IRA Recharacterization Notice",
			processingArea: "IRA/HSA",
		},
		{
			documentType: "Retirement Documents",
			documentName: "IRA Rollover Review",
			processingArea: "IRA/HSA",
		},
		{
			documentType: "Retirement Documents",
			documentName: "Retirement Plan Updates",
			processingArea: "IRA/HSA",
		},
		{
			documentType: "Retirement Documents",
			documentName: "Withholding",
			processingArea: "IRA/HSA",
		},
		{
			documentType: "NPAA Requests",
			documentName: "Entity Documents",
			processingArea: "Quality Assurance new Account Audit",
		},
		{
			documentType: "All Other Deposit Docs",
			documentName: "Dormant Maintenance",
			processingArea: "Account Maintenance",
		},
		{
			documentType: "All Other Deposit Docs",
			documentName: "All Other Deposit Docs",
			processingArea: "Account Maintenance",
		},
		{
			documentType: "All Other Deposit Docs",
			documentName: "Safe Deposit Box Contracts",
			processingArea: "Branch Support",
		},
		{
			documentType: "All Other Deposit Docs",
			documentName: "Safe Deposit Box Maintenance",
			processingArea: "Branch Support",
		},
		{
			documentType: "All Other Deposit Docs",
			documentName: "Cashiers Checks and Money Order Void Forms",
			processingArea: "IC P&C PO US II",
		},
		{
			documentType: "All Other Deposit Docs",
			documentName: "Stop Payment Form - Money Order and Official Check",
			processingArea: "IC P&C PO US II",
		},
		{
			documentType: "All Other Deposit Docs",
			documentName: "Stop Payment Indemnity Agreement",
			processingArea: "IC P&C PO US II",
		},
		{
			documentType: "All Other Deposit Docs",
			documentName: "Stop Payments and Voids for Official Checks",
			processingArea: "IC P&C PO US II",
		},
		{
			documentType: "Wire Transfers",
			documentName: "Wire Agreements",
			processingArea: "Wire Support",
		},
		{
			documentType: "Wire Transfers",
			documentName: "Wire Authorized Caller Schedule",
			processingArea: "Wire Support",
		},
		{
			documentType: "Wire Transfers",
			documentName: "Wire Domestic Repetitive",
			processingArea: "Wire Support",
		},
		{
			documentType: "Wire Transfers",
			documentName: "Wire International Repetitive",
			processingArea: "Wire Support",
		},
		{
			documentType: "Wire Transfers",
			documentName: "Wire Maintenance Request",
			processingArea: "Wire Support",
		},
		{
			documentType: "NPAA Requests",
			documentName: "E-mail Correction",
			processingArea: "Quality Assurance new Account Audit",
		},
		{
			documentType: "W-8 Documents",
			documentName: "W-8",
			processingArea: "Product Accounting",
		},
		{
			documentType: "Check Collection Documents",
			documentName: "Collection Form",
			processingArea: "Account Maintenance",
		},
	],
	REPORT_WORKFLOW_QUERY:
		"select * from workflow where process = 'PACE' and last_update_date >= '%startDate%' and last_update_date < '%endDate%' ORDER BY last_update_date DESC",

	VIEW_DOCUMENT_QUERY:
		"select * from workflow where %AccessQuery% process = 'PACE' and metadata->>'epochCreateDate'::int8 >= %startDate% and metadata->>'epochCreateDate'::int8 <= %endDate% and (metadata->>'taskId' != '%excludeTaskId%' or metadata->>'taskId' ISNULL) and metadata->>'lifecycleStatus' ILIKE '%status%' and metadata->>'documentName' ILIKE '%documentName%' and metadata->>'documentType' ILIKE '%documentType%' and (metadata->>'accountNumber' = '%accountNumber%' or metadata->>'accountNumber' ILIKE '%accountNumber%' or metadata->>'accountNumber' IN '%accountNumberMulti%') and (metadata->>'scannedDate'= '%scannedDate%' or metadata->>'scannedDate' ILIKE '%scannedDate%') and metadata->>'priority' ILIKE '%priority%' and metadata->>'customerName' ILIKE '%customerName%' and metadata->>'BUCNumber' ILIKE '%BUCNumber%' and owner ILIKE '%owner%' order by create_date desc",

	WORKSPACE_QUERY:
		'select * from task where %accessQuery% AND %customQuery% AND process = \'PACE\' AND (NOT (assignment @> \'[{"id":"%userAppRole%","access":"NA"}]\')) %orderBy%',

	WORKSPACE_COUNT_QUERY:
		'select count(id) as id from task where %accessQuery% AND %customQuery% AND process = \'PACE\' AND (NOT (assignment @> \'[{"id":"%userAppRole%","access":"NA"}]\'))',
	PACE_RULEENGINE_RULES: [
		'{"conditions":{"priority":1,"all":[{"operator":"contains","value":"OFFICEDOMAIN_ROL-PACE_BPM_User","fact":"adRole"}]},"priority":1,"event":{"type":"PACE_BPM_User","params":{"appRole":"app/PACE_BPM_User"}}}',
		'{"conditions":{"priority":1,"all":[{"operator":"contains","value":"OFFICEDOMAIN_ROL-PACE_BPM_Admin","fact":"adRole"}]},"priority":1,"event":{"type":"PACE_BPM_User","params":{"appRole":"app/PACE_BPM_Admin"}}}',
		//'{"conditions": {"priority": 1,"all": [{"operator": "contains","value": "OFFICEDOMAIN_ROL-PACE_BPM_User","fact": "adRole"},{"fact": "attributes","path": "$.PACE_Application","operator": "equal","value": "true"},{"fact": "attributes","path": "$.owning_groups.length","operator": "greaterThan","value": 0}]},"priority": 1,"event": {"type": "PACE_All_GroupRoles","params": {"appRole": {"pattern": "app/PACE_$","fact": "attributes","path": "$.owning_groups"}}}}',
		'{"conditions": {"priority": 1,"all": [{"operator": "contains","value": "OFFICEDOMAIN_ROL-PACE_BPM_User","fact": "adRole"},{"fact": "attributes","path": "$.PACE_Application","operator": "equal","value": "true"},{"fact": "attributes","path": "$.pace_group_roles.length","operator": "greaterThan","value": 0}]},"priority": 1,"event": {"type": "PACE_All_GroupRoles","params": {"appRole": {"pattern": "app/PACE_$","fact": "attributes","path": "$.pace_group_roles"}}}}',
	],

	WORKFLOW_ENCRYTION: {
		ProcessName: "LOB/PBBUS",
		EncryptionKeyStores: {
			LeftSecretId: process.env.WORKFLOW_ENCRYPTION_LEFTSECRET_ID,
			LeftSecretRoleArn: process.env.WORKFLOW_ENCRYPTION_LEFTSECRET_ROLEARN,
			RightSecretId: process.env.WORKFLOW_ENCRYPTION_RIGHTSECRET_ID,
			RightSecretRoleArn: process.env.WORKFLOW_ENCRYPTION_RIGHTSECRET_ROLEARN,
		},
		MetaDataFields: {
			encryptedMetaData: [
				{
					name: "accountNumber",
					searchType: "WILDCARD",
				},
			],
		},
	},

	REPORT_WORKFLOW:
		"select * from workflow where process = 'PACE' and last_update_date >= '%startDate%' and last_update_date < '%endDate%' ORDER BY last_update_date DESC",

	REPORT_WORKFLOW_HISTORY:
		"select * from workflow_history where wfid IN (%workflowIds%)",

	IDP_REPORT: {
		Bucket: process.env.S3_BUCKET_NAME,
		Folder: process.env.S3_REPORT_FILE_PATH,
		KMSKeyId: process.env.S3_KMS_KEY_NAME,
		EncryptionType: "aws:kms",
	},

	EMAIL_TEMPLATE: {
		FROM_EMAIL: "PACE<DoNotReply@bmo.com>",
		KEYWORDS: {
			STAGE: "${stage}",
			WORKFLOW_ID: "${wfID}",
			TASK_ID: "${taskID}",
			SUBJECT: "${subject}",
			CUST_ACC_NUM: "${custAccNum}",
			DOCUMENT_NAME: "${documentName}",
			DOCUMENT_TYPE: "${documentType}",
			FNGUID: "${fnguid}",
			FAILURE_REASON: "${reason}",
			WORKSPACE_URL: "${workspaceUrl}",
			REQUESTID: "${requestId}",
		},
		TYPE: {
			CREATE_WORKFLOW: "createWorkflow",
			UPDATE_TASK: "updateTask",
			GENERATE_REPORT: "generateReports",
			ESCALATE: "escalate",
		},
		REASONS: {
			ACCOUNT_ERROR_RESPONSE: "Get account details response contains error",
			ACCOUNT_NO_RESPONSE: "Get account details response doesn't have result",
			WMT_SERVICE_FAILURE: "Exception while calling WMT Account Proxy API",
			DUPLICATED_FNGUID: "Duplicated workflow exists",
		},
		SUBJECTS: {
			DUPLICATED_WORKFLOW: "Create workflow error - duplicated workflow exists",
			CREATE_WORKFLOW: "Create workflow error",
			UPDATE_TASK: "Update task error",
			CONSOLIDATE_REPORT_GENERATED: "CONSOLIDATE_REPORT generated",
			USER_AUDIT_REPORT_GENERATED: "USER_AUDIT_REPORT generated",
			USER_REPORT_GENERATED: "USER_REPORT generated",
			ESCALATE: "Escalation Request for ${documentName} - ${documentType}",
			GENERATE_REPORT: "Generate reports error",
		},
		BODY_WITH_WFID:
			"<!DOCTYPE html><html><body>" +
			"<p><strong>${reason}</strong></p>" +
			"<p><strong>Workflow ID: </strong>${wfID}</p>" +
			"<p><strong>TASK ID: </strong>${taskID}</p>" +
			"<p><strong>Customer Account Number: </strong>${custAccNum}</p>" +
			"<p><strong>FNGUID: </strong>${fnguid}</p>" +
			"<p><strong>Document Name: </strong>${documentName}</p>" +
			"<p><strong>Document Type: </strong>${documentType}</p>" +
			"</body></html>",
		ESCALATE_BODY:
			"<html><p>The following document has been escalated and requires your attention.Please click on the <a href='${workspaceUrl}/${taskID}'>link</a> to view the validation item.<p><small>This email was sent automatically generated.  Please do not reply.</small></html>",
		SUBJECT: "PACE (${stage}): ${subject}",
		REPORT_SUBJECT: "PACE (${stage}): generate reports",
		REPORT_BODY:
			"<!DOCTYPE html><html><body>" +
			"<p><strong>${reason}</strong></p>" +
			"</body></html>",
		BODY:
			"<!DOCTYPE html><html><body>" +
			"<p><strong>${reason}</strong></p>" +
			"<p><strong>Customer Account Number: </strong>${custAccNum}</p>" +
			"<p><strong>FNGUID: </strong>${fnguid}</p>" +
			"<p><strong>Document Name: </strong>${documentName}</p>" +
			"<p><strong>Document Type: </strong>${documentType}</p>" +
			"<p><strong>Request ID: </strong>${requestId}</p>" +
			"</body></html>",
		BODY_V2:
			"<!DOCTYPE html><html><body>" +
			"<div><strong>${reason}</strong></div>" +
			"<div>Customer Account Number: <strong>${custAccNum}</strong></div>" +
			"<br>" +
			"<div>_______________________________</div>" +
			"<div>PACE</div>" +
			"<div>DoNotReply@bmo.com</div>" +
			"</body></html>",
		EMAIL_TO_LIST: process.env.SUPPORT_EMAIL_RECEIVERS,
	},
};
