const ulog = require("../util/universalLogger.js");
const ddbUtil = require("../util/ddbUtil.js");
const mapResponse = require("../util/mapResponse.js");
const constants = require("../util/constants");
const framework = require("../../common/logger/framework.js");
const fs = require("fs");

module.exports = async function (payload, args) {
	try {
		let assumedDDBRole;
		//TODO for prodcution, if deploy to prod1 no need to cross acct, if deployed to prod2 need cross acct
		if (
			process.env.STAGE == "dev" ||
			process.env.STAGE.includes("sit") ||
			process.env.STAGE.includes("perf")
		) {
			assumedDDBRole = process.env.CROSS_ACCT_DDB_ROLE;
		}
		let queryLookupTable = process.env.QUERY_LOOKUP_DDB;
		let ruleEngineTable = process.env.RULE_ENGINE_DDB;
		let workflowEncryptionTable = process.env.WORKFLOW_ENCRYPTION_DDB;
		let customQueryItems = [];
		let ruleItems = [];
		let workflowEncConfigItems = [];
		ulog.info("InsertQueryAndRule started");

		let requestPayload = payload.detail || {};
		if (requestPayload && requestPayload.configFileName) {
			let fileName =  requestPayload.configFileName;
			let fileContent = fs.readFileSync(`./resources/customQuery/${fileName}`,"utf-8");
			let queryList = JSON.parse(fileContent);
			await ddbUtil.initDDBClient(assumedDDBRole);
			ulog.info("Insert custom queries begin...", queryList);
			await ddbUtil.insertItems(queryLookupTable, queryList);
			ulog.info("Insert custom queries end");
			return mapResponse.generateSuccessResponse(
				200,
				framework.getCorrelationId(),
				"Insert Custom Query finished successfully"
			);
		}
		//insert custom query
		// Note: These queries use data from the Statements API integration
		// See: API_INTEGRATION.md for endpoint details and /api/schema/{operation}
		customQueryItems.push({
			queryId: constants.VIEW_DOCUMENT_QUERY_ID,
			query: constants.VIEW_DOCUMENT_QUERY,
			// API Reference: Uses Statements.List API via GET /api/list (requires token from /api/authenticate)
		});

		customQueryItems.push({
			queryId: constants.WORKSPACE_QUERY_ID,
			query: constants.WORKSPACE_QUERY,
			// API Reference: Task workspace queries; related to token-based session management from /api/authenticate
		});

		customQueryItems.push({
			queryId: constants.WORKSPACE_COUNT_QUERY_ID,
			query: constants.WORKSPACE_COUNT_QUERY,
			// API Reference: Count of tasks; complements /api/list response from Statements service
		});
		
		customQueryItems.push({
			queryId: constants.REPORT_WORKFLOW_QUERY_ID,
			query: constants.REPORT_WORKFLOW_QUERY,
			// API Reference: Report generation; related to /api/create-pdf for document bundling
		});
		customQueryItems.push({
			queryId: constants.PACE_REPORT_WORKFLOWHISTORY_ID,
			query: constants.REPORT_WORKFLOW_HISTORY,
			// API Reference: Workflow history queries; part of dynamic filtering supported by /api/list-dynamic
		});

		await ddbUtil.initDDBClient(assumedDDBRole);
		ulog.info("Insert custom queries begin...", customQueryItems);
		await ddbUtil.insertItems(queryLookupTable, customQueryItems);
		ulog.info("Insert custom queries end");

		//insert app role rule
		ruleItems.push({
			lob: "pbbus",
			application: "pace",
			rules: constants.PACE_RULEENGINE_RULES,
		});
		ulog.info("Insert appRole rules begin...", ruleItems);

		await ddbUtil.insertItems(ruleEngineTable, ruleItems);
		ulog.info("Insert appRole rules end");

		//Workflow encryption config
		workflowEncConfigItems.push(constants.WORKFLOW_ENCRYTION);
		ulog.info(
			"Insert workflow encryption config begin...",
			workflowEncConfigItems
		);
		await ddbUtil.insertItems(workflowEncryptionTable, workflowEncConfigItems);
		ulog.info("Insert workflow encryption config end");
		ddbUtil.closeDDBClient();

		return mapResponse.generateSuccessResponse(
			200,
			framework.getCorrelationId(),
			"Insert Custom Query and app role finished successfully"
		);
	} catch (e) {
		ulog.error("Insert app role Exception: ", e);
		if (e.problemCode && e.problemCode !== undefined) {
			// if exception has problem code defined
			return mapResponse.generateErrorResponse(e.problemCode, e);
		} else {
			return mapResponse.generateErrorResponse(301, e);
		}
	}
};
