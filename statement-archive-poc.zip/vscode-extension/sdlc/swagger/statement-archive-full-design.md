# Statement Archive — Design and API Specification

**Scope Check:** In-scope operations detected: 4/4

**Sanitization Check:** No raw NCP messages, tokens, hashes, secrets, or backend error PDFs are exposed in consumer payloads

**Binary Handling Check:** application/pdf response and API Gateway binary handling are included

## Overview

This document describes the consumer-facing REST facade (BIAN-aligned) over NCP Direct Access backend services. The facade exposes two business operations:

- `ListStatement` — Lists available statements for an account (or accounts). Internally orchestrates NCP SOAP `Authenticate` then `List`.
- `RetrieveStatement` — Retrieves a statement PDF via backend REST `GetAccountPDF` or `GetAccountPDFinline` depending on `operationName`.

The implementation is intended to run in AWS Lambda behind API Gateway.

## Assumptions and Design Notes

- Secrets (`clientId`, `userId`, `password`, `sharedSecret`) are stored in AWS Secrets Manager and never returned to callers or logs.
- NCP tokens and document keys expire after ~30 minutes; treat them as short-lived.
- Consumer dates are `yyyy-mm-dd`; convert to `yyyymmdd` for NCP Authenticate.
- SHA-256 hash is computed server-side by concatenating parameters 1..10 (omitting unused optionals), appending the shared secret, and hashing.
- SOAP service: `Statements` at `https://directaccess.ncpsolutions.com:8443/AvailableImages/Statements.svc`.
- SOAP actions:
  - Authenticate: `http://directaccess.ncpsolutions.com/services/IStatements/Authenticate`
  - List: `http://directaccess.ncpsolutions.com/services/IStatements/List`
- NCP REST endpoints:
  - `GetAccountPDF`: `https://directaccess.ncpsolutions.com:8443/ImageRetrieval/Repository.svc/GetAccountPDF/{documentKey}`
  - `GetAccountPDFinline`: `https://directaccess.ncpsolutions.com:8443/ImageRetrieval/Repository.svc/GetAccountPDFinline/{documentKey}`
- For PDF retrieval, if backend returns a `Warning` header, suppress the PDF body and return a sanitized JSON error to the consumer.
- Correlation ID: accept `X-Correlation-Id` header; generate if absent. Include in logs and responses.
- Mask `accountNumber` and `statementKey` in logs (e.g., show first/last few characters or hashed value).

## Swagger Specification

The API Swagger YAML is included below. It is also saved as `sdlc/swagger/statement-archive-bian.swagger.yaml` in the repo.

```yaml
openapi: 3.0.3
info:
  title: Mortgage-loan-statement service.
  version: 1.0.0
  description: >
    Swagger specification for a mortgage-loan-statement API adapter that provides
    search and retrieval of mortgage statements from a third-party backend.
    This API is BIAN-aligned and hides backend SOAP/REST implementation details
    from consumers, exposing two primary operations: ListStatement and RetrieveStatement.
  contact:
    name: Smartcore CG
    email: CGV2DevelopmentTeam@bmo.com
    url: https://confluence.bmogc.net/display/CG2V
  x-audience: company-internal
servers:
  - url: https://api.examplebank.com
    description: Production
  - url: https://api-uat.examplebank.com
    description: UAT
tags:
  - name: StatementArchive
    description: Statement archive operations
paths:
  /statement-archive/v1/statements/list:
    post:
      tags:
        - StatementArchive
      operationId: ListStatement
      summary: List available statements for an account
      description: >-
        Calls backend Authenticate (SOAP) and List (SOAP) in sequence, then maps the XML list
        response to consumer JSON.
      x-bian-service-domain: Statement Archive
      x-bian-action-term: Retrieve
      x-aws-apigateway-integration-hint: lambda-proxy
      parameters:
        - $ref: '#/components/parameters/CorrelationId'
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ListStatementRequest'
            examples:
              default:
                value:
                  accountNumber: "12345678"
                  startDate: "2023-01-01"
                  endDate: "2024-01-01"
                  product: "00001000"
                  flexField1: ""
                  flexField2: ""
                  flexField3: ""
                  clientIpAddress: "10.20.30.40"
      responses:
        '200':
          description: Statement list successfully retrieved
          headers:
            X-Correlation-Id:
              $ref: '#/components/headers/CorrelationIdHeader'
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/ListStatementResponse'
              examples:
                statementsFound:
                  value:
                    accountNumber: "12345678"
                    statements:
                      - statementDate: "2014-09-30"
                        description: "Monthly Statement"
                        statementKey: "6754325468636748593261506F7..."
                        product: "00001000"
                noRecords:
                  value:
                    accountNumber: "12345678"
                    statements: []
        '400':
          description: Invalid request payload
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/ErrorResponse'
        '401':
          description: Authentication/session timeout
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/ErrorResponse'
        '502':
          description: Upstream dependency error
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/ErrorResponse'
        '500':
          description: Internal server error
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/ErrorResponse'
  /statement-archive/v1/statements/retrieve:
    post:
      tags:
        - StatementArchive
      operationId: RetrieveStatement
      summary: Retrieve statement PDF
      description: >-
        Calls backend GetAccountPDF or GetAccountPDFinline (REST) based on operationName.
        Uses X-NCP-AUTH with accountNumber and statementKey as URL path segment.
        If backend returns Warning header, suppresses backend error PDF and returns sanitized JSON error.
      x-bian-service-domain: Statement Archive
      x-bian-action-term: Retrieve
      x-aws-apigateway-binary-media-types:
        - application/pdf
      parameters:
        - $ref: '#/components/parameters/CorrelationId'
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/RetrieveStatementRequest'
            examples:
              inlineRequest:
                value:
                  accountNumber: "12345678"
                  statementKey: "6754325468636748593261506F7..."
                  operationName: "GetAccountPDFinline"
              attachmentRequest:
                value:
                  accountNumber: "12345678"
                  statementKey: "6754325468636748593261506F7..."
                  operationName: "GetAccountPDF"
      responses:
        '200':
          description: PDF stream retrieved successfully
          headers:
            X-Correlation-Id:
              $ref: '#/components/headers/CorrelationIdHeader'
            Content-Disposition:
              schema:
                type: string
              description: inline for GetAccountPDFinline, attachment for GetAccountPDF
          content:
            application/pdf:
              schema:
                type: string
                format: binary
        '400':
          description: Invalid request payload or corrupt statement key
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/ErrorResponse'
        '401':
          description: Session timeout for statement retrieval
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/ErrorResponse'
        '403':
          description: Request not authorized for statement retrieval
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/ErrorResponse'
        '404':
          description: Statement not found
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/ErrorResponse'
        '502':
          description: Upstream dependency error or Warning header reported by backend
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/ErrorResponse'
        '500':
          description: Internal server error
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/ErrorResponse'
components:
  parameters:
    CorrelationId:
      name: X-Correlation-Id
      in: header
      required: false
      description: Optional consumer-provided correlation identifier. Generated if absent.
      schema:
        type: string
        maxLength: 64
  headers:
    CorrelationIdHeader:
      description: Correlation identifier for end-to-end tracing.
      schema:
        type: string
  schemas:
    ListStatementRequest:
      type: object
      required:
        - accountNumber
      properties:
        accountNumber:
          type: string
          description: End customer account number or statement identifier value.
          maxLength: 500
          example: "12345678"
        startDate:
          type: string
          format: date
          description: Optional start date in yyyy-mm-dd. Converted to yyyymmdd for backend.
        endDate:
          type: string
          format: date
          description: Optional end date in yyyy-mm-dd. Converted to yyyymmdd for backend.
        product:
          type: string
          description: Optional product filter.
          maxLength: 32
        flexField1:
          type: string
          description: Optional flex field 1.
          maxLength: 64
        flexField2:
          type: string
          description: Optional flex field 2.
          maxLength: 64
        flexField3:
          type: string
          description: Optional flex field 3.
          maxLength: 64
        clientIpAddress:
          type: string
          description: Optional client IP address.
          maxLength: 64
    ListStatementResponse:
      type: object
      required:
        - accountNumber
        - statements
      properties:
        accountNumber:
          type: string
          example: "12345678"
        statements:
          type: array
          items:
            $ref: '#/components/schemas/Statement'
    Statement:
      type: object
      required:
        - statementDate
        - description
        - statementKey
        - product
      properties:
        accountNumber:
          type: string
          description: Returned when provided by backend configuration.
        statementDate:
          type: string
          format: date
          description: Statement date normalized to yyyy-mm-dd.
        description:
          type: string
        statementKey:
          type: string
          description: Expiring statement retrieval key.
        product:
          type: string
        flexField1:
          type: string
        flexField2:
          type: string
        flexField3:
          type: string
        flexField4:
          type: string
        flexField5:
          type: string
        flexField6:
          type: string
    RetrieveStatementRequest:
      type: object
      required:
        - accountNumber
        - statementKey
        - operationName
      properties:
        accountNumber:
          type: string
          maxLength: 128
        statementKey:
          type: string
          maxLength: 1024
        operationName:
          type: string
          enum:
            - GetAccountPDF
            - GetAccountPDFinline
          description: Backend operation selector for PDF retrieval behavior.
    ErrorResponse:
      type: object
      required:
        - code
        - message
        - correlationId
      properties:
        code:
          type: string
          example: STATEMENT_ARCHIVE_UPSTREAM_ERROR
        message:
          type: string
          example: We are unable to process your request at this time. Please try again later.
        correlationId:
          type: string
          example: 8f8ff4f7-8fd8-49f5-b347-896ff6fca15f
        details:
          type: object
          additionalProperties: true
          description: Optional non-sensitive debugging metadata.
  securitySchemes:
    bearerAuth:
      type: http
      scheme: bearer
      bearerFormat: JWT
security:
  - bearerAuth: []
```

## Backend Operation Mapping

- Authenticate (SOAP): Accepts `clientId`, `userId`, `password`, `account`, `startDate`, `endDate`, `product`, `flexField1..3`, `clientIpAddress`, `hash`. Returns token string or error string starting with `ERROR: Authentication Failure`.
- List (SOAP): Accepts `token`, returns XML string `<statementlist>...</statementlist>` or error node.
- GetAccountPDF / GetAccountPDFinline (REST): Accept `X-NCP-AUTH: {accountNumber}` header and `{documentKey}` path segment. Return `application/pdf` or `application/pdf` + `Warning` header on error.

## Request Mapping Table

- `ListStatement`:
  - Validate `accountNumber` present.
  - Convert dates `yyyy-mm-dd` -> `yyyymmdd` or empty string.
  - Build Authenticate params and compute `hash` server-side.
  - Call SOAP Authenticate action.
  - If success: call SOAP List with returned token.
  - Parse `ListResult` XML into JSON and return.
- `RetrieveStatement`:
  - Validate fields; map `operationName` to backend path.
  - Call backend GET with `X-NCP-AUTH` header.
  - Inspect `Warning` header; if present return sanitized error; else return PDF bytes.

## Response Mapping Table

- Authenticate errors mapped to consumer HTTP codes (see Error Mapping Table).
- List success: return `ListStatementResponse` JSON mapping `<statement>` entries.
- List error `1205` -> HTTP 200 with empty `statements: []`.
- Retrieve: PDF returned as binary with `Content-Disposition` header. If `Warning` present map codes to consumer errors per table.

## Error Mapping Table

- Authenticate: 1100->400, 1101->400, 1102->500, 1103->400, 1199->502
- List: 1200->401, 1201->502, 1203->502, 1205->200(empty), 1206->502, 1207->502, 1299->502
- PDF retrieval: 1000->400, 1001->401 (document/session expired), 1003->404, 1004->502, 1005->502, 1006->403, 1099->502

## Security Considerations

- Store secrets in Secrets Manager; Lambda uses IAM to read them.
- Enforce JWT bearer auth via API Gateway.
- HTTPS end-to-end.
- Mask sensitive fields in logs; never log tokens, hashes, secrets, or PDF bytes.
- Use structured logging and correlation IDs.

## AWS Deployment Notes

- API Gateway in front of Lambda; enable binary media type `application/pdf`.
- Lambda handler implements both operations; uses Secrets Manager and SSM parameter store for config.
- If NCP requires allowlisted IPs, deploy Lambda in VPC with NAT + Elastic IP.
- Use CloudWatch Logs and X-Ray.

## Mermaid Diagrams

### High-level Architecture

```mermaid
flowchart LR
  subgraph Consumer
    A[Consumer App]
  end
  A -->|HTTPS POST| B[API Gateway]
  B -->|Invoke| C[Lambda: Statement Archive Handler]
  C --> D[AWS Secrets Manager]
  C --> E[AWS Systems Manager Parameter Store]
  C -->|SOAP Authenticate/List| F[NCP Available Images (SOAP)]
  C -->|REST GetAccountPDF| G[NCP Image Retrieval (REST)]
  F --> H[NCP Document Archive]
  G --> H
  C -->|Logs & Traces| I[CloudWatch Logs / X-Ray]
```

### ListStatement Sequence

```mermaid
sequenceDiagram
  participant Consumer
  participant APIGW as API Gateway
  participant Lambda
  participant Secrets as Secrets Manager
  participant NCPAuth as NCP Authenticate (SOAP)
  participant NCPList as NCP List (SOAP)

  Consumer->>APIGW: POST /statement-archive/v1/statements/list
  APIGW->>Lambda: invoke ListStatement
  Lambda->>Secrets: Get NCP credentials & sharedSecret
  Lambda->>NCPAuth: SOAP Authenticate (params + server-generated hash)
  alt Authenticate fails
    NCPAuth-->>Lambda: ERROR: Authentication Failure...
    Lambda->>APIGW: sanitized ErrorResponse (mapped HTTP code)
    APIGW->>Consumer: ErrorResponse
  else Authenticate succeeds
    NCPAuth-->>Lambda: token
    Lambda->>NCPList: SOAP List (token)
    alt List returns error (1205 -> no records)
      NCPList-->>Lambda: ListResult with <error><code>1205...
      Lambda->>APIGW: 200 { statements: [] }
      APIGW->>Consumer: {}
    else List returns statements
      NCPList-->>Lambda: ListResult XML
      Lambda->>Lambda: parse XML -> JSON
      Lambda->>APIGW: 200 ListStatementResponse
      APIGW->>Consumer: ListStatementResponse
    end
  end
```

### RetrieveStatement Sequence

```mermaid
sequenceDiagram
  participant Consumer
  participant APIGW as API Gateway
  participant Lambda
  participant NCPREST as NCP Image Retrieval REST

  Consumer->>APIGW: POST /statement-archive/v1/statements/retrieve
  APIGW->>Lambda: invoke RetrieveStatement
  Lambda->>Lambda: validate operationName, statementKey
  Lambda->>NCPREST: GET /{operation}/{statementKey} with X-NCP-AUTH
  alt Warning header present
    NCPREST-->>Lambda: 200 application/pdf + Warning: "1001:Document key expired"
    Lambda->>APIGW: sanitized ErrorResponse (mapped HTTP code)
    APIGW->>Consumer: ErrorResponse
  else no Warning header
    NCPREST-->>Lambda: 200 application/pdf (PDF bytes)
    Lambda->>APIGW: 200 application/pdf (base64, isBase64Encoded=true)
    APIGW->>Consumer: PDF binary (Content-Disposition inline|attachment)
  end
```

## Risks, Open Questions & Recommendations

- Risk: NCP rate limits or intermittent SOAP failures — implement backoff and SRE runbook.
- Question: Does NCP require fixed outbound IP for allowlisting? If yes, Lambda must use NAT + EIP.
- Question: How long should secure backend logs be retained and who can access them?
- Recommendation: Add an automated integration test harness against UAT NCP to validate hash generation, SOAP envelopes, XML parsing, and Warning header behavior.
- Recommendation: Implement X-Ray tracing and structured logs with correlationId.

---

Generated: 2026-07-06

File: `sdlc/swagger/statement-archive-full-design.md`
