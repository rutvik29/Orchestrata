# Statement Archive API Design

Scope Check: In-scope operations detected: 4/4

## Scope Confirmation

| Backend Operation | Type | In Scope | Notes |
|---|---|---|---|
| Authenticate | SOAP | Yes | Used internally by ListStatement |
| List | SOAP | Yes | Used internally by ListStatement |
| GetAccountPDF | REST | Yes | Used internally by RetrieveStatement |
| GetAccountPDFinline | REST | Yes | Used internally by RetrieveStatement |
| ListDynamic | SOAP | No | Out of scope |
| CreateMultidocPDF | SOAP | No | Out of scope |

## Preservation Check

- Enterprise metadata preserved:
  - title: Mortgage-loan-statement service.
  - version: 1.0.0
  - x-audience: company-internal
  - contact: Smartcore CG / CGV2DevelopmentTeam@bmo.com / https://confluence.bmogc.net/display/CG2V
- Enterprise headers are included on all operations:
  - x-request-id, x-client-id, x-api-key, x-fapi-financial-id,
    x-fapi-customer-last-logged-time, x-fapi-customer-ip-address,
    x-fapi-customer-user-agent, x-fapi-interaction-id, Authorization, x-app-cat-id
- Response headers preserved on all operations:
  - x-request-id, x-fapi-interaction-id
- Response codes preserved on all operations:
  - 200, 400, 401, 403, 404, 415, 429, 500, 502, 504
- Enterprise security preserved:
  - apiKeyAuth (x-api-key header) and Authorization header parameter support
- Swagger specification format preserved

## Backend Operation Mapping

- ListStatement internal flow:
  1. Call Authenticate (SOAP)
  2. Call List (SOAP) using token from Authenticate
- RetrieveStatement internal flow:
  1. Validate operationName
  2. operationName=GetAccountPDF -> call backend GetAccountPDF
  3. operationName=GetAccountPDFinline -> call backend GetAccountPDFinline
- Legacy operationName mapping:
  - getAccountPDF -> GetAccountPDF
  - getAccountPDFInline -> GetAccountPDFinline

## Request Mapping

### ListStatement
- Consumer request maps to Authenticate parameters:
  - accountNumber -> account
  - startDate/endDate (yyyy-mm-dd) converted to yyyymmdd
  - product, flexField1/2/3, clientIpAddress map directly
- Credentials and shared secret are loaded internally from secrets storage.
- Hash is generated internally and never returned.

### RetrieveStatement
- statementKey -> backend URL path segment document key
- accountNumber -> backend header X-NCP-AUTH
- operationName controls backend endpoint selection
- Unsupported operationName values must be rejected before backend call.

## Response Mapping

### Legacy list
- Returns productResponse shape:
  - result + statementList.statements[]

### BIAN list
- Returns ListStatementResponse shape:
  - result + statements[]
- For backend code 1205: return HTTP 200 with empty statements array.

### Legacy retrieve
- Returns streamingResponse JSON wrapper with base64 PDF (statementsPDF).

### BIAN retrieve
- Returns application/pdf binary body with Content-Disposition header.

## Error Mapping

### Authenticate
- 1100 -> HTTP 400
- 1101 -> HTTP 400
- 1102 -> HTTP 500
- 1103 -> HTTP 400
- 1199 -> HTTP 502

### List
- 1200 -> HTTP 401
- 1201 -> HTTP 502
- 1203 -> HTTP 502
- 1205 -> HTTP 200 with empty statements array
- 1206 -> HTTP 502
- 1207 -> HTTP 502
- 1299 -> HTTP 502

### PDF retrieval
- 1000 -> HTTP 400
- 1001 -> HTTP 401 (session/document expired message)
- 1003 -> HTTP 404
- 1004 -> HTTP 502
- 1005 -> HTTP 502
- 1006 -> HTTP 403
- 1099 -> HTTP 502

## Sanitization Controls

Sanitization Check: No raw NCP messages, tokens, hashes, secrets, or backend error PDFs are exposed in consumer payloads

- Do not expose backend credentials, shared secret, generated hash, token, raw XML, or raw warning details.
- If backend Warning header is present on PDF retrieval:
  - Suppress PDF body
  - Log internal details securely with correlation id
  - Return sanitized JSON error payload
- Never return backend error PDF to consumer.

## Security Controls

- Gateway security uses x-api-key (apiKeyAuth).
- Authorization header remains supported as optional enterprise header.
- Correlation headers are propagated in responses.
- Sensitive values are masked or excluded from logs.

## AWS Deployment Notes

Binary Handling Check: application/pdf response and API Gateway binary handling are included

**Swagger specification:** See `sdlc/swagger/statement-archive-bian.swagger.yaml` for the complete Swagger schema.

- API Gateway:
  - Enable binary media type application/pdf
  - Validate request schema and required headers
- Lambda proxy integration:
  - Return base64-encoded PDF body for BIAN retrieve success
  - Set isBase64Encoded: true
  - Set Content-Type: application/pdf
  - Set Content-Disposition based on operationName
- If backend Warning header exists, return sanitized JSON error instead of PDF.

## Mermaid High-Level Architecture

```mermaid
flowchart LR
  Consumer[Consumer Channels] --> APIGW[API Gateway]
  APIGW --> Lambda[Lambda Statement Archive Handler]
  Lambda --> Secrets[Secrets Manager]
  Lambda --> SOAP[NCP SOAP: Authenticate and List]
  Lambda --> REST[NCP REST: GetAccountPDF and GetAccountPDFinline]
  Lambda --> Logs[CloudWatch Logs]
```

## Mermaid ListStatement Sequence

```mermaid
sequenceDiagram
  participant C as Consumer
  participant G as API Gateway
  participant L as Lambda
  participant N1 as NCP Authenticate SOAP
  participant N2 as NCP List SOAP

  C->>G: POST /statement-archive/v1/statements/list
  G->>L: Invoke
  L->>N1: Authenticate
  alt Backend authentication error
    N1-->>L: Authentication failed
    L-->>G: Sanitized ErrorResponse
    G-->>C: Sanitized ErrorResponse
  else Success
    N1-->>L: Token
    L->>N2: List(token)
    alt No records (1205)
      N2-->>L: No records
      L-->>G: 200 with empty statements
      G-->>C: 200 with empty statements
    else Records found
      N2-->>L: Statement data
      L-->>G: 200 list response
      G-->>C: 200 list response
    end
  end
```

## Mermaid RetrieveStatement Sequence

```mermaid
sequenceDiagram
  participant C as Consumer
  participant G as API Gateway
  participant L as Lambda
  participant N as NCP REST Retrieval

  C->>G: POST /statement-archive/v1/statements/retrieve
  G->>L: Invoke
  alt operationName=GetAccountPDF
    L->>N: GET GetAccountPDF/{statementKey} + X-NCP-AUTH
  else operationName=GetAccountPDFinline
    L->>N: GET GetAccountPDFinline/{statementKey} + X-NCP-AUTH
  end

  N-->>L: PDF response
  alt Backend Warning header present
    L->>L: Suppress backend error PDF and log securely
    L-->>G: Sanitized ErrorResponse
    G-->>C: Sanitized ErrorResponse
  else Success
    L-->>G: 200 application/pdf (base64, isBase64Encoded=true)
    G-->>C: 200 application/pdf
  end
```

## Risks, Open Questions, Recommendations

- Risks:
  - Token and statement key expiration at approximately 30 minutes can cause retrieval failures.
  - Backend Warning-header flow must be tested to verify PDF suppression.
- Open Questions:
  - Should Authorization be optional or required by runtime policy in each environment?
  - Is outbound IP allow-listing required in all environments?
- Recommendations:
  - Add integration tests for warning-header behavior and 1001/1006 mappings.
  - Add contract tests to ensure four paths and enterprise headers remain unchanged.
