---
applyTo: '**'
---

# SDLC Assistant: AI Agent Customization

This file guides AI coding agents through the SDLC Assistant codebase and its conventions.

## Project Overview

[SDLC Assistant](README.md) is a VS Code extension that automates a phased software delivery pipeline using GitHub Copilot. It orchestrates 9 phases (documentation → business analysis → architecture → development → code review → security review → performance review → QA → DevOps), persists transcripts, and surfaces progress in a webview panel.

**Not a user guide?** See [README.md](README.md) for user installation, setup, and troubleshooting.

## Build and Development

```bash
npm run build        # Bundles extension (Node/CJS) + webview (Browser/IIFE) via esbuild → dist/ + media/
npm run watch        # Continuous rebuild on file changes (development mode)
npm run typecheck    # TypeScript strict-mode validation
npm run vscode:prepublish  # Pre-publish build (same as `build`)
```

**Key tooling:**
- **esbuild** — dual-target bundler (extension as CommonJS/Node18, webview as IIFE/ES2022)
- **TypeScript** — strict mode, ES2022 target, sourcemaps enabled
- **VS Code SDK** — @types/vscode (1.90+), @github/copilot-sdk

**Outputs:**
- `dist/extension.js` — bundled extension (Node entry point)
- `media/webview.js` — bundled webview UI (browser IIFE)
- Both include sourcemaps

## Architecture and Key Patterns

## Architecture and Key Patterns

### Component Map

| Component | Path | Purpose |
|-----------|------|---------|
| **Orchestrator** | `src/pipeline/orchestrator.ts` | Drives phase loop; builds prompts from agent definitions; handles code-review verdict parsing; persists transcripts; **initializes API registry** |
| **Phase Definitions** | `src/pipeline/phases.ts` | Defines 9-phase sequence, gating logic, iteration cap (default 3, max 10 for dev↔codereview loop) |
| **Agent Loader** | `src/agents/agentLoader.ts` | Parses `.agent.md` files (YAML frontmatter + body); resolves personas from `~/.copilot/agents/` |
| **Session Manager** | `src/copilot/sessionManager.ts` | Wraps @github/copilot-sdk; auto-detects platform-specific Copilot CLI binary; manages session lifecycle |
| **Pipeline Panel** | `src/webview/PipelinePanel.ts` | Host for webview; orchestrates extension ↔ UI messaging; gates permissions and confirmations |
| **Webview Protocol** | `src/webview/protocol.ts` | Type definitions for extension ↔ webview RPC messages; **includes API operation types** |
| **Repository Context** | `src/context/repoContext.ts` | Loads optional GitHub repo metadata; injected into all phase prompts |
| **API Registry** | `src/context/apiRegistry.ts` | **NEW:** Manages Statements API operation catalog; provides parameter-to-operation mapping; injects hyperlinks into phase output |
| **Extension Entry** | `src/extension.ts` | Registers `sdlc.openPanel` command; validates workspace folder |

### Phase Loop

1. **Iterate through PHASES** (defined in `phases.ts`)
2. **For each phase:**
   - Load agent persona definition (YAML + body from `.agent.md`)
   - Build prompt: [person body] + [injected repository context] + [user initial request]
   - Submit to Copilot session via SessionManager
   - Emit updates to webview as events arrive
   - **Special handling for Code Review:** Parse PASS/FAIL verdict
     - **FAIL** → jump back to dev phase, increment iteration count
     - **Iteration cap exceeded?** → force forward to next phase
3. **Gate decisions:** If `confirmMode` is `'high-impact-only'` or `'always'`, pause after Architecture and/or Code Review
4. **Persist transcript:** Save prompt + all responses to `sdlc/.sdlc-runs/<runId>/phase-*.md` and `phase-*.json`

### Key Architectural Decisions

| Decision | Rationale |
|----------|-----------|
| **Zero npm runtime deps** | Extension bundles @github/copilot-sdk and all transitive deps at build time; no runtime install |
| **Copilot CLI auto-detection** | Searches: `sdlc.copilot.cliPath` setting → `COPILOT_CLI_PATH` env var → platform-specific well-known dirs → `PATH` |
| **Code Review loops only** | Dev phase runs once per pipeline; only code-review verdict triggers dev ↔ review iteration |
| **Gating on high-impact phases** | Architecture and Code Review default to `confirmBetweenPhases: 'high-impact-only'`; user can override to `'always'` or `'never'` |
| **Explicit permissions** | Copilot SDK asks user before reading/writing files or executing commands; no silent side effects |
| **Immutable transcripts** | All prompts + responses archived under `.sdlc-runs/<runId>/` with manifest.json for audit trail |
| **Agent personalization via YAML** | `.agent.md` files in `~/.copilot/agents/` use YAML frontmatter + body; agent loader extracts both |

## Coding Conventions

**Every function must include a header comment** (as per global instructions):

```typescript
// [One-line purpose].
// Purpose: [what the function does, what it decides, what it orchestrates].
// Inputs: [parameter list and types].
// Outputs: [return type and what it represents].
// Typical response: [example output or behavior for a representative call].

function exampleFunction(input: string): string {
  // implementation
}
```

Example from the codebase:
```typescript
// Extension entry point.
// Purpose: register the SDLC: Open Pipeline command and dispose resources on shutdown.
// Inputs: vscode.ExtensionContext from VS Code.
// Outputs: registers commands; returns void from activate/deactivate.
// Typical response: invoking the command opens the SDLC Pipeline webview panel.
```

**TypeScript Style:**
- Strict mode enabled (`"strict": true` in tsconfig.json)
- ES2022 target
- Import types from @types/vscode, not the vscode package at runtime (external to bundle)
- Use relative imports for internal modules

**Naming:**
- **Phase IDs:** `phase-N-label` (e.g., `phase-3-5-codereview`) — sequential phase count + short name
- **Agent names:** lowercase with hyphens (e.g., `ba-analyst`, `dev`, `codereview`)
- **Run folders:** `sdlc/.sdlc-runs/<runId>/` where runId is a timestamp-based slug

## Common Tasks for Agents

### Add a New Phase

1. **Define phase** in `src/pipeline/phases.ts` → extend `PHASES` array with `PhaseDefinition`
2. **Specify agent name** (must exist as `.agent.md` in `~/.copilot/agents/`)
3. **Set gating logic** via `shouldGate()` if this phase should pause for user confirmation
4. **Test:** Ensure orchestrator processes the new phase without errors

### Modify Session Management

- **File:** `src/copilot/sessionManager.ts`
- **Key method:** `submitPrompt(...)` — formats and submits to Copilot SDK; parses streaming responses
- **Watch for:** Copilot CLI binary detection; platform-specific path handling

### Extend Webview UI

- **Files:** `src/webview/main.ts`, `src/webview/PipelinePanel.ts`, `media/webview.css`
- **Protocol:** Message types defined in `src/webview/protocol.ts` (RPC contract between extension ↔ UI)
- **Rebuild:** Run `npm run watch` for live updates during development

### Add API Integration to a Script

- **Reference:** See `insertQueryAndRule.js` for example API reference comments
- **Pattern:** Add `// API Reference:` comments linking database queries to API operations
- **Example:** Query references `/api/list` operation from Statements service

### Access API Registry in Your Code

```typescript
import { apiRegistry } from "../context/apiRegistry";

// Initialize (done automatically by orchestrator)
await apiRegistry.initialize();

// Get all operations
const ops = apiRegistry.getOperations();

// Find operation by parameter
const op = apiRegistry.findOperationByParameter("clientId"); // Returns "authenticate"

// Create hyperlink for output
const linked = apiRegistry.linkifyParameter("User ID", "userId"); // Returns "[User ID→API](/swagger/authenticate)"

// Scan and linkify entire text
const output = apiRegistry.scanAndLinkify("Authenticate with clientId and userId");
// Returns: "Authenticate with [clientId→API](/swagger/authenticate) and [userId→API](/swagger/authenticate)"

// Get operation schema
const schema = apiRegistry.getSchema("authenticate");
// Returns: { operation: "authenticate", requestSchema: {...}, responseSchema: {...} }
```

## Critical Pitfalls

| Issue | Resolution |
|-------|-----------|
| **Copilot CLI not found** | Ensure GitHub Copilot CLI is installed and in PATH, or set `sdlc.copilot.cliPath` in settings |
| **Agent files missing** | Run `node scripts/install-agents.mjs` or manually copy `.agent.md` files to `~/.copilot/agents/` |
| **Extension won't activate** | Requires open workspace folder; run `sdlc.openPanel` command only after opening a folder |
| **Code review loop stuck** | Increase `sdlc.pipeline.maxReviewIterations` (default 3, max 10) in settings |
| **GitHub context fails** | Private repos need VS Code GitHub auth; check `sdlc.github.apiBaseUrl` for enterprise URLs |
| **Build fails with "external: vscode"** | Expected — vscode module is excluded from bundle; must be provided by VS Code at runtime |

## Testing and Validation

- **No automated tests in repo** — manual testing via VS Code extension host
- **TypeScript validation:** `npm run typecheck` catches type errors early
- **Build validation:** `npm run build` succeeds with no warnings for production release

## Settings and Configuration

See [README.md § Settings](README.md#settings) for user-facing settings. Key ones for agents:

- `sdlc.copilot.defaultModel` — model used for all phase runs (e.g., `gpt-5`)
- `sdlc.pipeline.maxReviewIterations` — iteration cap for dev ↔ codereview loop
- `sdlc.pipeline.confirmBetweenPhases` — gating strategy (`never`, `high-impact-only`, `always`)
- `sdlc.copilot.cliPath` — explicit Copilot CLI path (leave empty for auto-detect)

## Related Documentation

- [README.md](README.md) — User guide, installation, troubleshooting
- [API_INTEGRATION.md](API_INTEGRATION.md) — Statements API wrapper, Swagger spec, link injection
- [API_QUICKSTART.md](API_QUICKSTART.md) — 5-minute setup and testing guide
- [VS Code Extension API](https://code.visualstudio.com/api) — Extension development reference
- [@github/copilot-sdk](https://github.com/github/copilot-sdk) — Copilot SDK documentation
- `src/` — Inline function comments document all major components
