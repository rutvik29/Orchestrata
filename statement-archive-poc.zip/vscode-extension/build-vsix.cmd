@echo off
REM Build the BMO Digital Core SDLC Assistant .vsix (Windows)
cd /d "%~dp0sdlc"
call npm install --no-audit --no-fund || exit /b 1
call npm run build || exit /b 1
call npx --yes @vscode/vsce package --allow-missing-repository -o "..\sdlc-assistant-2.0.0.vsix" || exit /b 1
echo.
echo VSIX created: %~dp0sdlc-assistant-2.0.0.vsix
echo Install with:  code --install-extension "%~dp0sdlc-assistant-2.0.0.vsix"
